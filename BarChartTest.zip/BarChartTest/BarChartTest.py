###!/usr/bin/python
##import MySQLdb
##
##db = MySQLdb.connect(host="localhost",    # your host, usually localhost
##                     user="root",         # your username
##                     passwd="malarkodi",  # your password
##                     db="test_schema")        # name of the data base
##
### you must create a Cursor object. It will let
###  you execute all the queries you need
##cur = db.cursor()
##
### Use all the SQL you like
##cur.execute("SELECT * FROM bar_chart_test")
##
### print all the first cell of all the rows
##for row in cur.fetchall():
##    print (row[0])
##
##db.close()


###############################################################################

##import pymysql
##import matplotlib.pyplot as plt; plt.rcdefaults()
##import numpy as np
##import matplotlib.pyplot as plt
##import pandas as pd
##
##
##conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='malarkodi', db='test_schema')
##
##cur = conn.cursor()
##cur.execute("SELECT * FROM bar_chart_test")
##rows = cur.fetchall()
##
####print(cur.description)
####print()
####
####for rows in cur:
####    print(rows)
##
##
##
##df = pd.DataFrame( [[ij for ij in i] for i in rows] )
##df.rename(columns={0: 'ID', 1: 'Name', 2: 'Marks'}, inplace=True);
###df = df.sort(['Marks'], descending=[1]);
###print(df)
##
###objects = ('Python', 'C++', 'Java', 'Perl', 'Scala', 'Lisp')
##x = df['Name']
##print(x)
##
##y_pos = np.arange(len(x))
##y = df['Marks']
##print(y)
##
##plt.bar(y_pos, y, align='center', alpha=0.5)
##plt.xticks(y_pos, x)
##plt.ylabel('STUDENT MARKS')
##plt.title('STUDENT MARKS DATA')
##
##plt.show()
##
##cur.close()
##conn.close()




################################


import pymysql
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
#import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import pylab
from pylab import *


#DB CONNECTION STRING
conn = pymysql.connect(host='localhost', port=3306, user='root', passwd='malarkodi', db='test_schema')

cur = conn.cursor()
cur.execute("SELECT * FROM bar_chart_test")
rows = cur.fetchall() #FETCHING ALL RECORDS


#APPENDING THE RECORDS TO DATAFRAME
df = pd.DataFrame( [[ij for ij in i] for i in rows] )
df.rename(columns={0: 'ID', 1: 'Name', 2: 'Marks'}, inplace=True); #ALIAS NAME FOR COLUMN NAMES

#X-AXIS
x = df['Name']
print(x)

#Y-AXIS
y_pos = np.arange(len(x))
y = df['Marks']
print(y)

#PLOTTING THE BAR GRAPH
plt.bar(y_pos, y, align='center', alpha=0.5)
plt.xticks(y_pos, x)
plt.ylabel('STUDENT MARKS')
plt.title('STUDENT MARKS DATA')

#plt.show()

#CLOSING DB CONNECTIONS
cur.close()
conn.close()

pylab.savefig('BarChart_StudentMarks.png')

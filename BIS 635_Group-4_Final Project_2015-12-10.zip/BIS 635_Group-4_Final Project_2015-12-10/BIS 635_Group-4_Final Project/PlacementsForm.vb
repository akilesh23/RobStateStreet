﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : PlacementsForm
'Description     : This class contains all the properties of PlacementsForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class PlacementsForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private CompanyId As Integer

    Private Sub PlacementsForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub

    Private Sub PlacementsForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        DBAccess.ExecuteQuery("SELECT * FROM Students")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
            StudentIdComboBox.Items.Add(ADataRow("StudentId"))
        Next

        If DBAccess.RecordCount > 0 Then
            StudentIdComboBox.SelectedIndex = -1
        End If

        DBAccess.ExecuteQuery("SELECT * FROM Companies")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
            CompanyNameComboBox.Items.Add(ADataRow("CompanyName"))
        Next

        If DBAccess.RecordCount > 0 Then
            CompanyNameComboBox.SelectedIndex = -1
        End If

    End Sub

    Private Sub StudentIdComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles StudentIdComboBox.SelectionChangeCommitted

        DBAccess.ExecuteQuery("SELECT * FROM Students WHERE StudentId = " & StudentIdComboBox.Text & "")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        StudentFullNameTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("StudentFirstName") & " " & DBAccess.DBDataTable.Rows(0).Item("StudentLastName")

    End Sub

    Private Sub SaveButton_Click(sender As System.Object, e As System.EventArgs) Handles SaveButton.Click

        If StudentIdComboBox.Text = "" Or CompanyNameComboBox.Text = "" Or DesignationTextBox.Text = "" Or GrossSalaryTextBox.Text = "" Then
            MessageBox.Show("Please Fill In All The Required Fields")
        Else
            RecordPlacement(StudentIdComboBox.Text, JoiningDateDateTimePicker.Value.Date, InterviewDateDateTimePicker.Value.Date, DesignationTextBox.Text, GrossSalaryTextBox.Text, OtherBenefitsTextBox.Text)
        End If

    End Sub

    Private Sub RecordPlacement(StudentId As Integer, JoiningDate As Date, InterviewDate As Date, Designation As String, GrossSalary As Decimal, OtherBenefits As String)
        Try

            DBAccess.ExecuteQuery("SELECT CompanyId FROM Companies WHERE CompanyName = '" & CompanyNameComboBox.Text & "' ")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            CompanyId = DBAccess.DBDataTable.Rows(0).Item("CompanyId")

            DBAccess.AddParam("@StudentId", StudentId)
            DBAccess.AddParam("@CompanyId", CompanyId)
            DBAccess.AddParam("@JoiningDate", JoiningDate)
            DBAccess.AddParam("@InterviewDate", InterviewDate)
            DBAccess.AddParam("@Designation", Designation)
            DBAccess.AddParam("@GrossSalary", GrossSalary)
            DBAccess.AddParam("@OtherBenefits", OtherBenefits)

            DBAccess.ExecuteQuery("INSERT INTO Placements(StudentId,CompanyId,JoiningDate,InterviewDate,Designation,GrossSalary,OtherBenefits) values(@StudentId,@CompanyId,@JoiningDate,@InterviewDate,@Designation,@GrossSalary,@OtherBenefits)")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            MessageBox.Show("Student Placement Details Recorded Successfully!")

            Me.Close()
            MainMenuForm.Show()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click

        Dim result As Integer = MessageBox.Show("Any Unsaved Data Changes Will Be Lost! Do You Want To Save & Exit?", "Save & Exit", MessageBoxButtons.YesNoCancel)

        If result = DialogResult.Cancel Then
            'Do Nothing
        ElseIf result = DialogResult.No Then
            Me.Close()
            MainMenuForm.Show()
        ElseIf result = DialogResult.Yes Then

            If StudentIdComboBox.Text = "" Or CompanyNameComboBox.Text = "" Or DesignationTextBox.Text = "" Or GrossSalaryTextBox.Text = "" Then
                MessageBox.Show("Please Fill In All The Required Fields")
            Else
                RecordPlacement(StudentIdComboBox.Text, JoiningDateDateTimePicker.Value.Date, InterviewDateDateTimePicker.Value.Date, DesignationTextBox.Text, GrossSalaryTextBox.Text, OtherBenefitsTextBox.Text)
            End If

        End If

    End Sub
End Class
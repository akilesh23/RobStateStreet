﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : PlacementsReportForm
'Description     : This class contains all the properties of PlacementsReportForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Imports Visifire.Gauges
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports Microsoft.Reporting.WinForms

Public Class PlacementsReportForm

    Private DBAccess As New DBControl

    Private Sub PlacementsReportForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub

    Private Sub PlacementsReport_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        DBAccess.ExecuteQuery("SELECT COUNT(S.StudentId) AS StudentsPlaced, C.CompanyName FROM ((Students S INNER JOIN Placements P ON P.StudentId = S.StudentId) INNER JOIN Companies C ON C.CompanyId = P.CompanyId) GROUP BY C.CompanyName")

        ReportViewer1.ProcessingMode = ProcessingMode.Local
        
        Dim datasource As New ReportDataSource("StudentPlacements", DBAccess.DBDataTable)

        ReportViewer1.LocalReport.DataSources.Clear()
        ReportViewer1.LocalReport.DataSources.Add(datasource)
        Me.ReportViewer1.RefreshReport()

        PlacementPercentageMeterLabel.Enabled = False
        ElementHost1.Enabled = False

        PlacementsReportTimer.Start()

    End Sub

    Public Sub New()
        'This call is required by the designer.
        InitializeComponent()
        CreateGauge()
    End Sub

    Private Sub CreateGauge()

        DBAccess.ExecuteQuery("SELECT (Count1/Count2)*100 AS PlacementPercentage FROM ((SELECT COUNT(*) AS Count1 FROM (SELECT DISTINCT(StudentId) FROM Placements)) AS TABLE1),((SELECT COUNT(*) AS Count2 FROM Students) AS TABLE2)")

        ' Create a gauge
        Dim gauge As New Gauge()
        gauge.Width = 300
        gauge.Height = 300

        ' Create a Needle Indicator
        Dim indicator As New NeedleIndicator()
        indicator.Value = "" & DBAccess.DBDataTable.Rows(0).Item("PlacementPercentage") & ""

        ' Add indicator to Indicators collection of gauge
        gauge.Indicators.Add(indicator)

        ' Add gauge to the LayoutRoot for display
        ElementHost1.Child = gauge

    End Sub

    Private Sub PlacementsReportTimer_Tick(sender As System.Object, e As System.EventArgs) Handles PlacementsReportTimer.Tick

        PlacementsReportTimer.Stop()

        PlacementPercentageMeterLabel.Enabled = True
        ElementHost1.Enabled = True

        CreateGauge()

    End Sub
End Class
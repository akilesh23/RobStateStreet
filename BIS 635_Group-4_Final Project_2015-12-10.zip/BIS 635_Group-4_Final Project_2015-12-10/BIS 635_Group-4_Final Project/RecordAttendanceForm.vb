﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : RecordAttendanceForm
'Description     : This class contains all the properties of RecordAttendanceForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class RecordAttendanceForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub RecordAttendanceForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        Formshown()
    End Sub

    Private Sub Formshown()

        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then

                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseNameComboBox.Items.Add(ADataRow("CourseName"))
            Next

            If DBAccess.RecordCount > 0 Then
                CourseNameComboBox.SelectedIndex = -1
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub CourseNameComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseNameComboBox.SelectionChangeCommitted

        Try

            DBAccess.ExecuteQuery("SELECT CourseId FROM OfferedCourses WHERE CourseName = '" & CourseNameComboBox.Text & "' ")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            CourseIdTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("CourseId")

            SectionNameComboBox.Items.Clear()

            DBAccess.ExecuteQuery("SELECT SectionName FROM Sections WHERE CourseId = " & CourseIdTextBox.Text & " ")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                SectionNameComboBox.Items.Add(ADataRow("SectionName"))
            Next

            If DBAccess.RecordCount > 0 Then
                SectionNameComboBox.SelectedIndex = -1
            End If

            If RecordAttendanceDataGridView.RowCount > 0 Then

                RecordAttendanceDataGridView.DataSource.clear()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub SectionNameComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles SectionNameComboBox.SelectionChangeCommitted

        Try

            DBAccess.ExecuteQuery("SELECT SectionId FROM Sections WHERE SectionName = '" & SectionNameComboBox.Text & "' ")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            SectionIdTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("SectionId")

            DBAccess.ExecuteQuery("SELECT S.StudentId, S.StudentLastName, S.StudentFirstName FROM (Students S INNER JOIN CourseEnrollment CE ON CE.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = CE.SectionId WHERE CE.SectionId = " & SectionIdTextBox.Text & " ORDER BY S.StudentId ASC")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            'Display the records on the grid
            RecordAttendanceDataGridView.DataSource = DBAccess.DBDataTable

            If RecordAttendanceDataGridView.Rows.Count = 0 Then
                MessageBox.Show("Sorry, No Student Record found for the Course and SectionId chosen!")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub SubmitButton_Click(sender As System.Object, e As System.EventArgs) Handles SubmitButton.Click
        If CourseNameComboBox.Text = "" Then
            MessageBox.Show("Please Select The Course Name First To Start With!")
        ElseIf SectionNameComboBox.Text = "" Then
            MessageBox.Show("Please Select The Section Name!")
        Else
            SubmitAttendance(SectionIdTextBox.Text, AttendanceDateTimePicker.Value.Date)
        End If
    End Sub

    Private Sub SubmitAttendance(SectionId As Integer, AttendanceDate As Date)

        Try
            If RecordAttendanceDataGridView.Rows.Count = 0 Then

                MessageBox.Show("No Records to Save!")
                Me.Close()
                MainMenuForm.Show()

            Else

                For i As Integer = 0 To RecordAttendanceDataGridView.Rows.Count - 1

                    DBAccess.AddParam("@StudentId", RecordAttendanceDataGridView.Rows(i).Cells(1).Value)
                    DBAccess.AddParam("@SectionId", SectionId)
                    DBAccess.AddParam("@AttendanceDate", AttendanceDate)
                    DBAccess.AddParam("@Present", RecordAttendanceDataGridView.Rows(i).Cells(0).Value)

                    If RecordAttendanceDataGridView.Rows(i).Cells(0).Value = False Then

                        DBAccess.ExecuteQuery("INSERT INTO Attendance(StudentId,SectionId,ClassDate) values(@StudentId,@SectionId,@AttendanceDate)")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                    Else

                        DBAccess.ExecuteQuery("INSERT INTO Attendance(StudentId,SectionId,ClassDate,Present) values(@StudentId,@SectionId,@AttendanceDate,@Present)")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                    End If
                Next

                MessageBox.Show("Today's Class Attendance Recorded Successfully")
                Me.Close()
                MainMenuForm.Show()

            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub ClearButton_Click(sender As System.Object, e As System.EventArgs) Handles ClearButton.Click

        CourseNameComboBox.Items.Clear()

        CourseIdTextBox.Clear()

        SectionNameComboBox.Items.Clear()

        SectionIdTextBox.Clear()

        If RecordAttendanceDataGridView.RowCount > 0 Then
            RecordAttendanceDataGridView.DataSource.clear()
        End If

        Formshown()

    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click

        Dim result As Integer = MessageBox.Show("Any Unsaved Data Changes Will Be Lost! Do You Want To Save & Exit?", "Save & Exit", MessageBoxButtons.YesNoCancel)
        If result = DialogResult.Cancel Then
            'Do Nothing
        ElseIf result = DialogResult.No Then
            Me.Close()
            MainMenuForm.Show()
        ElseIf result = DialogResult.Yes Then

            If RecordAttendanceDataGridView.Rows.Count = 0 Then

                MessageBox.Show("No Records to Save!")
                Me.Close()
                MainMenuForm.Show()
            Else
                SubmitAttendance(SectionIdTextBox.Text, AttendanceDateTimePicker.Text)
            End If

        End If

    End Sub



End Class
﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : AttendanceReportForm
'Description     : This class contains all the properties of AttendanceReportForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Imports Visifire.Charts
Imports System.Windows.Input
Imports System.Windows.Media

Public Class AttendanceReportForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub AttendanceReportForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub


    Private Sub AttendanceReportForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        Try

            DBAccess.ExecuteQuery("SELECT SectionName FROM Sections")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                SectionNameComboBox.Items.Add(ADataRow("SectionName"))
            Next

            If DBAccess.RecordCount > 0 Then
                SectionNameComboBox.SelectedIndex = -1
            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub CheckButton_Click(sender As System.Object, e As System.EventArgs) Handles CheckButton.Click
        Try

            DBAccess.ExecuteQuery("SELECT S.StudentId, S.StudentLastName, S.StudentFirstName, A.Present FROM (Students S INNER JOIN Attendance A ON A.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = A.SectionId WHERE (A.ClassDate LIKE '" & AttendanceReportDateTimePicker.Value.Date & "' AND A.SectionId = (Select SectionId FROM Sections WHERE SectionName = '" & SectionNameComboBox.Text & "'))")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If


            If DBAccess.RecordCount = 0 Then
                MessageBox.Show("Sorry, No Student Record found for the Section Name and Date chosen!")
            End If

            AttendanceReportDataGridView.DataSource = DBAccess.DBDataTable

            'TotalPresentCount/TotalStrengthCount
            TotalStrengthCountTextBox.Text = DBAccess.RecordCount

            DBAccess.ExecuteQuery("SELECT COUNT(A.Present) AS TotalPresentCount FROM (Students S INNER JOIN Attendance A ON A.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = A.SectionId WHERE (A.ClassDate LIKE '" & AttendanceReportDateTimePicker.Value.Date & "' AND A.Present = True AND A.SectionId = (Select SectionId FROM Sections WHERE SectionName = '" & SectionNameComboBox.Text & "'))")

            TotalPresentCountTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("TotalPresentCount")

        Catch ex As Exception

        End Try
    End Sub

    Private chart As Chart
    ' Chart object
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
    End Sub


    Private Sub PublishReport_Click(sender As System.Object, e As System.EventArgs) Handles PublishReportButton.Click

        DBAccess.ExecuteQuery("SELECT TABLE1.A.ClassDate, TABLE1.Present, TABLE2.Total, (TABLE1.Present/TABLE2.Total * 100) AS AttendancePercentage FROM ((SELECT A.ClassDate, COUNT(A.Present) AS Present FROM (Students S INNER JOIN Attendance A ON A.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = A.SectionId WHERE((A.ClassDate BETWEEN #" & FromDateTimePicker.Value.Date & "# AND #" & ToDateTimePicker.Value.Date & "#) AND A.Present = True AND A.SectionId = (Select SectionId FROM Sections WHERE SectionName = '" & SectionNameComboBox.Text & "')) GROUP BY A.ClassDate) AS TABLE1 INNER JOIN (SELECT A.ClassDate, COUNT(S.StudentId) AS Total FROM (Students S INNER JOIN Attendance A ON A.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = A.SectionId WHERE ((A.ClassDate BETWEEN #" & FromDateTimePicker.Value.Date & "# AND #" & ToDateTimePicker.Value.Date & "#) AND A.SectionId = (Select SectionId FROM Sections WHERE SectionName = '" & SectionNameComboBox.Text & "')) GROUP BY A.ClassDate) AS TABLE2 ON TABLE1.A.ClassDate = TABLE2.A.ClassDate)")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        CreateChart()

    End Sub

    Public Sub CreateChart()
        ' Create a new instance of Chart
        chart = New Chart()

        ' Create a new instance of Title
        Dim title As New Title()

        ' Set title property
        title.Text = "Attendance Report - YES"

        ' Add title to Titles collection
        chart.Titles.Add(title)

        ' Create a new instance of DataSeries
        Dim dataSeries As New DataSeries()

        ' Set DataSeries property
        dataSeries.RenderAs = RenderAs.Column

        ' Create a DataPoint
        Dim dataPoint As DataPoint

        For i As Integer = 0 To DBAccess.DBDataTable.Rows.Count - 1
            ' Create a new instance of DataPoint
            dataPoint = New DataPoint()

            ' Set YValue for a DataPoint
            dataPoint.YValue = "" & DBAccess.DBDataTable.Rows(i).Item("AttendancePercentage") & ""

            dataPoint.XValue = "" & DBAccess.DBDataTable.Rows(i).Item("ClassDate") & ""

            ' Add dataPoint to DataPoints collection
            dataSeries.DataPoints.Add(dataPoint)
        Next

        ' Add dataSeries to Series collection
        chart.Series.Add(dataSeries)

        ' Add chart to LayoutRoot
        AttendanceReportChartElementHost.Child = chart

    End Sub

    Private Sub CloseButton_Click(sender As System.Object, e As System.EventArgs) Handles CloseButton.Click
        Me.Close()
        MainMenuForm.Show()
    End Sub

    Private Sub SectionNameComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles SectionNameComboBox.SelectionChangeCommitted

        If AttendanceReportDataGridView.RowCount > 0 Then
            AttendanceReportDataGridView.DataSource.Clear()
        End If

        AttendanceReportChartElementHost.Child = Nothing

    End Sub

End Class
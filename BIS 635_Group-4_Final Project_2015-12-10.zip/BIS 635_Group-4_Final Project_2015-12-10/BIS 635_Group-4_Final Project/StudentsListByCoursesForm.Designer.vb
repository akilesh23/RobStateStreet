﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentsListByCoursesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CourseNameLabel = New System.Windows.Forms.Label()
        Me.CourseNameComboBox = New System.Windows.Forms.ComboBox()
        Me.StudentsDataGridView = New System.Windows.Forms.DataGridView()
        Me.StudentsListLabel = New System.Windows.Forms.Label()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.EmailStudentsListToClientButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CourseNameLabel
        '
        Me.CourseNameLabel.AutoSize = True
        Me.CourseNameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CourseNameLabel.Location = New System.Drawing.Point(20, 40)
        Me.CourseNameLabel.Name = "CourseNameLabel"
        Me.CourseNameLabel.Size = New System.Drawing.Size(133, 24)
        Me.CourseNameLabel.TabIndex = 4
        Me.CourseNameLabel.Text = "Select Course:"
        '
        'CourseNameComboBox
        '
        Me.CourseNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CourseNameComboBox.FormattingEnabled = True
        Me.CourseNameComboBox.Location = New System.Drawing.Point(24, 74)
        Me.CourseNameComboBox.Name = "CourseNameComboBox"
        Me.CourseNameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.CourseNameComboBox.TabIndex = 3
        '
        'StudentsDataGridView
        '
        Me.StudentsDataGridView.AllowUserToAddRows = False
        Me.StudentsDataGridView.AllowUserToDeleteRows = False
        Me.StudentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.StudentsDataGridView.Location = New System.Drawing.Point(24, 117)
        Me.StudentsDataGridView.Name = "StudentsDataGridView"
        Me.StudentsDataGridView.ReadOnly = True
        Me.StudentsDataGridView.Size = New System.Drawing.Size(912, 277)
        Me.StudentsDataGridView.TabIndex = 5
        '
        'StudentsListLabel
        '
        Me.StudentsListLabel.AutoSize = True
        Me.StudentsListLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsListLabel.Location = New System.Drawing.Point(407, 71)
        Me.StudentsListLabel.Name = "StudentsListLabel"
        Me.StudentsListLabel.Size = New System.Drawing.Size(135, 24)
        Me.StudentsListLabel.TabIndex = 6
        Me.StudentsListLabel.Text = "List of Students"
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(440, 424)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(75, 23)
        Me.CloseButton.TabIndex = 7
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'EmailStudentsListToClientButton
        '
        Me.EmailStudentsListToClientButton.Location = New System.Drawing.Point(830, 40)
        Me.EmailStudentsListToClientButton.Name = "EmailStudentsListToClientButton"
        Me.EmailStudentsListToClientButton.Size = New System.Drawing.Size(106, 55)
        Me.EmailStudentsListToClientButton.TabIndex = 9
        Me.EmailStudentsListToClientButton.Text = "Email Students List To Client"
        Me.EmailStudentsListToClientButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 450)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(802, 450)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StudentsListByCoursesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 474)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.EmailStudentsListToClientButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.StudentsListLabel)
        Me.Controls.Add(Me.StudentsDataGridView)
        Me.Controls.Add(Me.CourseNameLabel)
        Me.Controls.Add(Me.CourseNameComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "StudentsListByCoursesForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "List Of Students By Courses"
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CourseNameLabel As System.Windows.Forms.Label
    Friend WithEvents CourseNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StudentsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents StudentsListLabel As System.Windows.Forms.Label
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents EmailStudentsListToClientButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class

﻿'************************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'------------------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : DBControl
'Description     : This class directly controls all the Database Transactions with MS Access Database.
'Project Manager : Dr. Zhenyu Huang
'************************************************************************************************************

Imports System.Data
Imports System.Data.OleDb


Public Class DBControl

    'create DB connection 
    Private ConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\YES_v3.0.mdb"
    Public DBConnection As New OleDbConnection(ConnectionString)

    'prepare DB command. database command  
    Private DBCommand As OleDbCommand

    'DB Data. make them public as they need to be accessed from presentation tier.  
    Public DBDataAdapter As OleDbDataAdapter
    Public DBDataTable As DataTable

    'Query parameters. Parameters are important for queries. use a list collection to keep paramters.  
    'Please check your database text about adding parameters into SQL Queries
    Public Params As New List(Of OleDbParameter)

    'it is important to save query statistics.  
    'Query Statistics 
    Public RecordCount As Integer
    Public Exception As String 'when query runs into error/exception. This Public variable will carry the exception from this data tier to presentation tier 

    'Create a general procedure to execute queries to a database. Query is an argument to pass SQL Strings.  
    Public Sub ExecuteQuery(Query As String)

        'Reset Query Stats 
        RecordCount = 0
        Exception = String.Empty

        Try

            'Open a database connection 
            DBConnection.Open()

            'create Database Command 
            DBCommand = New OleDbCommand(Query, DBConnection)

            'load parameters into DB command. the following syntax is supported by Visual Basic 2010 or later.  
            Params.ForEach(Sub(p) DBCommand.Parameters.Add(p))

            'clear parameter list as each time query parameters could be different 
            Params.Clear()

            'execute command & Fill datatable 
            DBDataTable = New DataTable
            DBDataAdapter = New OleDbDataAdapter(DBCommand)

            RecordCount = DBDataAdapter.Fill(DBDataTable) 'all query result will be loaded into the data table.

        Catch ex As Exception

            Exception = ex.Message 'The presentation tier can use an If statement on Exception variable to see if any error happens. If you use Throw Ex, then the presentation tier has to use Try...Catch block to capture the exception. Both methods will work.
            MessageBox.Show(Exception)
        End Try
        'close db connection 
        If DBConnection.State = ConnectionState.Open Then DBConnection.Close()

    End Sub

    'Include Query & Command Parameters 
    'The above general Query Execution Procedure has not place to take query parameter 
    'the following procedure will accept parameters for queries.  
    Public Sub AddParam(Name As String, Value As Object)
        'argument value is object type to be open for any possible types of value, such as String, Integer, Font, Image etc.  
        Dim NewParam As New OleDbParameter(Name, Value)
        Params.Add(NewParam)
    End Sub

End Class

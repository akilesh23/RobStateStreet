﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenuForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.StudentsDataGridView = New System.Windows.Forms.DataGridView()
        Me.StudentSearchTextBox = New System.Windows.Forms.TextBox()
        Me.StudentSearchLabel = New System.Windows.Forms.Label()
        Me.NewRegistrationButton = New System.Windows.Forms.Button()
        Me.EditDetailsButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.LogoutButton = New System.Windows.Forms.Button()
        Me.RecordAttendanceButton = New System.Windows.Forms.Button()
        Me.AddOrDropCoursesButton = New System.Windows.Forms.Button()
        Me.AttendanceReportButton = New System.Windows.Forms.Button()
        Me.RecordPlacementButton = New System.Windows.Forms.Button()
        Me.StudentPlacementsReportButton = New System.Windows.Forms.Button()
        Me.AttendanceGroupBox = New System.Windows.Forms.GroupBox()
        Me.StudentRecordsGroupBox = New System.Windows.Forms.GroupBox()
        Me.PlacementsGroupBox = New System.Windows.Forms.GroupBox()
        Me.CoursesGroupBox = New System.Windows.Forms.GroupBox()
        Me.StudentsListByCoursesButton = New System.Windows.Forms.Button()
        Me.StudentsListLabel = New System.Windows.Forms.Label()
        Me.QuitGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AttendanceGroupBox.SuspendLayout()
        Me.StudentRecordsGroupBox.SuspendLayout()
        Me.PlacementsGroupBox.SuspendLayout()
        Me.CoursesGroupBox.SuspendLayout()
        Me.QuitGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'StudentsDataGridView
        '
        Me.StudentsDataGridView.AllowUserToAddRows = False
        Me.StudentsDataGridView.AllowUserToDeleteRows = False
        Me.StudentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.StudentsDataGridView.Location = New System.Drawing.Point(71, 166)
        Me.StudentsDataGridView.Name = "StudentsDataGridView"
        Me.StudentsDataGridView.ReadOnly = True
        Me.StudentsDataGridView.Size = New System.Drawing.Size(1005, 411)
        Me.StudentsDataGridView.TabIndex = 1
        '
        'StudentSearchTextBox
        '
        Me.StudentSearchTextBox.Location = New System.Drawing.Point(893, 134)
        Me.StudentSearchTextBox.Name = "StudentSearchTextBox"
        Me.StudentSearchTextBox.Size = New System.Drawing.Size(183, 20)
        Me.StudentSearchTextBox.TabIndex = 2
        '
        'StudentSearchLabel
        '
        Me.StudentSearchLabel.AutoSize = True
        Me.StudentSearchLabel.Location = New System.Drawing.Point(757, 137)
        Me.StudentSearchLabel.Name = "StudentSearchLabel"
        Me.StudentSearchLabel.Size = New System.Drawing.Size(130, 13)
        Me.StudentSearchLabel.TabIndex = 3
        Me.StudentSearchLabel.Text = "Search By Student Name:"
        '
        'NewRegistrationButton
        '
        Me.NewRegistrationButton.Location = New System.Drawing.Point(32, 25)
        Me.NewRegistrationButton.Name = "NewRegistrationButton"
        Me.NewRegistrationButton.Size = New System.Drawing.Size(109, 23)
        Me.NewRegistrationButton.TabIndex = 6
        Me.NewRegistrationButton.Text = "New Registration"
        Me.NewRegistrationButton.UseVisualStyleBackColor = True
        '
        'EditDetailsButton
        '
        Me.EditDetailsButton.Location = New System.Drawing.Point(32, 64)
        Me.EditDetailsButton.Name = "EditDetailsButton"
        Me.EditDetailsButton.Size = New System.Drawing.Size(109, 23)
        Me.EditDetailsButton.TabIndex = 7
        Me.EditDetailsButton.Text = "Edit Details"
        Me.EditDetailsButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(31, 69)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(109, 23)
        Me.ExitButton.TabIndex = 8
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'LogoutButton
        '
        Me.LogoutButton.Location = New System.Drawing.Point(31, 25)
        Me.LogoutButton.Name = "LogoutButton"
        Me.LogoutButton.Size = New System.Drawing.Size(109, 23)
        Me.LogoutButton.TabIndex = 9
        Me.LogoutButton.Text = "Logout"
        Me.LogoutButton.UseVisualStyleBackColor = True
        '
        'RecordAttendanceButton
        '
        Me.RecordAttendanceButton.Location = New System.Drawing.Point(32, 21)
        Me.RecordAttendanceButton.Name = "RecordAttendanceButton"
        Me.RecordAttendanceButton.Size = New System.Drawing.Size(109, 23)
        Me.RecordAttendanceButton.TabIndex = 10
        Me.RecordAttendanceButton.Text = "Record Attendance"
        Me.RecordAttendanceButton.UseVisualStyleBackColor = True
        '
        'AddOrDropCoursesButton
        '
        Me.AddOrDropCoursesButton.Location = New System.Drawing.Point(33, 25)
        Me.AddOrDropCoursesButton.Name = "AddOrDropCoursesButton"
        Me.AddOrDropCoursesButton.Size = New System.Drawing.Size(109, 23)
        Me.AddOrDropCoursesButton.TabIndex = 11
        Me.AddOrDropCoursesButton.Text = "Add/Drop Courses"
        Me.AddOrDropCoursesButton.UseVisualStyleBackColor = True
        '
        'AttendanceReportButton
        '
        Me.AttendanceReportButton.Location = New System.Drawing.Point(32, 63)
        Me.AttendanceReportButton.Name = "AttendanceReportButton"
        Me.AttendanceReportButton.Size = New System.Drawing.Size(109, 23)
        Me.AttendanceReportButton.TabIndex = 12
        Me.AttendanceReportButton.Text = "Attendance Report"
        Me.AttendanceReportButton.UseVisualStyleBackColor = True
        '
        'RecordPlacementButton
        '
        Me.RecordPlacementButton.Location = New System.Drawing.Point(27, 21)
        Me.RecordPlacementButton.Name = "RecordPlacementButton"
        Me.RecordPlacementButton.Size = New System.Drawing.Size(109, 23)
        Me.RecordPlacementButton.TabIndex = 14
        Me.RecordPlacementButton.Text = "Record Placement"
        Me.RecordPlacementButton.UseVisualStyleBackColor = True
        '
        'StudentPlacementsReportButton
        '
        Me.StudentPlacementsReportButton.Location = New System.Drawing.Point(27, 58)
        Me.StudentPlacementsReportButton.Name = "StudentPlacementsReportButton"
        Me.StudentPlacementsReportButton.Size = New System.Drawing.Size(109, 34)
        Me.StudentPlacementsReportButton.TabIndex = 15
        Me.StudentPlacementsReportButton.Text = "Student Placements Report"
        Me.StudentPlacementsReportButton.UseVisualStyleBackColor = True
        '
        'AttendanceGroupBox
        '
        Me.AttendanceGroupBox.Controls.Add(Me.RecordAttendanceButton)
        Me.AttendanceGroupBox.Controls.Add(Me.AttendanceReportButton)
        Me.AttendanceGroupBox.Location = New System.Drawing.Point(279, 12)
        Me.AttendanceGroupBox.Name = "AttendanceGroupBox"
        Me.AttendanceGroupBox.Size = New System.Drawing.Size(172, 102)
        Me.AttendanceGroupBox.TabIndex = 17
        Me.AttendanceGroupBox.TabStop = False
        Me.AttendanceGroupBox.Text = "Attendance"
        '
        'StudentRecordsGroupBox
        '
        Me.StudentRecordsGroupBox.Controls.Add(Me.NewRegistrationButton)
        Me.StudentRecordsGroupBox.Controls.Add(Me.EditDetailsButton)
        Me.StudentRecordsGroupBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentRecordsGroupBox.Location = New System.Drawing.Point(71, 12)
        Me.StudentRecordsGroupBox.Name = "StudentRecordsGroupBox"
        Me.StudentRecordsGroupBox.Size = New System.Drawing.Size(172, 102)
        Me.StudentRecordsGroupBox.TabIndex = 18
        Me.StudentRecordsGroupBox.TabStop = False
        Me.StudentRecordsGroupBox.Text = "Student Records"
        '
        'PlacementsGroupBox
        '
        Me.PlacementsGroupBox.Controls.Add(Me.RecordPlacementButton)
        Me.PlacementsGroupBox.Controls.Add(Me.StudentPlacementsReportButton)
        Me.PlacementsGroupBox.Location = New System.Drawing.Point(489, 12)
        Me.PlacementsGroupBox.Name = "PlacementsGroupBox"
        Me.PlacementsGroupBox.Size = New System.Drawing.Size(172, 102)
        Me.PlacementsGroupBox.TabIndex = 18
        Me.PlacementsGroupBox.TabStop = False
        Me.PlacementsGroupBox.Text = "Placements"
        '
        'CoursesGroupBox
        '
        Me.CoursesGroupBox.Controls.Add(Me.StudentsListByCoursesButton)
        Me.CoursesGroupBox.Controls.Add(Me.AddOrDropCoursesButton)
        Me.CoursesGroupBox.Location = New System.Drawing.Point(699, 12)
        Me.CoursesGroupBox.Name = "CoursesGroupBox"
        Me.CoursesGroupBox.Size = New System.Drawing.Size(172, 102)
        Me.CoursesGroupBox.TabIndex = 18
        Me.CoursesGroupBox.TabStop = False
        Me.CoursesGroupBox.Text = "Courses"
        '
        'StudentsListByCoursesButton
        '
        Me.StudentsListByCoursesButton.Location = New System.Drawing.Point(33, 57)
        Me.StudentsListByCoursesButton.Name = "StudentsListByCoursesButton"
        Me.StudentsListByCoursesButton.Size = New System.Drawing.Size(109, 34)
        Me.StudentsListByCoursesButton.TabIndex = 12
        Me.StudentsListByCoursesButton.Text = "Students List By Courses"
        Me.StudentsListByCoursesButton.UseVisualStyleBackColor = True
        '
        'StudentsListLabel
        '
        Me.StudentsListLabel.AutoSize = True
        Me.StudentsListLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsListLabel.Location = New System.Drawing.Point(506, 128)
        Me.StudentsListLabel.Name = "StudentsListLabel"
        Me.StudentsListLabel.Size = New System.Drawing.Size(138, 25)
        Me.StudentsListLabel.TabIndex = 19
        Me.StudentsListLabel.Text = "Students List"
        '
        'QuitGroupBox
        '
        Me.QuitGroupBox.Controls.Add(Me.LogoutButton)
        Me.QuitGroupBox.Controls.Add(Me.ExitButton)
        Me.QuitGroupBox.Location = New System.Drawing.Point(904, 12)
        Me.QuitGroupBox.Name = "QuitGroupBox"
        Me.QuitGroupBox.Size = New System.Drawing.Size(172, 102)
        Me.QuitGroupBox.TabIndex = 19
        Me.QuitGroupBox.TabStop = False
        Me.QuitGroupBox.Text = "Quit"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 592)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 60
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(994, 592)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 61
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MainMenuForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1150, 612)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.QuitGroupBox)
        Me.Controls.Add(Me.StudentsListLabel)
        Me.Controls.Add(Me.CoursesGroupBox)
        Me.Controls.Add(Me.PlacementsGroupBox)
        Me.Controls.Add(Me.StudentRecordsGroupBox)
        Me.Controls.Add(Me.AttendanceGroupBox)
        Me.Controls.Add(Me.StudentSearchLabel)
        Me.Controls.Add(Me.StudentSearchTextBox)
        Me.Controls.Add(Me.StudentsDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MainMenuForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Youth Empowerment Society"
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AttendanceGroupBox.ResumeLayout(False)
        Me.StudentRecordsGroupBox.ResumeLayout(False)
        Me.PlacementsGroupBox.ResumeLayout(False)
        Me.CoursesGroupBox.ResumeLayout(False)
        Me.QuitGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StudentsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents StudentSearchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentSearchLabel As System.Windows.Forms.Label
    Friend WithEvents NewRegistrationButton As System.Windows.Forms.Button
    Friend WithEvents EditDetailsButton As System.Windows.Forms.Button
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents LogoutButton As System.Windows.Forms.Button
    Friend WithEvents RecordAttendanceButton As System.Windows.Forms.Button
    Friend WithEvents AddOrDropCoursesButton As System.Windows.Forms.Button
    Friend WithEvents AttendanceReportButton As System.Windows.Forms.Button
    Friend WithEvents RecordPlacementButton As System.Windows.Forms.Button
    Friend WithEvents StudentPlacementsReportButton As System.Windows.Forms.Button
    Friend WithEvents AttendanceGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents StudentRecordsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents PlacementsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents CoursesGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents StudentsListByCoursesButton As System.Windows.Forms.Button
    Friend WithEvents StudentsListLabel As System.Windows.Forms.Label
    Friend WithEvents QuitGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class

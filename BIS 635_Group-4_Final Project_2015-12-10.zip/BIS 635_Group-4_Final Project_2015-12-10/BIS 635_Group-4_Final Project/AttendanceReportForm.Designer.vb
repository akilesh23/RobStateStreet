﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AttendanceReportForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SectionNameComboBox = New System.Windows.Forms.ComboBox()
        Me.SectionNameLabel = New System.Windows.Forms.Label()
        Me.AttendanceReportDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.AttendanceReportDataGridView = New System.Windows.Forms.DataGridView()
        Me.StudentIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentLastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentFirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PresentDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TotalPresentCountLabel = New System.Windows.Forms.Label()
        Me.TotalStrengthCountLabel = New System.Windows.Forms.Label()
        Me.SlashLabel = New System.Windows.Forms.Label()
        Me.TotalPresentCountTextBox = New System.Windows.Forms.TextBox()
        Me.TotalStrengthCountTextBox = New System.Windows.Forms.TextBox()
        Me.FromDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ToDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PublishReportButton = New System.Windows.Forms.Button()
        Me.FromLabel = New System.Windows.Forms.Label()
        Me.ToLabel = New System.Windows.Forms.Label()
        Me.AttendanceReportChartElementHost = New System.Windows.Forms.Integration.ElementHost()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.CheckButton = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.AttendanceReportDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SectionNameComboBox
        '
        Me.SectionNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SectionNameComboBox.FormattingEnabled = True
        Me.SectionNameComboBox.Location = New System.Drawing.Point(589, 33)
        Me.SectionNameComboBox.Name = "SectionNameComboBox"
        Me.SectionNameComboBox.Size = New System.Drawing.Size(227, 21)
        Me.SectionNameComboBox.TabIndex = 30
        '
        'SectionNameLabel
        '
        Me.SectionNameLabel.AutoSize = True
        Me.SectionNameLabel.Location = New System.Drawing.Point(489, 36)
        Me.SectionNameLabel.Name = "SectionNameLabel"
        Me.SectionNameLabel.Size = New System.Drawing.Size(77, 13)
        Me.SectionNameLabel.TabIndex = 31
        Me.SectionNameLabel.Text = "Section Name:"
        '
        'AttendanceReportDateTimePicker
        '
        Me.AttendanceReportDateTimePicker.Location = New System.Drawing.Point(52, 101)
        Me.AttendanceReportDateTimePicker.Name = "AttendanceReportDateTimePicker"
        Me.AttendanceReportDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.AttendanceReportDateTimePicker.TabIndex = 32
        '
        'AttendanceReportDataGridView
        '
        Me.AttendanceReportDataGridView.AllowUserToAddRows = False
        Me.AttendanceReportDataGridView.AllowUserToDeleteRows = False
        Me.AttendanceReportDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.AttendanceReportDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudentIdDataGridViewTextBoxColumn, Me.StudentLastNameDataGridViewTextBoxColumn, Me.StudentFirstNameDataGridViewTextBoxColumn, Me.PresentDataGridViewCheckBoxColumn})
        Me.AttendanceReportDataGridView.Location = New System.Drawing.Point(52, 155)
        Me.AttendanceReportDataGridView.Name = "AttendanceReportDataGridView"
        Me.AttendanceReportDataGridView.ReadOnly = True
        Me.AttendanceReportDataGridView.Size = New System.Drawing.Size(445, 408)
        Me.AttendanceReportDataGridView.TabIndex = 33
        '
        'StudentIdDataGridViewTextBoxColumn
        '
        Me.StudentIdDataGridViewTextBoxColumn.DataPropertyName = "StudentId"
        Me.StudentIdDataGridViewTextBoxColumn.HeaderText = "Student ID"
        Me.StudentIdDataGridViewTextBoxColumn.Name = "StudentIdDataGridViewTextBoxColumn"
        Me.StudentIdDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StudentLastNameDataGridViewTextBoxColumn
        '
        Me.StudentLastNameDataGridViewTextBoxColumn.DataPropertyName = "StudentLastName"
        Me.StudentLastNameDataGridViewTextBoxColumn.HeaderText = "Student Last Name"
        Me.StudentLastNameDataGridViewTextBoxColumn.Name = "StudentLastNameDataGridViewTextBoxColumn"
        Me.StudentLastNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StudentFirstNameDataGridViewTextBoxColumn
        '
        Me.StudentFirstNameDataGridViewTextBoxColumn.DataPropertyName = "StudentFirstName"
        Me.StudentFirstNameDataGridViewTextBoxColumn.HeaderText = "Student First Name"
        Me.StudentFirstNameDataGridViewTextBoxColumn.Name = "StudentFirstNameDataGridViewTextBoxColumn"
        Me.StudentFirstNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PresentDataGridViewCheckBoxColumn
        '
        Me.PresentDataGridViewCheckBoxColumn.DataPropertyName = "Present"
        Me.PresentDataGridViewCheckBoxColumn.HeaderText = "Was the Student Present?"
        Me.PresentDataGridViewCheckBoxColumn.Name = "PresentDataGridViewCheckBoxColumn"
        Me.PresentDataGridViewCheckBoxColumn.ReadOnly = True
        '
        'TotalPresentCountLabel
        '
        Me.TotalPresentCountLabel.AutoSize = True
        Me.TotalPresentCountLabel.Location = New System.Drawing.Point(277, 105)
        Me.TotalPresentCountLabel.Name = "TotalPresentCountLabel"
        Me.TotalPresentCountLabel.Size = New System.Drawing.Size(80, 13)
        Me.TotalPresentCountLabel.TabIndex = 34
        Me.TotalPresentCountLabel.Text = "No. Of Present:"
        '
        'TotalStrengthCountLabel
        '
        Me.TotalStrengthCountLabel.AutoSize = True
        Me.TotalStrengthCountLabel.Location = New System.Drawing.Point(381, 105)
        Me.TotalStrengthCountLabel.Name = "TotalStrengthCountLabel"
        Me.TotalStrengthCountLabel.Size = New System.Drawing.Size(116, 13)
        Me.TotalStrengthCountLabel.TabIndex = 35
        Me.TotalStrengthCountLabel.Text = "Total Section Strength:"
        '
        'SlashLabel
        '
        Me.SlashLabel.AutoSize = True
        Me.SlashLabel.Location = New System.Drawing.Point(363, 105)
        Me.SlashLabel.Name = "SlashLabel"
        Me.SlashLabel.Size = New System.Drawing.Size(12, 13)
        Me.SlashLabel.TabIndex = 36
        Me.SlashLabel.Text = "/"
        '
        'TotalPresentCountTextBox
        '
        Me.TotalPresentCountTextBox.Location = New System.Drawing.Point(302, 128)
        Me.TotalPresentCountTextBox.Name = "TotalPresentCountTextBox"
        Me.TotalPresentCountTextBox.ReadOnly = True
        Me.TotalPresentCountTextBox.Size = New System.Drawing.Size(32, 20)
        Me.TotalPresentCountTextBox.TabIndex = 37
        '
        'TotalStrengthCountTextBox
        '
        Me.TotalStrengthCountTextBox.Location = New System.Drawing.Point(421, 128)
        Me.TotalStrengthCountTextBox.Name = "TotalStrengthCountTextBox"
        Me.TotalStrengthCountTextBox.ReadOnly = True
        Me.TotalStrengthCountTextBox.Size = New System.Drawing.Size(31, 20)
        Me.TotalStrengthCountTextBox.TabIndex = 38
        '
        'FromDateTimePicker
        '
        Me.FromDateTimePicker.Location = New System.Drawing.Point(580, 119)
        Me.FromDateTimePicker.Name = "FromDateTimePicker"
        Me.FromDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.FromDateTimePicker.TabIndex = 40
        '
        'ToDateTimePicker
        '
        Me.ToDateTimePicker.Location = New System.Drawing.Point(867, 120)
        Me.ToDateTimePicker.Name = "ToDateTimePicker"
        Me.ToDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.ToDateTimePicker.TabIndex = 41
        '
        'PublishReportButton
        '
        Me.PublishReportButton.Location = New System.Drawing.Point(1134, 111)
        Me.PublishReportButton.Name = "PublishReportButton"
        Me.PublishReportButton.Size = New System.Drawing.Size(79, 42)
        Me.PublishReportButton.TabIndex = 42
        Me.PublishReportButton.Text = "Publish Report"
        Me.PublishReportButton.UseVisualStyleBackColor = True
        '
        'FromLabel
        '
        Me.FromLabel.AutoSize = True
        Me.FromLabel.Location = New System.Drawing.Point(541, 125)
        Me.FromLabel.Name = "FromLabel"
        Me.FromLabel.Size = New System.Drawing.Size(33, 13)
        Me.FromLabel.TabIndex = 43
        Me.FromLabel.Text = "From:"
        '
        'ToLabel
        '
        Me.ToLabel.AutoSize = True
        Me.ToLabel.Location = New System.Drawing.Point(838, 126)
        Me.ToLabel.Name = "ToLabel"
        Me.ToLabel.Size = New System.Drawing.Size(23, 13)
        Me.ToLabel.TabIndex = 44
        Me.ToLabel.Text = "To:"
        '
        'AttendanceReportChartElementHost
        '
        Me.AttendanceReportChartElementHost.Location = New System.Drawing.Point(515, 156)
        Me.AttendanceReportChartElementHost.Name = "AttendanceReportChartElementHost"
        Me.AttendanceReportChartElementHost.Size = New System.Drawing.Size(698, 407)
        Me.AttendanceReportChartElementHost.TabIndex = 45
        Me.AttendanceReportChartElementHost.Text = "Attendance Report"
        Me.AttendanceReportChartElementHost.Child = Nothing
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(597, 586)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(75, 23)
        Me.CloseButton.TabIndex = 46
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'CheckButton
        '
        Me.CheckButton.Location = New System.Drawing.Point(52, 126)
        Me.CheckButton.Name = "CheckButton"
        Me.CheckButton.Size = New System.Drawing.Size(75, 23)
        Me.CheckButton.TabIndex = 47
        Me.CheckButton.Text = "Check"
        Me.CheckButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(1113, 607)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 54
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 607)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 55
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AttendanceReportForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1269, 631)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CheckButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.AttendanceReportChartElementHost)
        Me.Controls.Add(Me.ToLabel)
        Me.Controls.Add(Me.FromLabel)
        Me.Controls.Add(Me.PublishReportButton)
        Me.Controls.Add(Me.ToDateTimePicker)
        Me.Controls.Add(Me.FromDateTimePicker)
        Me.Controls.Add(Me.TotalStrengthCountTextBox)
        Me.Controls.Add(Me.TotalPresentCountTextBox)
        Me.Controls.Add(Me.SlashLabel)
        Me.Controls.Add(Me.TotalStrengthCountLabel)
        Me.Controls.Add(Me.TotalPresentCountLabel)
        Me.Controls.Add(Me.AttendanceReportDataGridView)
        Me.Controls.Add(Me.AttendanceReportDateTimePicker)
        Me.Controls.Add(Me.SectionNameLabel)
        Me.Controls.Add(Me.SectionNameComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AttendanceReportForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Attendance Report"
        CType(Me.AttendanceReportDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SectionNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents SectionNameLabel As System.Windows.Forms.Label
    Friend WithEvents AttendanceReportDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents AttendanceReportDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TotalPresentCountLabel As System.Windows.Forms.Label
    Friend WithEvents TotalStrengthCountLabel As System.Windows.Forms.Label
    Friend WithEvents SlashLabel As System.Windows.Forms.Label
    Friend WithEvents TotalPresentCountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TotalStrengthCountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FromDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ToDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents PublishReportButton As System.Windows.Forms.Button
    Friend WithEvents FromLabel As System.Windows.Forms.Label
    Friend WithEvents ToLabel As System.Windows.Forms.Label
    Friend WithEvents AttendanceReportChartElementHost As System.Windows.Forms.Integration.ElementHost
    Friend WithEvents StudentIdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentLastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentFirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PresentDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents CheckButton As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class

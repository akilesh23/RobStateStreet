﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : MainMenuForm
'Description     : This class contains all the properties of MainMenuForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class MainMenuForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub MainMenuForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        LoginForm.Show()
    End Sub

    Private Sub MainMenuForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        StudentsDataGridView.ReadOnly = True
    End Sub

    Private Sub MainMenuForm_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        Try

            DBAccess.ExecuteQuery("SELECT * FROM Students")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            StudentsDataGridView.DataSource = DBAccess.DBDataTable

            StudentsDataGridView.Columns(12).HeaderCell.Value = "LastUpdatedBy"

            StudentsDataGridView.Refresh()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub StudentSearchTextBox_TextChanged(sender As Object, e As System.EventArgs) Handles StudentSearchTextBox.TextChanged

        StudentSearch(StudentSearchTextBox.Text)

    End Sub

    Private Sub StudentSearch(StudentFirstOrLastName As String)

        DBAccess.ExecuteQuery("SELECT * FROM Students WHERE StudentLastName LIKE '%" & StudentFirstOrLastName & "%' " & " OR StudentFirstName LIKE '%" & StudentFirstOrLastName & "%'")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        StudentsDataGridView.DataSource = DBAccess.DBDataTable

    End Sub

    Private Sub NewRegistrationButton_Click(sender As System.Object, e As System.EventArgs) Handles NewRegistrationButton.Click
        StudentRegistrationForm.Show()
    End Sub

    Private Sub EditDetailsButton_Click(sender As System.Object, e As System.EventArgs) Handles EditDetailsButton.Click

        StudentRegistrationForm.SaveButton.Text = "Update"

        StudentRegistrationForm.Show()

        StudentRegistrationForm.StudentIdTextBox.Text = StudentsDataGridView.CurrentRow.Cells(0).Value.ToString()
        StudentRegistrationForm.StudentLastNameTextBox.Text = StudentsDataGridView.CurrentRow.Cells(1).Value.ToString()
        StudentRegistrationForm.StudentFirstNameTextBox.Text = StudentsDataGridView.CurrentRow.Cells(2).Value.ToString()
        StudentRegistrationForm.StudentDobDateTimePicker.Text = StudentsDataGridView.CurrentRow.Cells(3).Value.ToString()
        StudentRegistrationForm.StudentGenderComboBox.Text = StudentsDataGridView.CurrentRow.Cells(4).Value.ToString()
        StudentRegistrationForm.MaritalStatusComboBox.Text = StudentsDataGridView.CurrentRow.Cells(5).Value.ToString()
        StudentRegistrationForm.AddressLineTextBox.Text = StudentsDataGridView.CurrentRow.Cells(6).Value.ToString()
        StudentRegistrationForm.CityTextBox.Text = StudentsDataGridView.CurrentRow.Cells(7).Value.ToString()
        StudentRegistrationForm.StateTextBox.Text = StudentsDataGridView.CurrentRow.Cells(8).Value.ToString()
        StudentRegistrationForm.PostalCodeTextBox.Text = StudentsDataGridView.CurrentRow.Cells(9).Value.ToString()
        StudentRegistrationForm.StudentPhoneTextBox.Text = StudentsDataGridView.CurrentRow.Cells(10).Value.ToString()
        StudentRegistrationForm.StudentEmailTextBox.Text = StudentsDataGridView.CurrentRow.Cells(11).Value.ToString()
        StudentRegistrationForm.RegistrationDateTimePicker.Text = StudentsDataGridView.CurrentRow.Cells(13).Value.ToString()

    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click
        Application.Exit()
    End Sub


    Private Sub LogoutButton_Click(sender As System.Object, e As System.EventArgs) Handles LogoutButton.Click
        Me.Close()
        LoginForm.Show()
    End Sub

    Private Sub RecordAttendanceButton_Click(sender As System.Object, e As System.EventArgs) Handles RecordAttendanceButton.Click
        Me.Hide()
        RecordAttendanceForm.Show()
    End Sub

    Private Sub AddOrDropCoursesButton_Click(sender As System.Object, e As System.EventArgs) Handles AddOrDropCoursesButton.Click
        Me.Hide()
        CourseEnrollmentForm.Show()
    End Sub

    Private Sub StudentsListByCoursesButton_Click(sender As System.Object, e As System.EventArgs) Handles StudentsListByCoursesButton.Click
        Me.Hide()
        StudentsListByCoursesForm.Show()
    End Sub


    Private Sub AttendanceReportButton_Click(sender As System.Object, e As System.EventArgs) Handles AttendanceReportButton.Click
        Me.Hide()
        AttendanceReportForm.Show()
    End Sub

    Private Sub RecordPlacementButton_Click(sender As System.Object, e As System.EventArgs) Handles RecordPlacementButton.Click
        Me.Hide()
        PlacementsForm.Show()
    End Sub

    Private Sub StudentPlacementsReport_Click(sender As System.Object, e As System.EventArgs) Handles StudentPlacementsReportButton.Click
        PlacementsReportForm.Show()
    End Sub

End Class
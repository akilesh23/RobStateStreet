﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentRegistrationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim StudentIdLabel As System.Windows.Forms.Label
        Dim StudentLastNameLabel As System.Windows.Forms.Label
        Dim StudentFirstNameLabel As System.Windows.Forms.Label
        Dim StudentDobLabel As System.Windows.Forms.Label
        Dim StudentGenderLabel As System.Windows.Forms.Label
        Dim MaritalStatusLabel As System.Windows.Forms.Label
        Dim AddressLineLabel As System.Windows.Forms.Label
        Dim CityLabel As System.Windows.Forms.Label
        Dim StateLabel As System.Windows.Forms.Label
        Dim PostalCodeLabel As System.Windows.Forms.Label
        Dim StudentPhoneLabel As System.Windows.Forms.Label
        Dim StudentEmailLabel As System.Windows.Forms.Label
        Dim RegistrationDateLabel As System.Windows.Forms.Label
        Dim RegisteredByNameLabel As System.Windows.Forms.Label
        Me.StudentIdTextBox = New System.Windows.Forms.TextBox()
        Me.StudentLastNameTextBox = New System.Windows.Forms.TextBox()
        Me.StudentFirstNameTextBox = New System.Windows.Forms.TextBox()
        Me.StudentDobDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.AddressLineTextBox = New System.Windows.Forms.TextBox()
        Me.CityTextBox = New System.Windows.Forms.TextBox()
        Me.StateTextBox = New System.Windows.Forms.TextBox()
        Me.PostalCodeTextBox = New System.Windows.Forms.TextBox()
        Me.StudentPhoneTextBox = New System.Windows.Forms.TextBox()
        Me.StudentEmailTextBox = New System.Windows.Forms.TextBox()
        Me.RegistrationDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.StudentGenderComboBox = New System.Windows.Forms.ComboBox()
        Me.MaritalStatusComboBox = New System.Windows.Forms.ComboBox()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.RegisteredByNameTextBox = New System.Windows.Forms.TextBox()
        Me.ErrorProvider = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        StudentIdLabel = New System.Windows.Forms.Label()
        StudentLastNameLabel = New System.Windows.Forms.Label()
        StudentFirstNameLabel = New System.Windows.Forms.Label()
        StudentDobLabel = New System.Windows.Forms.Label()
        StudentGenderLabel = New System.Windows.Forms.Label()
        MaritalStatusLabel = New System.Windows.Forms.Label()
        AddressLineLabel = New System.Windows.Forms.Label()
        CityLabel = New System.Windows.Forms.Label()
        StateLabel = New System.Windows.Forms.Label()
        PostalCodeLabel = New System.Windows.Forms.Label()
        StudentPhoneLabel = New System.Windows.Forms.Label()
        StudentEmailLabel = New System.Windows.Forms.Label()
        RegistrationDateLabel = New System.Windows.Forms.Label()
        RegisteredByNameLabel = New System.Windows.Forms.Label()
        CType(Me.ErrorProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StudentIdLabel
        '
        StudentIdLabel.AutoSize = True
        StudentIdLabel.Location = New System.Drawing.Point(28, 43)
        StudentIdLabel.Name = "StudentIdLabel"
        StudentIdLabel.Size = New System.Drawing.Size(59, 13)
        StudentIdLabel.TabIndex = 1
        StudentIdLabel.Text = "Student Id:"
        '
        'StudentLastNameLabel
        '
        StudentLastNameLabel.AutoSize = True
        StudentLastNameLabel.Location = New System.Drawing.Point(28, 69)
        StudentLastNameLabel.Name = "StudentLastNameLabel"
        StudentLastNameLabel.Size = New System.Drawing.Size(101, 13)
        StudentLastNameLabel.TabIndex = 3
        StudentLastNameLabel.Text = "Student Last Name:"
        '
        'StudentFirstNameLabel
        '
        StudentFirstNameLabel.AutoSize = True
        StudentFirstNameLabel.Location = New System.Drawing.Point(28, 95)
        StudentFirstNameLabel.Name = "StudentFirstNameLabel"
        StudentFirstNameLabel.Size = New System.Drawing.Size(100, 13)
        StudentFirstNameLabel.TabIndex = 5
        StudentFirstNameLabel.Text = "Student First Name:"
        '
        'StudentDobLabel
        '
        StudentDobLabel.AutoSize = True
        StudentDobLabel.Location = New System.Drawing.Point(454, 70)
        StudentDobLabel.Name = "StudentDobLabel"
        StudentDobLabel.Size = New System.Drawing.Size(70, 13)
        StudentDobLabel.TabIndex = 7
        StudentDobLabel.Text = "Student Dob:"
        '
        'StudentGenderLabel
        '
        StudentGenderLabel.AutoSize = True
        StudentGenderLabel.Location = New System.Drawing.Point(454, 43)
        StudentGenderLabel.Name = "StudentGenderLabel"
        StudentGenderLabel.Size = New System.Drawing.Size(85, 13)
        StudentGenderLabel.TabIndex = 9
        StudentGenderLabel.Text = "Student Gender:"
        '
        'MaritalStatusLabel
        '
        MaritalStatusLabel.AutoSize = True
        MaritalStatusLabel.Location = New System.Drawing.Point(454, 95)
        MaritalStatusLabel.Name = "MaritalStatusLabel"
        MaritalStatusLabel.Size = New System.Drawing.Size(74, 13)
        MaritalStatusLabel.TabIndex = 11
        MaritalStatusLabel.Text = "Marital Status:"
        '
        'AddressLineLabel
        '
        AddressLineLabel.AutoSize = True
        AddressLineLabel.Location = New System.Drawing.Point(28, 121)
        AddressLineLabel.Name = "AddressLineLabel"
        AddressLineLabel.Size = New System.Drawing.Size(71, 13)
        AddressLineLabel.TabIndex = 13
        AddressLineLabel.Text = "Address Line:"
        '
        'CityLabel
        '
        CityLabel.AutoSize = True
        CityLabel.Location = New System.Drawing.Point(28, 147)
        CityLabel.Name = "CityLabel"
        CityLabel.Size = New System.Drawing.Size(27, 13)
        CityLabel.TabIndex = 15
        CityLabel.Text = "City:"
        '
        'StateLabel
        '
        StateLabel.AutoSize = True
        StateLabel.Location = New System.Drawing.Point(28, 173)
        StateLabel.Name = "StateLabel"
        StateLabel.Size = New System.Drawing.Size(35, 13)
        StateLabel.TabIndex = 17
        StateLabel.Text = "State:"
        '
        'PostalCodeLabel
        '
        PostalCodeLabel.AutoSize = True
        PostalCodeLabel.Location = New System.Drawing.Point(28, 199)
        PostalCodeLabel.Name = "PostalCodeLabel"
        PostalCodeLabel.Size = New System.Drawing.Size(67, 13)
        PostalCodeLabel.TabIndex = 19
        PostalCodeLabel.Text = "Postal Code:"
        '
        'StudentPhoneLabel
        '
        StudentPhoneLabel.AutoSize = True
        StudentPhoneLabel.Location = New System.Drawing.Point(454, 121)
        StudentPhoneLabel.Name = "StudentPhoneLabel"
        StudentPhoneLabel.Size = New System.Drawing.Size(81, 13)
        StudentPhoneLabel.TabIndex = 21
        StudentPhoneLabel.Text = "Student Phone:"
        '
        'StudentEmailLabel
        '
        StudentEmailLabel.AutoSize = True
        StudentEmailLabel.Location = New System.Drawing.Point(454, 147)
        StudentEmailLabel.Name = "StudentEmailLabel"
        StudentEmailLabel.Size = New System.Drawing.Size(75, 13)
        StudentEmailLabel.TabIndex = 23
        StudentEmailLabel.Text = "Student Email:"
        '
        'RegistrationDateLabel
        '
        RegistrationDateLabel.AutoSize = True
        RegistrationDateLabel.Location = New System.Drawing.Point(454, 200)
        RegistrationDateLabel.Name = "RegistrationDateLabel"
        RegistrationDateLabel.Size = New System.Drawing.Size(92, 13)
        RegistrationDateLabel.TabIndex = 27
        RegistrationDateLabel.Text = "Registration Date:"
        '
        'RegisteredByNameLabel
        '
        RegisteredByNameLabel.AutoSize = True
        RegisteredByNameLabel.Location = New System.Drawing.Point(454, 173)
        RegisteredByNameLabel.Name = "RegisteredByNameLabel"
        RegisteredByNameLabel.Size = New System.Drawing.Size(76, 13)
        RegisteredByNameLabel.TabIndex = 38
        RegisteredByNameLabel.Text = "Registered By:"
        '
        'StudentIdTextBox
        '
        Me.StudentIdTextBox.Location = New System.Drawing.Point(135, 40)
        Me.StudentIdTextBox.Name = "StudentIdTextBox"
        Me.StudentIdTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StudentIdTextBox.TabIndex = 2
        '
        'StudentLastNameTextBox
        '
        Me.StudentLastNameTextBox.Location = New System.Drawing.Point(135, 66)
        Me.StudentLastNameTextBox.Name = "StudentLastNameTextBox"
        Me.StudentLastNameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StudentLastNameTextBox.TabIndex = 4
        '
        'StudentFirstNameTextBox
        '
        Me.StudentFirstNameTextBox.Location = New System.Drawing.Point(135, 92)
        Me.StudentFirstNameTextBox.Name = "StudentFirstNameTextBox"
        Me.StudentFirstNameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StudentFirstNameTextBox.TabIndex = 6
        '
        'StudentDobDateTimePicker
        '
        Me.StudentDobDateTimePicker.Location = New System.Drawing.Point(561, 66)
        Me.StudentDobDateTimePicker.Name = "StudentDobDateTimePicker"
        Me.StudentDobDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.StudentDobDateTimePicker.TabIndex = 8
        '
        'AddressLineTextBox
        '
        Me.AddressLineTextBox.Location = New System.Drawing.Point(135, 118)
        Me.AddressLineTextBox.Name = "AddressLineTextBox"
        Me.AddressLineTextBox.Size = New System.Drawing.Size(200, 20)
        Me.AddressLineTextBox.TabIndex = 14
        '
        'CityTextBox
        '
        Me.CityTextBox.Location = New System.Drawing.Point(135, 144)
        Me.CityTextBox.Name = "CityTextBox"
        Me.CityTextBox.Size = New System.Drawing.Size(200, 20)
        Me.CityTextBox.TabIndex = 16
        '
        'StateTextBox
        '
        Me.StateTextBox.Location = New System.Drawing.Point(135, 170)
        Me.StateTextBox.Name = "StateTextBox"
        Me.StateTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StateTextBox.TabIndex = 18
        '
        'PostalCodeTextBox
        '
        Me.PostalCodeTextBox.Location = New System.Drawing.Point(135, 196)
        Me.PostalCodeTextBox.Name = "PostalCodeTextBox"
        Me.PostalCodeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.PostalCodeTextBox.TabIndex = 20
        '
        'StudentPhoneTextBox
        '
        Me.StudentPhoneTextBox.Location = New System.Drawing.Point(561, 118)
        Me.StudentPhoneTextBox.Name = "StudentPhoneTextBox"
        Me.StudentPhoneTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StudentPhoneTextBox.TabIndex = 22
        '
        'StudentEmailTextBox
        '
        Me.StudentEmailTextBox.Location = New System.Drawing.Point(561, 144)
        Me.StudentEmailTextBox.Name = "StudentEmailTextBox"
        Me.StudentEmailTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StudentEmailTextBox.TabIndex = 24
        '
        'RegistrationDateTimePicker
        '
        Me.RegistrationDateTimePicker.Location = New System.Drawing.Point(561, 196)
        Me.RegistrationDateTimePicker.Name = "RegistrationDateTimePicker"
        Me.RegistrationDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.RegistrationDateTimePicker.TabIndex = 29
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(285, 256)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 30
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'StudentGenderComboBox
        '
        Me.StudentGenderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StudentGenderComboBox.FormattingEnabled = True
        Me.StudentGenderComboBox.Items.AddRange(New Object() {"Male", "Female", "Others"})
        Me.StudentGenderComboBox.Location = New System.Drawing.Point(561, 35)
        Me.StudentGenderComboBox.Name = "StudentGenderComboBox"
        Me.StudentGenderComboBox.Size = New System.Drawing.Size(121, 21)
        Me.StudentGenderComboBox.TabIndex = 32
        '
        'MaritalStatusComboBox
        '
        Me.MaritalStatusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MaritalStatusComboBox.FormattingEnabled = True
        Me.MaritalStatusComboBox.Items.AddRange(New Object() {"Single", "Married", "Divorced"})
        Me.MaritalStatusComboBox.Location = New System.Drawing.Point(561, 91)
        Me.MaritalStatusComboBox.Name = "MaritalStatusComboBox"
        Me.MaritalStatusComboBox.Size = New System.Drawing.Size(121, 21)
        Me.MaritalStatusComboBox.TabIndex = 33
        '
        'ClearButton
        '
        Me.ClearButton.CausesValidation = False
        Me.ClearButton.Location = New System.Drawing.Point(408, 256)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 34
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'RegisteredByNameTextBox
        '
        Me.RegisteredByNameTextBox.Location = New System.Drawing.Point(561, 170)
        Me.RegisteredByNameTextBox.Name = "RegisteredByNameTextBox"
        Me.RegisteredByNameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.RegisteredByNameTextBox.TabIndex = 37
        '
        'ErrorProvider
        '
        Me.ErrorProvider.ContainerControl = Me
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 301)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(639, 301)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 62
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StudentRegistrationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(795, 324)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(RegisteredByNameLabel)
        Me.Controls.Add(Me.RegisteredByNameTextBox)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.MaritalStatusComboBox)
        Me.Controls.Add(Me.StudentGenderComboBox)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.RegistrationDateTimePicker)
        Me.Controls.Add(StudentIdLabel)
        Me.Controls.Add(Me.StudentIdTextBox)
        Me.Controls.Add(StudentLastNameLabel)
        Me.Controls.Add(Me.StudentLastNameTextBox)
        Me.Controls.Add(StudentFirstNameLabel)
        Me.Controls.Add(Me.StudentFirstNameTextBox)
        Me.Controls.Add(StudentDobLabel)
        Me.Controls.Add(Me.StudentDobDateTimePicker)
        Me.Controls.Add(StudentGenderLabel)
        Me.Controls.Add(MaritalStatusLabel)
        Me.Controls.Add(AddressLineLabel)
        Me.Controls.Add(Me.AddressLineTextBox)
        Me.Controls.Add(CityLabel)
        Me.Controls.Add(Me.CityTextBox)
        Me.Controls.Add(StateLabel)
        Me.Controls.Add(Me.StateTextBox)
        Me.Controls.Add(PostalCodeLabel)
        Me.Controls.Add(Me.PostalCodeTextBox)
        Me.Controls.Add(StudentPhoneLabel)
        Me.Controls.Add(Me.StudentPhoneTextBox)
        Me.Controls.Add(StudentEmailLabel)
        Me.Controls.Add(Me.StudentEmailTextBox)
        Me.Controls.Add(RegistrationDateLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "StudentRegistrationForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Student Registration"
        CType(Me.ErrorProvider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StudentIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentLastNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentFirstNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentDobDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents AddressLineTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PostalCodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentPhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentEmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RegistrationDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents StudentGenderComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents MaritalStatusComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents RegisteredByNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ErrorProvider As System.Windows.Forms.ErrorProvider
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PlacementsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim StudentIdLabel As System.Windows.Forms.Label
        Dim JoiningDateLabel As System.Windows.Forms.Label
        Dim InterviewDateLabel As System.Windows.Forms.Label
        Dim DesignationLabel As System.Windows.Forms.Label
        Dim GrossSalaryLabel As System.Windows.Forms.Label
        Dim OtherBenefitsLabel As System.Windows.Forms.Label
        Dim CompanyNameLabel As System.Windows.Forms.Label
        Me.JoiningDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.InterviewDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.DesignationTextBox = New System.Windows.Forms.TextBox()
        Me.GrossSalaryTextBox = New System.Windows.Forms.TextBox()
        Me.OtherBenefitsTextBox = New System.Windows.Forms.TextBox()
        Me.StudentIdComboBox = New System.Windows.Forms.ComboBox()
        Me.StudentFullNameTextBox = New System.Windows.Forms.TextBox()
        Me.StudentFullNameLabel = New System.Windows.Forms.Label()
        Me.CompanyNameComboBox = New System.Windows.Forms.ComboBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        StudentIdLabel = New System.Windows.Forms.Label()
        JoiningDateLabel = New System.Windows.Forms.Label()
        InterviewDateLabel = New System.Windows.Forms.Label()
        DesignationLabel = New System.Windows.Forms.Label()
        GrossSalaryLabel = New System.Windows.Forms.Label()
        OtherBenefitsLabel = New System.Windows.Forms.Label()
        CompanyNameLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'StudentIdLabel
        '
        StudentIdLabel.AutoSize = True
        StudentIdLabel.Location = New System.Drawing.Point(34, 42)
        StudentIdLabel.Name = "StudentIdLabel"
        StudentIdLabel.Size = New System.Drawing.Size(59, 13)
        StudentIdLabel.TabIndex = 1
        StudentIdLabel.Text = "Student Id:"
        '
        'JoiningDateLabel
        '
        JoiningDateLabel.AutoSize = True
        JoiningDateLabel.Location = New System.Drawing.Point(40, 127)
        JoiningDateLabel.Name = "JoiningDateLabel"
        JoiningDateLabel.Size = New System.Drawing.Size(69, 13)
        JoiningDateLabel.TabIndex = 5
        JoiningDateLabel.Text = "Joining Date:"
        '
        'InterviewDateLabel
        '
        InterviewDateLabel.AutoSize = True
        InterviewDateLabel.Location = New System.Drawing.Point(40, 153)
        InterviewDateLabel.Name = "InterviewDateLabel"
        InterviewDateLabel.Size = New System.Drawing.Size(79, 13)
        InterviewDateLabel.TabIndex = 7
        InterviewDateLabel.Text = "Interview Date:"
        '
        'DesignationLabel
        '
        DesignationLabel.AutoSize = True
        DesignationLabel.Location = New System.Drawing.Point(40, 194)
        DesignationLabel.Name = "DesignationLabel"
        DesignationLabel.Size = New System.Drawing.Size(66, 13)
        DesignationLabel.TabIndex = 9
        DesignationLabel.Text = "Designation:"
        '
        'GrossSalaryLabel
        '
        GrossSalaryLabel.AutoSize = True
        GrossSalaryLabel.Location = New System.Drawing.Point(40, 220)
        GrossSalaryLabel.Name = "GrossSalaryLabel"
        GrossSalaryLabel.Size = New System.Drawing.Size(69, 13)
        GrossSalaryLabel.TabIndex = 11
        GrossSalaryLabel.Text = "Gross Salary:"
        '
        'OtherBenefitsLabel
        '
        OtherBenefitsLabel.AutoSize = True
        OtherBenefitsLabel.Location = New System.Drawing.Point(42, 246)
        OtherBenefitsLabel.Name = "OtherBenefitsLabel"
        OtherBenefitsLabel.Size = New System.Drawing.Size(77, 13)
        OtherBenefitsLabel.TabIndex = 13
        OtherBenefitsLabel.Text = "Other Benefits:"
        '
        'CompanyNameLabel
        '
        CompanyNameLabel.AutoSize = True
        CompanyNameLabel.Location = New System.Drawing.Point(34, 79)
        CompanyNameLabel.Name = "CompanyNameLabel"
        CompanyNameLabel.Size = New System.Drawing.Size(85, 13)
        CompanyNameLabel.TabIndex = 17
        CompanyNameLabel.Text = "Company Name:"
        '
        'JoiningDateDateTimePicker
        '
        Me.JoiningDateDateTimePicker.Location = New System.Drawing.Point(125, 123)
        Me.JoiningDateDateTimePicker.Name = "JoiningDateDateTimePicker"
        Me.JoiningDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.JoiningDateDateTimePicker.TabIndex = 6
        '
        'InterviewDateDateTimePicker
        '
        Me.InterviewDateDateTimePicker.Location = New System.Drawing.Point(125, 149)
        Me.InterviewDateDateTimePicker.Name = "InterviewDateDateTimePicker"
        Me.InterviewDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.InterviewDateDateTimePicker.TabIndex = 8
        '
        'DesignationTextBox
        '
        Me.DesignationTextBox.Location = New System.Drawing.Point(125, 191)
        Me.DesignationTextBox.Name = "DesignationTextBox"
        Me.DesignationTextBox.Size = New System.Drawing.Size(200, 20)
        Me.DesignationTextBox.TabIndex = 10
        '
        'GrossSalaryTextBox
        '
        Me.GrossSalaryTextBox.Location = New System.Drawing.Point(125, 217)
        Me.GrossSalaryTextBox.Name = "GrossSalaryTextBox"
        Me.GrossSalaryTextBox.Size = New System.Drawing.Size(200, 20)
        Me.GrossSalaryTextBox.TabIndex = 12
        '
        'OtherBenefitsTextBox
        '
        Me.OtherBenefitsTextBox.Location = New System.Drawing.Point(125, 243)
        Me.OtherBenefitsTextBox.Multiline = True
        Me.OtherBenefitsTextBox.Name = "OtherBenefitsTextBox"
        Me.OtherBenefitsTextBox.Size = New System.Drawing.Size(200, 72)
        Me.OtherBenefitsTextBox.TabIndex = 14
        '
        'StudentIdComboBox
        '
        Me.StudentIdComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StudentIdComboBox.FormattingEnabled = True
        Me.StudentIdComboBox.Location = New System.Drawing.Point(125, 39)
        Me.StudentIdComboBox.Name = "StudentIdComboBox"
        Me.StudentIdComboBox.Size = New System.Drawing.Size(121, 21)
        Me.StudentIdComboBox.TabIndex = 15
        '
        'StudentFullNameTextBox
        '
        Me.StudentFullNameTextBox.Location = New System.Drawing.Point(378, 35)
        Me.StudentFullNameTextBox.Name = "StudentFullNameTextBox"
        Me.StudentFullNameTextBox.ReadOnly = True
        Me.StudentFullNameTextBox.Size = New System.Drawing.Size(121, 20)
        Me.StudentFullNameTextBox.TabIndex = 41
        '
        'StudentFullNameLabel
        '
        Me.StudentFullNameLabel.AutoSize = True
        Me.StudentFullNameLabel.Location = New System.Drawing.Point(276, 38)
        Me.StudentFullNameLabel.Name = "StudentFullNameLabel"
        Me.StudentFullNameLabel.Size = New System.Drawing.Size(97, 13)
        Me.StudentFullNameLabel.TabIndex = 40
        Me.StudentFullNameLabel.Text = "Student Full Name:"
        '
        'CompanyNameComboBox
        '
        Me.CompanyNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CompanyNameComboBox.FormattingEnabled = True
        Me.CompanyNameComboBox.Location = New System.Drawing.Point(125, 76)
        Me.CompanyNameComboBox.Name = "CompanyNameComboBox"
        Me.CompanyNameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.CompanyNameComboBox.TabIndex = 16
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(125, 339)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 42
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(250, 339)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 44
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 368)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 60
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(374, 368)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 61
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PlacementsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(530, 390)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.StudentFullNameTextBox)
        Me.Controls.Add(Me.StudentFullNameLabel)
        Me.Controls.Add(CompanyNameLabel)
        Me.Controls.Add(Me.CompanyNameComboBox)
        Me.Controls.Add(Me.StudentIdComboBox)
        Me.Controls.Add(StudentIdLabel)
        Me.Controls.Add(JoiningDateLabel)
        Me.Controls.Add(Me.JoiningDateDateTimePicker)
        Me.Controls.Add(InterviewDateLabel)
        Me.Controls.Add(Me.InterviewDateDateTimePicker)
        Me.Controls.Add(DesignationLabel)
        Me.Controls.Add(Me.DesignationTextBox)
        Me.Controls.Add(GrossSalaryLabel)
        Me.Controls.Add(Me.GrossSalaryTextBox)
        Me.Controls.Add(OtherBenefitsLabel)
        Me.Controls.Add(Me.OtherBenefitsTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PlacementsForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Record Placement"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents JoiningDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents InterviewDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents DesignationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GrossSalaryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OtherBenefitsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentIdComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StudentFullNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentFullNameLabel As System.Windows.Forms.Label
    Friend WithEvents CompanyNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class

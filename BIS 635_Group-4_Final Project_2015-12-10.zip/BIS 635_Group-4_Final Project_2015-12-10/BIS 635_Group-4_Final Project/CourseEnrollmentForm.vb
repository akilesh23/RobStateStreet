﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : CourseEnrollmentForm
'Description     : This class contains all the properties of CourseEnrollmentForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Imports System.IO
Imports System.Text
Imports System.Data
Imports System.Net
Imports System.Net.Mail
Imports System.Web.UI
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.tool.xml
Imports iTextSharp.text.xml.simpleparser


Public Class CourseEnrollmentForm

    Private DBAccess As New DBControl
    Private SelectedCourseListDataTable As New DataTable

    Private StudentEmailAddress As String
    Private NewStudent As Boolean

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub CourseEnrollmentForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub

    Private Sub CourseEnrollmentForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        RegisteredByTextBox.Text = LoginForm.LoggedInEmpFullName
        RegisteredByTextBox.ReadOnly = True

        DBAccess.ExecuteQuery("SELECT * FROM Students")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
            StudentIdComboBox.Items.Add(ADataRow("StudentId"))
        Next

        If DBAccess.RecordCount > 0 Then
            StudentIdComboBox.SelectedIndex = -1
        End If

        LoadCourseNameComboBox()
    

    End Sub

    Private Sub StudentIdComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles StudentIdComboBox.SelectionChangeCommitted

        DBAccess.ExecuteQuery("SELECT * FROM Students WHERE StudentId = " & StudentIdComboBox.Text & "")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        StudentFullNameTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("StudentFirstName") & " " & DBAccess.DBDataTable.Rows(0).Item("StudentLastName")

        LoadSelectedCourseListDataGridView()

        Dim TotalFee As Double = SelectedCourseListDataGridView.Rows.Cast(Of DataGridViewRow)().Sum(Function(row) Convert.ToDouble(row.Cells("CourseFeeDataGridViewTextBoxColumn").Value))
        TotalFeeTextBox.Text = TotalFee

    End Sub

    'Fill SelectedCourseListDataGridView!
    Private Sub LoadSelectedCourseListDataGridView()

        DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        If DBAccess.RecordCount = 0 Then

            SelectedCourseListDataTable = DBAccess.DBDataTable

            SelectedCourseListDataGridView.DataSource = SelectedCourseListDataTable

            NewStudent = True

            SaveButton.Text = "Register"

            SaveButton.Enabled = True

            EmailReceiptButton.Enabled = False

        Else

            SelectedCourseListDataTable = DBAccess.DBDataTable

            SelectedCourseListDataGridView.DataSource = SelectedCourseListDataTable

            NewStudent = False

            SaveButton.Text = "Save"

            SaveButton.Enabled = True

            EmailReceiptButton.Enabled = True

        End If


    End Sub

    'Drop Courses!
    Private Sub SelectedCourseListDataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles SelectedCourseListDataGridView.CellContentClick

        If TypeOf SelectedCourseListDataGridView.Columns(e.ColumnIndex) Is DataGridViewButtonColumn AndAlso e.RowIndex >= 0 Then

            For i = 0 To SelectedCourseListDataTable.Rows.Count - 1

                If SelectedCourseListDataGridView.CurrentRow.Cells(2).Value = SelectedCourseListDataTable.Rows(i)("SectionName") Then

                    SelectedCourseListDataTable.Rows(i).Delete()
                    SelectedCourseListDataTable.AcceptChanges()
                    SelectedCourseListDataGridView.DataSource = SelectedCourseListDataTable
                    SelectedCourseListDataGridView.Refresh()

                    Dim TotalFee As Double = SelectedCourseListDataGridView.Rows.Cast(Of DataGridViewRow)().Sum(Function(row) Convert.ToDouble(row.Cells("CourseFeeDataGridViewTextBoxColumn").Value))
                    TotalFeeTextBox.Text = TotalFee

                    Exit Sub

                End If

            Next

        End If


    End Sub

    Private Sub LoadCourseNameComboBox()

        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseNameComboBox.Items.Add(ADataRow("CourseName"))
            Next

            If DBAccess.RecordCount > 0 Then
                CourseNameComboBox.SelectedIndex = -1
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub CourseNameComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseNameComboBox.SelectionChangeCommitted
        Try

            'Populate GiftNameTextBox
            DBAccess.ExecuteQuery("SELECT GiftName FROM OfferedCourses WHERE CourseName = '" & CourseNameComboBox.Text & "'")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            GiftNameTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("GiftName")

            'Populate CoursesListDataGridView
            DBAccess.ExecuteQuery("SELECT Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId)INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) WHERE OC.CourseName = '" & CourseNameComboBox.Text & "' ")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            If DBAccess.RecordCount = 0 Then
                MessageBox.Show("Sorry, No Sections found for the Selected Course!")
            End If

            CoursesListDataGridView.DataSource = DBAccess.DBDataTable

        Catch ex As Exception

        End Try

    End Sub

    Private Sub ReloadCourseButton_Click(sender As System.Object, e As System.EventArgs) Handles ReloadCourseButton.Click

        CourseNameComboBox.Items.Clear()

        GiftNameTextBox.Clear()

        If CoursesListDataGridView.RowCount > 0 Then

            CoursesListDataGridView.DataSource.Clear()

        End If

        LoadCourseNameComboBox()

    End Sub

    Private Sub CoursesListDataGridView_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles CoursesListDataGridView.CellClick

        'Making CheckBoxes To Work like Radio Buttons!
        For Each r1 As DataGridViewRow In CoursesListDataGridView.Rows

            If r1.Index = e.RowIndex Then
                r1.Cells(0).Value = True
                r1.Cells(0).ReadOnly = True
            Else
                r1.Cells(0).Value = False
                r1.Cells(0).ReadOnly = False
            End If

        Next

    End Sub

    Private Sub Course1DataGridView_SelectionChanged(sender As Object, e As System.EventArgs) Handles CoursesListDataGridView.SelectionChanged
        CoursesListDataGridView.ClearSelection()
    End Sub


    Private Sub TransferButton_Click(sender As System.Object, e As System.EventArgs) Handles TransferButton.Click

        If StudentIdComboBox.Text = "" Then
            MessageBox.Show("Please Select The Student ID First!")
            Exit Sub
        ElseIf SelectedCourseListDataGridView.RowCount = 3 Then
            MessageBox.Show("Sorry, The Student has already reached the max. no. of courses that he can enroll for! Please drop a course from the selection list and then select the intended course from the courses list!")
            Exit Sub
        ElseIf CoursesListDataGridView.RowCount = 0 Then
            MessageBox.Show("Sorry, No Courses Selected! Please Select A Course And Then Click >> Button")
            Exit Sub
        ElseIf SelectedCourseListDataGridView.RowCount = 0 Then 'Fresh Course Enrollment

            'CoursesListDataGridView TO SelectedCourseListDataGridView
            If CoursesListDataGridView.RowCount > 0 And CoursesListDataGridView.CurrentRow.Cells(0).Value = True Then

                SelectedCourseListDataTable = DirectCast(SelectedCourseListDataGridView.DataSource, DataTable)

                Dim r1 As DataRow
                r1 = SelectedCourseListDataTable.NewRow
                r1.Item("CourseName") = CourseNameComboBox.Text
                r1.Item("SectionName") = CoursesListDataGridView.CurrentRow.Cells(1).Value
                r1.Item("ScheduleName") = CoursesListDataGridView.CurrentRow.Cells(2).Value
                r1.Item("InstructorName") = CoursesListDataGridView.CurrentRow.Cells(3).Value
                r1.Item("CourseFee") = CoursesListDataGridView.CurrentRow.Cells(4).Value

                SelectedCourseListDataTable.Rows.Add(r1)

                SelectedCourseListDataTable.AcceptChanges()

                SelectedCourseListDataGridView.DataSource = SelectedCourseListDataTable

                SelectedCourseListDataGridView.Refresh()

                If SelectedCourseListDataGridView.RowCount = 3 Then
                    MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                    Exit Sub
                End If

            Else
                MessageBox.Show("Please Choose A Section From The Section Lists Available Under Courses!")
                Exit Sub
            End If

        ElseIf SelectedCourseListDataGridView.RowCount > 0 And CoursesListDataGridView.CurrentRow.Cells(0).Value = True Then

            For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1

                If (CourseNameComboBox.Text = SelectedCourseListDataGridView.Rows(i).Cells(1).Value) And (CoursesListDataGridView.CurrentRow.Cells(0).Value = True) Then

                    MessageBox.Show("You have already enrolled for this Course! Please select a different course!")

                    CourseNameComboBox.Items.Clear()
                    GiftNameTextBox.Clear()
                    If CoursesListDataGridView.RowCount > 0 Then
                        CoursesListDataGridView.DataSource.Clear()
                    End If

                    LoadCourseNameComboBox()

                    Exit Sub

                ElseIf (CoursesListDataGridView.CurrentRow.Cells(2).Value = SelectedCourseListDataGridView.Rows(i).Cells(3).Value) And (CoursesListDataGridView.CurrentRow.Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")
                    CoursesListDataGridView.CurrentRow.Cells(0).Value = False
                    Exit Sub
                End If
            Next

            Dim r1 As DataRow
            r1 = SelectedCourseListDataTable.NewRow
            r1.Item("CourseName") = CourseNameComboBox.Text
            r1.Item("SectionName") = CoursesListDataGridView.CurrentRow.Cells(1).Value
            r1.Item("ScheduleName") = CoursesListDataGridView.CurrentRow.Cells(2).Value
            r1.Item("InstructorName") = CoursesListDataGridView.CurrentRow.Cells(3).Value
            r1.Item("CourseFee") = CoursesListDataGridView.CurrentRow.Cells(4).Value

            SelectedCourseListDataTable.Rows.Add(r1)

            SelectedCourseListDataTable.AcceptChanges()

            SelectedCourseListDataGridView.DataSource = SelectedCourseListDataTable

            SelectedCourseListDataGridView.Refresh()

            If SelectedCourseListDataGridView.RowCount = 3 Then
                MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
            End If

        Else
            MessageBox.Show("Please Choose A Section From The Section Lists Available Under Courses!")
            Exit Sub
        End If

        Dim TotalFee As Double = SelectedCourseListDataGridView.Rows.Cast(Of DataGridViewRow)().Sum(Function(row) Convert.ToDouble(row.Cells("CourseFeeDataGridViewTextBoxColumn").Value))
        TotalFeeTextBox.Text = TotalFee

    End Sub

    Private Sub SaveButton_Click(sender As System.Object, e As System.EventArgs) Handles SaveButton.Click

        SaveSelectedCourses(StudentIdComboBox.Text, CourseEnrollFormDateTimePicker.Value.Date)

    End Sub

    Private Sub SaveSelectedCourses(StudentId As Integer, CourseEnrollmentDate As Date)

        Try

            DBAccess.ExecuteQuery("DELETE * FROM CourseEnrollment WHERE StudentId = " & StudentIdComboBox.Text & "")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            'SelectedCourseListDataGridView
            If SelectedCourseListDataGridView.RowCount = 0 Then
                MessageBox.Show("Sorry, Nothing To Save!")
            Else

                For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1

                    DBAccess.ExecuteQuery("SELECT SectionId FROM Sections WHERE SectionName = '" & SelectedCourseListDataGridView.Rows(i).Cells(2).Value & "'")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim SectionId As Integer = DBAccess.DBDataTable.Rows(0).Item("SectionId")

                    DBAccess.AddParam("@StudentId", StudentId)
                    DBAccess.AddParam("@SectionId", SectionId)
                    DBAccess.AddParam("@CourseEnrollmentDate", CourseEnrollmentDate)
                    DBAccess.AddParam("@EmployeeId", LoginForm.LoggedInEmpId)

                    DBAccess.ExecuteQuery("INSERT INTO CourseEnrollment(StudentId,SectionId,CourseEnrollmentDate,RegisteredBy) values(@StudentId,@SectionId,@CourseEnrollmentDate,@EmployeeId)")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                Next

                SendPDFEmail()

                MessageBox.Show("Course Enrollment Successfully Completed! Please Pay $" & TotalFeeTextBox.Text & " To Admin! We Have Also Sent An e-Receipt To The Registered Email Address. Thank you!")

                Me.Close()
                MainMenuForm.Show()

            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub EmailReceiptButton_Click(sender As System.Object, e As System.EventArgs) Handles EmailReceiptButton.Click

        Try

            If StudentIdComboBox.Text = "" Then
                MessageBox.Show("Please Select Student Id To Start With!")
                Exit Sub
            End If

            If SelectedCourseListDataGridView.RowCount = 0 Then
                MessageBox.Show("Sorry, No Courses Selected In The System To Send An Acknowledgement Receipt!")
                Exit Sub
            End If

            SendPDFEmail()

            MessageBox.Show("E-Mail Receipt Sent Successfully!")

        Catch ex As Exception

        End Try


    End Sub

    Private Sub SendPDFEmail()

        Try

            DBAccess.ExecuteQuery("SELECT StudentEmail FROM Students WHERE StudentId = " & StudentIdComboBox.Text & "")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            StudentEmailAddress = DBAccess.DBDataTable.Rows(0).Item("StudentEmail")

            Dim EmailReceiptDataTable As New DataTable()

            EmailReceiptDataTable.Columns.AddRange(New DataColumn(4) {New DataColumn("CourseName"), New DataColumn("SectionName"), New DataColumn("ScheduleName"), New DataColumn("InstructorName"), New DataColumn("CourseFee")})


            If SelectedCourseListDataGridView.RowCount = 1 Then
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(0)("CourseName"), SelectedCourseListDataTable.Rows(0)("SectionName"), SelectedCourseListDataTable.Rows(0)("ScheduleName"), SelectedCourseListDataTable.Rows(0)("InstructorName"), SelectedCourseListDataTable.Rows(0)("CourseFee"))
            ElseIf SelectedCourseListDataGridView.RowCount = 2 Then
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(0)("CourseName"), SelectedCourseListDataTable.Rows(0)("SectionName"), SelectedCourseListDataTable.Rows(0)("ScheduleName"), SelectedCourseListDataTable.Rows(0)("InstructorName"), SelectedCourseListDataTable.Rows(0)("CourseFee"))
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(1)("CourseName"), SelectedCourseListDataTable.Rows(1)("SectionName"), SelectedCourseListDataTable.Rows(1)("ScheduleName"), SelectedCourseListDataTable.Rows(1)("InstructorName"), SelectedCourseListDataTable.Rows(1)("CourseFee"))
            ElseIf SelectedCourseListDataGridView.RowCount = 3 Then
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(0)("CourseName"), SelectedCourseListDataTable.Rows(0)("SectionName"), SelectedCourseListDataTable.Rows(0)("ScheduleName"), SelectedCourseListDataTable.Rows(0)("InstructorName"), SelectedCourseListDataTable.Rows(0)("CourseFee"))
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(1)("CourseName"), SelectedCourseListDataTable.Rows(1)("SectionName"), SelectedCourseListDataTable.Rows(1)("ScheduleName"), SelectedCourseListDataTable.Rows(1)("InstructorName"), SelectedCourseListDataTable.Rows(1)("CourseFee"))
                EmailReceiptDataTable.Rows.Add(SelectedCourseListDataTable.Rows(2)("CourseName"), SelectedCourseListDataTable.Rows(2)("SectionName"), SelectedCourseListDataTable.Rows(2)("ScheduleName"), SelectedCourseListDataTable.Rows(2)("InstructorName"), SelectedCourseListDataTable.Rows(2)("CourseFee"))
            End If


            Using sw As New StringWriter()
                Using hw As New HtmlTextWriter(sw)
                    Dim StudentName As String = "" & StudentFullNameTextBox.Text & ""
                    Dim StudentId As Integer = "" & StudentIdComboBox.Text & ""
                    Dim sb As New StringBuilder()
                    sb.Append("<table width='100%' cellspacing='0' cellpadding='2'>")

                    If NewStudent = True Then
                        sb.Append("<tr><td align='center' style='background-color: #18B5F0' colspan = '2'><b>Course Registration Confirmation Receipt</b></td></tr>")
                    Else
                        sb.Append("<tr><td align='center' style='background-color: #18B5F0' colspan = '2'><b>Updated Course Registration Confirmation Receipt</b></td></tr>")
                    End If

                    sb.Append("<tr><td colspan = '2'></td></tr>")
                    sb.Append("<tr><td><b>Student Id: </b>")
                    sb.Append(StudentId)
                    sb.Append("</td><td><b>Date: </b>")
                    sb.Append(DateTime.Now)
                    sb.Append(" </td></tr>")
                    sb.Append("<tr><td colspan = '2'><b>Student Name: </b> ")
                    sb.Append(StudentName)
                    sb.Append("</td></tr>")
                    sb.Append("</table>")
                    sb.Append("<br />")
                    sb.Append("<table border = '1'>")
                    sb.Append("<tr>")


                    For Each column As DataColumn In EmailReceiptDataTable.Columns
                        sb.Append("<td>")
                        sb.Append(column.ColumnName)
                        sb.Append("</td>")
                    Next

                    sb.Append("</tr>")
                    For Each row As DataRow In EmailReceiptDataTable.Rows
                        sb.Append("<tr>")
                        For Each column As DataColumn In EmailReceiptDataTable.Columns
                            sb.Append("<td>")
                            sb.Append(row(column))
                            sb.Append("</td>")
                        Next
                        sb.Append("</tr>")
                    Next
                    sb.Append("</table>")


                    Dim sr As New StringReader(sb.ToString())

                    Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)

                    Dim htmlparser As New HTMLWorker(pdfDoc)

                    Using memoryStream As New MemoryStream()
                        Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, memoryStream)
                        pdfDoc.Open()

                        htmlparser.Parse(sr)

                        pdfDoc.Close()

                        Dim bytes As Byte() = memoryStream.ToArray()
                        memoryStream.Close()

                        Dim mm As New MailMessage("bis635groupfour@gmail.com", "" & StudentEmailAddress & "")

                        If NewStudent = True Then
                            mm.Subject = "Course Enrollment Confirmation - YES"
                            mm.Body = "Course Enrollment Confirmation - YES"
                        Else
                            mm.Subject = "Updated Course Enrollment Confirmation - YES"
                            mm.Body = "Updated Course Enrollment Confirmation - YES"
                        End If

                        mm.Attachments.Add(New Attachment(New MemoryStream(bytes), "Course_Enrollment_Confirmation_" & StudentFullNameTextBox.Text & ".pdf"))
                        mm.IsBodyHtml = True

                        Dim smtp As New SmtpClient()
                        smtp.Host = "smtp.gmail.com"
                        smtp.EnableSsl = True

                        Dim NetworkCred As New NetworkCredential()
                        NetworkCred.UserName = "bis635groupfour@gmail.com"
                        NetworkCred.Password = "2179040251"
                        smtp.UseDefaultCredentials = True
                        smtp.Credentials = NetworkCred
                        smtp.Port = 587
                        smtp.Send(mm)

                    End Using
                End Using
            End Using


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub SelectedCourseListDataGridView_SelectionChanged(sender As Object, e As System.EventArgs) Handles SelectedCourseListDataGridView.SelectionChanged

        SelectedCourseListDataGridView.ClearSelection()

    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click

        Dim result As Integer = MessageBox.Show("Any Unsaved Data Changes Will Be Lost! Do You Want To Save & Exit?", "Save & Exit", MessageBoxButtons.YesNoCancel)

        If result = DialogResult.Cancel Then
            'Do Nothing
        ElseIf result = DialogResult.No Then

            Me.Close()
            MainMenuForm.Show()

        ElseIf result = DialogResult.Yes Then

            If SelectedCourseListDataGridView.Rows.Count = 0 Then
                MessageBox.Show("No Records to Save!")
                Me.Close()
                MainMenuForm.Show()
            Else
                SaveSelectedCourses(StudentIdComboBox.Text, CourseEnrollFormDateTimePicker.Value.Date)
            End If
        End If

    End Sub

End Class
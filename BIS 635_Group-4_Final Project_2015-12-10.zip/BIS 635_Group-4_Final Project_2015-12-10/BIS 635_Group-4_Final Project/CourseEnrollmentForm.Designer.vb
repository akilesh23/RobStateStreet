﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CourseEnrollmentForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim RegisteredByLabel As System.Windows.Forms.Label
        Dim StudentIdLabel As System.Windows.Forms.Label
        Dim EnrollmentDateLabel As System.Windows.Forms.Label
        Dim EnrolledCoursesLabel As System.Windows.Forms.Label
        Dim TotalFeeLabel As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Me.CoursesListDataGridView = New System.Windows.Forms.DataGridView()
        Me.SectionName1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ScheduleName1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InstructorName1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseFee1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Select1DataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.CourseNameComboBox = New System.Windows.Forms.ComboBox()
        Me.CourseNameLabel = New System.Windows.Forms.Label()
        Me.ReloadCourseButton = New System.Windows.Forms.Button()
        Me.CourseEnrollFormDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.RegisteredByTextBox = New System.Windows.Forms.TextBox()
        Me.StudentIdComboBox = New System.Windows.Forms.ComboBox()
        Me.StudentFullNameTextBox = New System.Windows.Forms.TextBox()
        Me.StudentFullNameLabel = New System.Windows.Forms.Label()
        Me.SelectedCourseListDataGridView = New System.Windows.Forms.DataGridView()
        Me.CourseNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SectionNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ScheduleNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InstructorNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseFeeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SelectedCourseListDataGridViewButtonColumn = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.TransferButton = New System.Windows.Forms.Button()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.EmailReceiptButton = New System.Windows.Forms.Button()
        Me.TotalFeeTextBox = New System.Windows.Forms.TextBox()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.GiftNameTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        RegisteredByLabel = New System.Windows.Forms.Label()
        StudentIdLabel = New System.Windows.Forms.Label()
        EnrollmentDateLabel = New System.Windows.Forms.Label()
        EnrolledCoursesLabel = New System.Windows.Forms.Label()
        TotalFeeLabel = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        CType(Me.CoursesListDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SelectedCourseListDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RegisteredByLabel
        '
        RegisteredByLabel.AutoSize = True
        RegisteredByLabel.Location = New System.Drawing.Point(29, 283)
        RegisteredByLabel.Name = "RegisteredByLabel"
        RegisteredByLabel.Size = New System.Drawing.Size(76, 13)
        RegisteredByLabel.TabIndex = 41
        RegisteredByLabel.Text = "Registered By:"
        '
        'StudentIdLabel
        '
        StudentIdLabel.AutoSize = True
        StudentIdLabel.Location = New System.Drawing.Point(29, 95)
        StudentIdLabel.Name = "StudentIdLabel"
        StudentIdLabel.Size = New System.Drawing.Size(59, 13)
        StudentIdLabel.TabIndex = 38
        StudentIdLabel.Text = "Student Id:"
        '
        'EnrollmentDateLabel
        '
        EnrollmentDateLabel.AutoSize = True
        EnrollmentDateLabel.Location = New System.Drawing.Point(29, 322)
        EnrollmentDateLabel.Name = "EnrollmentDateLabel"
        EnrollmentDateLabel.Size = New System.Drawing.Size(85, 13)
        EnrollmentDateLabel.TabIndex = 44
        EnrollmentDateLabel.Text = "Enrollment Date:"
        '
        'EnrolledCoursesLabel
        '
        EnrolledCoursesLabel.AutoSize = True
        EnrolledCoursesLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EnrolledCoursesLabel.Location = New System.Drawing.Point(392, 273)
        EnrolledCoursesLabel.Name = "EnrolledCoursesLabel"
        EnrolledCoursesLabel.Size = New System.Drawing.Size(168, 25)
        EnrolledCoursesLabel.TabIndex = 49
        EnrolledCoursesLabel.Text = "Enrolled Courses:"
        '
        'TotalFeeLabel
        '
        TotalFeeLabel.AutoSize = True
        TotalFeeLabel.Location = New System.Drawing.Point(780, 432)
        TotalFeeLabel.Name = "TotalFeeLabel"
        TotalFeeLabel.Size = New System.Drawing.Size(64, 13)
        TotalFeeLabel.TabIndex = 52
        TotalFeeLabel.Text = "Total Fee: $"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Location = New System.Drawing.Point(527, 79)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(57, 13)
        Label1.TabIndex = 56
        Label1.Text = "Gift Name:"
        '
        'CoursesListDataGridView
        '
        Me.CoursesListDataGridView.AllowUserToAddRows = False
        Me.CoursesListDataGridView.AllowUserToDeleteRows = False
        Me.CoursesListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CoursesListDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SectionName1DataGridViewTextBoxColumn, Me.ScheduleName1DataGridViewTextBoxColumn, Me.InstructorName1DataGridViewTextBoxColumn, Me.CourseFee1DataGridViewTextBoxColumn, Me.Select1DataGridViewCheckBoxColumn})
        Me.CoursesListDataGridView.Location = New System.Drawing.Point(395, 102)
        Me.CoursesListDataGridView.Name = "CoursesListDataGridView"
        Me.CoursesListDataGridView.Size = New System.Drawing.Size(543, 110)
        Me.CoursesListDataGridView.TabIndex = 0
        '
        'SectionName1DataGridViewTextBoxColumn
        '
        Me.SectionName1DataGridViewTextBoxColumn.DataPropertyName = "SectionName"
        Me.SectionName1DataGridViewTextBoxColumn.HeaderText = "SectionName"
        Me.SectionName1DataGridViewTextBoxColumn.Name = "SectionName1DataGridViewTextBoxColumn"
        Me.SectionName1DataGridViewTextBoxColumn.ReadOnly = True
        '
        'ScheduleName1DataGridViewTextBoxColumn
        '
        Me.ScheduleName1DataGridViewTextBoxColumn.DataPropertyName = "ScheduleName"
        Me.ScheduleName1DataGridViewTextBoxColumn.HeaderText = "ScheduleName"
        Me.ScheduleName1DataGridViewTextBoxColumn.Name = "ScheduleName1DataGridViewTextBoxColumn"
        Me.ScheduleName1DataGridViewTextBoxColumn.ReadOnly = True
        '
        'InstructorName1DataGridViewTextBoxColumn
        '
        Me.InstructorName1DataGridViewTextBoxColumn.DataPropertyName = "InstructorName"
        Me.InstructorName1DataGridViewTextBoxColumn.HeaderText = "InstructorName"
        Me.InstructorName1DataGridViewTextBoxColumn.Name = "InstructorName1DataGridViewTextBoxColumn"
        Me.InstructorName1DataGridViewTextBoxColumn.ReadOnly = True
        '
        'CourseFee1DataGridViewTextBoxColumn
        '
        Me.CourseFee1DataGridViewTextBoxColumn.DataPropertyName = "CourseFee"
        Me.CourseFee1DataGridViewTextBoxColumn.HeaderText = "CourseFee"
        Me.CourseFee1DataGridViewTextBoxColumn.Name = "CourseFee1DataGridViewTextBoxColumn"
        Me.CourseFee1DataGridViewTextBoxColumn.ReadOnly = True
        '
        'Select1DataGridViewCheckBoxColumn
        '
        Me.Select1DataGridViewCheckBoxColumn.DataPropertyName = "Select"
        Me.Select1DataGridViewCheckBoxColumn.HeaderText = "Select"
        Me.Select1DataGridViewCheckBoxColumn.Name = "Select1DataGridViewCheckBoxColumn"
        '
        'CourseNameComboBox
        '
        Me.CourseNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CourseNameComboBox.FormattingEnabled = True
        Me.CourseNameComboBox.Location = New System.Drawing.Point(397, 74)
        Me.CourseNameComboBox.Name = "CourseNameComboBox"
        Me.CourseNameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.CourseNameComboBox.TabIndex = 1
        '
        'CourseNameLabel
        '
        Me.CourseNameLabel.AutoSize = True
        Me.CourseNameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CourseNameLabel.Location = New System.Drawing.Point(389, 47)
        Me.CourseNameLabel.Name = "CourseNameLabel"
        Me.CourseNameLabel.Size = New System.Drawing.Size(142, 25)
        Me.CourseNameLabel.TabIndex = 2
        Me.CourseNameLabel.Text = "Select Course:"
        '
        'ReloadCourseButton
        '
        Me.ReloadCourseButton.Location = New System.Drawing.Point(805, 74)
        Me.ReloadCourseButton.Name = "ReloadCourseButton"
        Me.ReloadCourseButton.Size = New System.Drawing.Size(133, 23)
        Me.ReloadCourseButton.TabIndex = 11
        Me.ReloadCourseButton.Text = "Select a Different Course"
        Me.ReloadCourseButton.UseVisualStyleBackColor = True
        '
        'CourseEnrollFormDateTimePicker
        '
        Me.CourseEnrollFormDateTimePicker.Location = New System.Drawing.Point(131, 316)
        Me.CourseEnrollFormDateTimePicker.Name = "CourseEnrollFormDateTimePicker"
        Me.CourseEnrollFormDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.CourseEnrollFormDateTimePicker.TabIndex = 43
        '
        'RegisteredByTextBox
        '
        Me.RegisteredByTextBox.Location = New System.Drawing.Point(131, 280)
        Me.RegisteredByTextBox.Name = "RegisteredByTextBox"
        Me.RegisteredByTextBox.ReadOnly = True
        Me.RegisteredByTextBox.Size = New System.Drawing.Size(200, 20)
        Me.RegisteredByTextBox.TabIndex = 42
        '
        'StudentIdComboBox
        '
        Me.StudentIdComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StudentIdComboBox.FormattingEnabled = True
        Me.StudentIdComboBox.Location = New System.Drawing.Point(131, 92)
        Me.StudentIdComboBox.Name = "StudentIdComboBox"
        Me.StudentIdComboBox.Size = New System.Drawing.Size(58, 21)
        Me.StudentIdComboBox.TabIndex = 40
        '
        'StudentFullNameTextBox
        '
        Me.StudentFullNameTextBox.Location = New System.Drawing.Point(131, 123)
        Me.StudentFullNameTextBox.Name = "StudentFullNameTextBox"
        Me.StudentFullNameTextBox.ReadOnly = True
        Me.StudentFullNameTextBox.Size = New System.Drawing.Size(121, 20)
        Me.StudentFullNameTextBox.TabIndex = 39
        '
        'StudentFullNameLabel
        '
        Me.StudentFullNameLabel.AutoSize = True
        Me.StudentFullNameLabel.Location = New System.Drawing.Point(29, 126)
        Me.StudentFullNameLabel.Name = "StudentFullNameLabel"
        Me.StudentFullNameLabel.Size = New System.Drawing.Size(97, 13)
        Me.StudentFullNameLabel.TabIndex = 37
        Me.StudentFullNameLabel.Text = "Student Full Name:"
        '
        'SelectedCourseListDataGridView
        '
        Me.SelectedCourseListDataGridView.AllowUserToAddRows = False
        Me.SelectedCourseListDataGridView.AllowUserToDeleteRows = False
        Me.SelectedCourseListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SelectedCourseListDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CourseNameDataGridViewTextBoxColumn, Me.SectionNameDataGridViewTextBoxColumn, Me.ScheduleNameDataGridViewTextBoxColumn, Me.InstructorNameDataGridViewTextBoxColumn, Me.CourseFeeDataGridViewTextBoxColumn, Me.SelectedCourseListDataGridViewButtonColumn})
        Me.SelectedCourseListDataGridView.Location = New System.Drawing.Point(394, 304)
        Me.SelectedCourseListDataGridView.Name = "SelectedCourseListDataGridView"
        Me.SelectedCourseListDataGridView.Size = New System.Drawing.Size(544, 110)
        Me.SelectedCourseListDataGridView.TabIndex = 47
        '
        'CourseNameDataGridViewTextBoxColumn
        '
        Me.CourseNameDataGridViewTextBoxColumn.DataPropertyName = "CourseName"
        Me.CourseNameDataGridViewTextBoxColumn.HeaderText = "CourseName"
        Me.CourseNameDataGridViewTextBoxColumn.Name = "CourseNameDataGridViewTextBoxColumn"
        Me.CourseNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SectionNameDataGridViewTextBoxColumn
        '
        Me.SectionNameDataGridViewTextBoxColumn.DataPropertyName = "SectionName"
        Me.SectionNameDataGridViewTextBoxColumn.HeaderText = "SectionName"
        Me.SectionNameDataGridViewTextBoxColumn.Name = "SectionNameDataGridViewTextBoxColumn"
        Me.SectionNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ScheduleNameDataGridViewTextBoxColumn
        '
        Me.ScheduleNameDataGridViewTextBoxColumn.DataPropertyName = "ScheduleName"
        Me.ScheduleNameDataGridViewTextBoxColumn.HeaderText = "ScheduleName"
        Me.ScheduleNameDataGridViewTextBoxColumn.Name = "ScheduleNameDataGridViewTextBoxColumn"
        Me.ScheduleNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'InstructorNameDataGridViewTextBoxColumn
        '
        Me.InstructorNameDataGridViewTextBoxColumn.DataPropertyName = "InstructorName"
        Me.InstructorNameDataGridViewTextBoxColumn.HeaderText = "InstructorName"
        Me.InstructorNameDataGridViewTextBoxColumn.Name = "InstructorNameDataGridViewTextBoxColumn"
        Me.InstructorNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CourseFeeDataGridViewTextBoxColumn
        '
        Me.CourseFeeDataGridViewTextBoxColumn.DataPropertyName = "CourseFee"
        Me.CourseFeeDataGridViewTextBoxColumn.HeaderText = "CourseFee"
        Me.CourseFeeDataGridViewTextBoxColumn.Name = "CourseFeeDataGridViewTextBoxColumn"
        Me.CourseFeeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SelectedCourseListDataGridViewButtonColumn
        '
        Me.SelectedCourseListDataGridViewButtonColumn.DataPropertyName = "Drop"
        Me.SelectedCourseListDataGridViewButtonColumn.HeaderText = "Drop"
        Me.SelectedCourseListDataGridViewButtonColumn.Name = "SelectedCourseListDataGridViewButtonColumn"
        Me.SelectedCourseListDataGridViewButtonColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SelectedCourseListDataGridViewButtonColumn.Text = "DROP"
        Me.SelectedCourseListDataGridViewButtonColumn.UseColumnTextForButtonValue = True
        '
        'TransferButton
        '
        Me.TransferButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TransferButton.Location = New System.Drawing.Point(654, 240)
        Me.TransferButton.Name = "TransferButton"
        Me.TransferButton.Size = New System.Drawing.Size(40, 37)
        Me.TransferButton.TabIndex = 48
        Me.TransferButton.Text = " V" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " V"
        Me.TransferButton.UseVisualStyleBackColor = True
        '
        'SaveButton
        '
        Me.SaveButton.Enabled = False
        Me.SaveButton.Location = New System.Drawing.Point(453, 469)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(81, 23)
        Me.SaveButton.TabIndex = 50
        Me.SaveButton.Text = "Register"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'EmailReceiptButton
        '
        Me.EmailReceiptButton.Enabled = False
        Me.EmailReceiptButton.Location = New System.Drawing.Point(610, 469)
        Me.EmailReceiptButton.Name = "EmailReceiptButton"
        Me.EmailReceiptButton.Size = New System.Drawing.Size(81, 23)
        Me.EmailReceiptButton.TabIndex = 51
        Me.EmailReceiptButton.Text = "Email Receipt"
        Me.EmailReceiptButton.UseVisualStyleBackColor = True
        '
        'TotalFeeTextBox
        '
        Me.TotalFeeTextBox.Location = New System.Drawing.Point(841, 429)
        Me.TotalFeeTextBox.Name = "TotalFeeTextBox"
        Me.TotalFeeTextBox.ReadOnly = True
        Me.TotalFeeTextBox.Size = New System.Drawing.Size(97, 20)
        Me.TotalFeeTextBox.TabIndex = 53
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(763, 469)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(81, 23)
        Me.ExitButton.TabIndex = 54
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'GiftNameTextBox
        '
        Me.GiftNameTextBox.Location = New System.Drawing.Point(590, 76)
        Me.GiftNameTextBox.Name = "GiftNameTextBox"
        Me.GiftNameTextBox.ReadOnly = True
        Me.GiftNameTextBox.Size = New System.Drawing.Size(121, 20)
        Me.GiftNameTextBox.TabIndex = 55
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 514)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(160, 15)
        Me.Label2.TabIndex = 59
        Me.Label2.Text = "Youth Empowerment Society"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(820, 514)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CourseEnrollmentForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(976, 538)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Me.GiftNameTextBox)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.TotalFeeTextBox)
        Me.Controls.Add(TotalFeeLabel)
        Me.Controls.Add(Me.EmailReceiptButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(EnrolledCoursesLabel)
        Me.Controls.Add(Me.TransferButton)
        Me.Controls.Add(Me.SelectedCourseListDataGridView)
        Me.Controls.Add(EnrollmentDateLabel)
        Me.Controls.Add(Me.CourseEnrollFormDateTimePicker)
        Me.Controls.Add(RegisteredByLabel)
        Me.Controls.Add(Me.RegisteredByTextBox)
        Me.Controls.Add(Me.StudentIdComboBox)
        Me.Controls.Add(Me.StudentFullNameTextBox)
        Me.Controls.Add(Me.StudentFullNameLabel)
        Me.Controls.Add(StudentIdLabel)
        Me.Controls.Add(Me.ReloadCourseButton)
        Me.Controls.Add(Me.CourseNameLabel)
        Me.Controls.Add(Me.CourseNameComboBox)
        Me.Controls.Add(Me.CoursesListDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CourseEnrollmentForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Course Enrollment"
        CType(Me.CoursesListDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SelectedCourseListDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CoursesListDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents CourseNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CourseNameLabel As System.Windows.Forms.Label
    Friend WithEvents SectionName1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ScheduleName1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstructorName1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CourseFee1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Select1DataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents ReloadCourseButton As System.Windows.Forms.Button
    Friend WithEvents CourseEnrollFormDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents RegisteredByTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentIdComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents StudentFullNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentFullNameLabel As System.Windows.Forms.Label
    Friend WithEvents SelectedCourseListDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TransferButton As System.Windows.Forms.Button
    Friend WithEvents CourseNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SectionNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ScheduleNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InstructorNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CourseFeeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SelectedCourseListDataGridViewButtonColumn As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents EmailReceiptButton As System.Windows.Forms.Button
    Friend WithEvents TotalFeeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents GiftNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class

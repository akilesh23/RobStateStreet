﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : EmailPopUpForm
'Description     : This class contains all the properties of EmailPopUpForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Imports System.IO
Imports System.Text
Imports System.Data
Imports System.Net
Imports System.Net.Mail
Imports System.Web.UI
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.tool.xml
Imports iTextSharp.text.xml.simpleparser

Public Class EmailPopUpForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub SendButton_Click(sender As System.Object, e As System.EventArgs) Handles SendButton.Click

        Try

            Dim EmailStudentListDataTable As New DataTable()

            EmailStudentListDataTable.Columns.AddRange(New DataColumn(13) {New DataColumn("StudentId"), New DataColumn("StudentLastName"), New DataColumn("StudentFirstName"), New DataColumn("StudentDob"), New DataColumn("StudentGender"), New DataColumn("MaritalStatus"), New DataColumn("AddressLine"), New DataColumn("City"), New DataColumn("State"), New DataColumn("PostalCode"), New DataColumn("StudentPhone"), New DataColumn("StudentEmail"), New DataColumn("RegisteredBy"), New DataColumn("RegistrationDt")})

            For i As Integer = 0 To StudentsListByCoursesForm.StudentsDataGridView.RowCount - 1
                EmailStudentListDataTable.Rows.Add(StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentId"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentLastName"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentFirstName"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentDob"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentGender"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("MaritalStatus"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("AddressLine"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("City"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("State"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("PostalCode"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentPhone"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("StudentEmail"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("RegisteredBy"), StudentsListByCoursesForm.StudentsListDataTable.Rows(i)("RegistrationDt"))
            Next

            Using sw As New StringWriter()
                Using hw As New HtmlTextWriter(sw)

                    Dim sb As New StringBuilder()
                    sb.Append("<table width='100%' cellspacing='0' cellpadding='2'>")

                    sb.Append("<tr><td align='center' style='background-color: #18B5F0' colspan = '2'><b>List Of Students Enrolled In " & StudentsListByCoursesForm.CourseNameComboBox.Text & "</b></td></tr>")

                    sb.Append("<tr><td colspan = '2'></td></tr>")
                    sb.Append("<tr><td><b>Course Name: </b>")
                    sb.Append(StudentsListByCoursesForm.CourseNameComboBox.Text)
                    sb.Append("</td><td><b>Date: </b>")
                    sb.Append(DateTime.Now)
                    sb.Append(" </td></tr>")
                    sb.Append("<tr><td colspan = '2'><b>Total Students In This List: </b> ")
                    sb.Append(StudentsListByCoursesForm.StudentsDataGridView.RowCount)
                    sb.Append("</td></tr>")
                    sb.Append("</table>")
                    sb.Append("<br />")
                    sb.Append("<table border = '1'>")
                    sb.Append("<tr>")


                    For Each column As DataColumn In EmailStudentListDataTable.Columns
                        sb.Append("<td>")
                        sb.Append(column.ColumnName)
                        sb.Append("</td>")
                    Next

                    sb.Append("</tr>")
                    For Each row As DataRow In EmailStudentListDataTable.Rows
                        sb.Append("<tr>")
                        For Each column As DataColumn In EmailStudentListDataTable.Columns
                            sb.Append("<td>")
                            sb.Append(row(column))
                            sb.Append("</td>")
                        Next
                        sb.Append("</tr>")
                    Next
                    sb.Append("</table>")

                    Dim sr As New StringReader(sb.ToString())

                    Dim pdfDoc As New Document(PageSize.A3, 10.0F, 10.0F, 10.0F, 0.0F)

                    Dim htmlparser As New HTMLWorker(pdfDoc)

                    Using memoryStream As New MemoryStream()
                        Dim writer As PdfWriter = PdfWriter.GetInstance(pdfDoc, memoryStream)
                        pdfDoc.Open()

                        htmlparser.Parse(sr)

                        pdfDoc.Close()

                        Dim bytes As Byte() = memoryStream.ToArray()
                        memoryStream.Close()

                        Dim mm As New MailMessage("bis635groupfour@gmail.com", "" & Me.EmailAddressTextBox.Text & "")

                        mm.Subject = "" & StudentsListByCoursesForm.CourseNameComboBox.Text & " Students List - Youth Empowerment Society"
                        mm.Body = "Hello! Greetings. Please find the attached Students List for your reference. Thank you. Regards, YES"

                        mm.Attachments.Add(New Attachment(New MemoryStream(bytes), "Students List_" & StudentsListByCoursesForm.CourseNameComboBox.Text & ".pdf"))
                        mm.IsBodyHtml = True

                        Dim smtp As New SmtpClient()
                        smtp.Host = "smtp.gmail.com"
                        smtp.EnableSsl = True

                        Dim NetworkCred As New NetworkCredential()
                        NetworkCred.UserName = "bis635groupfour@gmail.com"
                        NetworkCred.Password = "2179040251"
                        smtp.UseDefaultCredentials = True
                        smtp.Credentials = NetworkCred
                        smtp.Port = 587
                        smtp.Send(mm)

                    End Using
                End Using
            End Using

            MessageBox.Show("Email Sent Successfully!")
            Me.Close()
            StudentsListByCoursesForm.Show()

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
        
    End Sub

End Class
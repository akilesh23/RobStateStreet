﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : StudentsListByCoursesForm
'Description     : This class contains all the properties of StudentsListByCoursesForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class StudentsListByCoursesForm

    Private DBAccess As New DBControl

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Public StudentsListDataTable As New DataTable

    Private Sub StudentsListByCoursesForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub

    Private Sub StudentsListByCoursesForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseNameComboBox.Items.Add(ADataRow("CourseName"))
            Next

            If DBAccess.RecordCount > 0 Then
                CourseNameComboBox.SelectedIndex = -1
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub CourseNameComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseNameComboBox.SelectionChangeCommitted

        DBAccess.ExecuteQuery("SELECT S.* FROM (((Students S INNER JOIN CourseEnrollment CE ON CE.StudentId = S.StudentId) INNER JOIN Sections Sec ON Sec.SectionId = CE.SectionId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) WHERE OC.CourseName = '" & CourseNameComboBox.Text & "' ORDER BY S.StudentId ASC")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        If DBAccess.RecordCount = 0 Then
            MessageBox.Show("Sorry, No Student Record Found For The Course Chosen!")
        End If

        StudentsDataGridView.DataSource = DBAccess.DBDataTable

        StudentsListDataTable = DBAccess.DBDataTable

    End Sub

    Private Sub EmailStudentsListToClientButton_Click(sender As System.Object, e As System.EventArgs) Handles EmailStudentsListToClientButton.Click
        EmailPopUpForm.Show()
    End Sub

    Private Sub CloseButton_Click(sender As System.Object, e As System.EventArgs) Handles CloseButton.Click
        Me.Close()
        MainMenuForm.Show()
    End Sub

End Class
﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : StudentRegistrationForm
'Description     : This class contains all the properties of StudentRegistrationForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class StudentRegistrationForm

    Public MaxStuId As String
    Public NewStuId As String

    Private DBAccess As New DBControl

    Private Sub StudentRegistrationForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainMenuForm.Show()
    End Sub

    Private Sub StudentRegistrationForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        Me.RegistrationDateTimePicker.Value = Today

        Me.StudentIdTextBox.ReadOnly = True

        'RegisteredBy Employee ID populates onto the RegisteredByTextBox based on Login ID when successful login takes place
        Me.RegisteredByNameTextBox.Text = LoginForm.LoggedInEmpFullName
        Me.RegisteredByNameTextBox.ReadOnly = True

        If Me.SaveButton.Text = "Save" Then

            DBAccess.ExecuteQuery("SELECT * FROM Students")

            If DBAccess.RecordCount = 0 Then
                StudentIdTextBox.Text = 1
            Else
                DBAccess.ExecuteQuery("SELECT MAX(StudentId) AS MaxStuIdFromDB FROM Students")
                MaxStuId = DBAccess.DBDataTable.Rows(0).Item("MaxStuIdFromDB")
                NewStuId = MaxStuId + 1
                StudentIdTextBox.Text = NewStuId
            End If

        End If

    End Sub

    Private Sub SaveButton_Click(sender As System.Object, e As System.EventArgs) Handles SaveButton.Click

        SaveStudentDetails(StudentIdTextBox.Text, StudentLastNameTextBox.Text, StudentFirstNameTextBox.Text, StudentDobDateTimePicker.Text, StudentGenderComboBox.Text, MaritalStatusComboBox.Text, AddressLineTextBox.Text, CityTextBox.Text, StateTextBox.Text, PostalCodeTextBox.Text, StudentPhoneTextBox.Text, StudentEmailTextBox.Text, LoginForm.LoggedInEmpId, RegistrationDateTimePicker.Text)

    End Sub

    Private Sub SaveStudentDetails(StudentId As Integer, StudentLastName As String, StudentFirstName As String, StudentDob As Date, StudentGender As String, MaritalStatus As String, AddressLine As String, City As String, State As String, PostalCode As String, StudentPhone As String, StudentEmail As String, RegisteredBy As Integer, RegistrationDate As Date)

        Try

            If Me.SaveButton.Text = "Save" Then
                'Add parameters and run query 
                DBAccess.AddParam("@StudentId", StudentId)
                DBAccess.AddParam("@StudentLastName", StudentLastName)
                DBAccess.AddParam("@StudentFirstName", StudentFirstName)
                DBAccess.AddParam("@StudentDob", StudentDob)
                DBAccess.AddParam("@StudentGender", StudentGender)
                DBAccess.AddParam("@MaritalStatus", MaritalStatus)
                DBAccess.AddParam("@AddressLine", AddressLine)
                DBAccess.AddParam("@City", City)
                DBAccess.AddParam("@State", State)
                DBAccess.AddParam("@PostalCode", PostalCode)
                DBAccess.AddParam("@StudentPhone", StudentPhone)
                DBAccess.AddParam("@StudentEmail", StudentEmail)
                DBAccess.AddParam("@RegisteredBy", RegisteredBy)
                DBAccess.AddParam("@RegistrationDate", RegistrationDate)

                DBAccess.ExecuteQuery("INSERT INTO Students(StudentId,StudentLastName,StudentFirstName,StudentDob,StudentGender,MaritalStatus,AddressLine,City,State,PostalCode,StudentPhone,StudentEmail,RegisteredBy,RegistrationDt) values(@StudentId,@StudentLastName,@StudentFirstName,@StudentDob,@StudentGender,@MaritalStatus,@AddressLine,@City,@State,@PostalCode,@StudentPhone,@StudentEmail,@RegisteredBy,@RegistrationDate)")

                MessageBox.Show("Student Details Saved Successfully!")
                Call Clear()
                Me.Close()
                MainMenuForm.Show()

            ElseIf Me.SaveButton.Text = "Update" Then

                DBAccess.AddParam("@StudentLastName", StudentLastName)
                DBAccess.AddParam("@StudentFirstName", StudentFirstName)
                DBAccess.AddParam("@StudentDob", StudentDob)
                DBAccess.AddParam("@StudentGender", StudentGender)
                DBAccess.AddParam("@MaritalStatus", MaritalStatus)
                DBAccess.AddParam("@AddressLine", AddressLine)
                DBAccess.AddParam("@City", City)
                DBAccess.AddParam("@State", State)
                DBAccess.AddParam("@PostalCode", PostalCode)
                DBAccess.AddParam("@StudentPhone", StudentPhone)
                DBAccess.AddParam("@StudentEmail", StudentEmail)
                DBAccess.AddParam("@RegisteredBy", RegisteredBy)
                DBAccess.AddParam("@RegistrationDate", RegistrationDate)

                DBAccess.ExecuteQuery("UPDATE Students SET StudentLastName=@StudentLastName,StudentFirstName=@StudentFirstName,StudentDob=@StudentDob,StudentGender=@StudentGender,MaritalStatus=@MaritalStatus,AddressLine=@AddressLine,City=@City,State=@State,PostalCode=@PostalCode,StudentPhone=@StudentPhone,StudentEmail=@StudentEmail,RegisteredBy=@RegisteredBy,RegistrationDt=@RegistrationDate WHERE StudentId=" & Integer.Parse(StudentIdTextBox.Text) & "")

                MessageBox.Show("Student Details Updated Successfully!")
                Call Clear()
                Me.Close()
                MainMenuForm.Show()

            End If

        Catch ex As Exception
            MessageBox.Show(DBAccess.Exception)
        End Try

    End Sub

    Sub Clear()

        Me.StudentLastNameTextBox.Clear()
        Me.StudentFirstNameTextBox.Clear()
        Me.StudentDobDateTimePicker.Text = ""
        Me.StudentGenderComboBox.Text = ""
        Me.MaritalStatusComboBox.Text = ""
        Me.AddressLineTextBox.Clear()
        Me.CityTextBox.Clear()
        Me.StateTextBox.Clear()
        Me.PostalCodeTextBox.Clear()
        Me.StudentPhoneTextBox.Clear()
        Me.StudentEmailTextBox.Clear()

    End Sub

    Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
        e.Cancel = False
        MainMenuForm.Show()
    End Sub

    Private Sub ClearButton_Click(sender As System.Object, e As System.EventArgs) Handles ClearButton.Click
        ErrorProvider.Clear()
        Call Clear()
    End Sub

    'Error Provider
    Private Sub StudentFirstNameTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StudentFirstNameTextBox.Validating
        If StudentFirstNameTextBox.Text = "" Then
            ErrorProvider.SetError(StudentFirstNameTextBox, "Student First Name field cannot be empty.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub StudentLastNameTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StudentLastNameTextBox.Validating
        If StudentLastNameTextBox.Text = "" Then
            ErrorProvider.SetError(StudentLastNameTextBox, "Student Last Name field cannot be empty.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub AddressLineTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles AddressLineTextBox.Validating
        If AddressLineTextBox.Text = "" Then
            ErrorProvider.SetError(AddressLineTextBox, "Address Line field cannot be empty.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub CityTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles CityTextBox.Validating
        If CityTextBox.Text = "" Then
            ErrorProvider.SetError(CityTextBox, "City field cannot be empty.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub StateTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StateTextBox.Validating
        If StateTextBox.Text = "" Then
            ErrorProvider.SetError(StateTextBox, "State field cannot be empty.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub PostalCodeTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles PostalCodeTextBox.Validating
        If Not IsNumeric(PostalCodeTextBox.Text) Then
            ErrorProvider.SetError(PostalCodeTextBox, "Postal Code Should Be Numeric.")
            e.Cancel = True
        ElseIf PostalCodeTextBox.Text.Length <> "6" Then
            ErrorProvider.SetError(PostalCodeTextBox, "Postal Code should be of 6 digits.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub StudentGenderComboBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StudentGenderComboBox.Validating
        If StudentGenderComboBox.Text = "" Then
            ErrorProvider.SetError(StudentGenderComboBox, "Please Select The Student's Gender.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub MaritalStatusComboBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MaritalStatusComboBox.Validating
        If MaritalStatusComboBox.Text = "" Then
            ErrorProvider.SetError(MaritalStatusComboBox, "Please Select The Student's Marital Status.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False
        End If
    End Sub

    Private Sub StudentPhoneTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StudentPhoneTextBox.Validating
        If Not IsNumeric(StudentPhoneTextBox.Text) Then
            ErrorProvider.SetError(StudentPhoneTextBox, "Phone Number Should Be Numeric.")
            e.Cancel = True
        ElseIf StudentPhoneTextBox.Text.Length <> "10" Then
            ErrorProvider.SetError(StudentPhoneTextBox, "Phone Number Should Be of 10 Digits.")
            e.Cancel = True
        Else
            ErrorProvider.Clear()
            e.Cancel = False

        End If
    End Sub

    Private Sub StudentEmailTextBox_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles StudentEmailTextBox.Validating

        If StudentEmailTextBox.Text = "" Then
            ErrorProvider.Clear()
            e.Cancel = False
        Else
            Try
                ErrorProvider.Clear()
                e.Cancel = False
                Dim testAddress = New Net.Mail.MailAddress(StudentEmailTextBox.Text)
            Catch ex As FormatException
                ErrorProvider.SetError(StudentEmailTextBox, "Invalid E-Mail Address.")
                e.Cancel = True
            End Try
        End If

    End Sub

End Class
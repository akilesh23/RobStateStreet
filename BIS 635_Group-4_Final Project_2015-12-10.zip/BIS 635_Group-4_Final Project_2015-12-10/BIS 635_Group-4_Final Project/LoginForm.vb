﻿'***************************************************************************************************
'                               YOUTH EMPOWERMENT SOCIETY © 2015
'---------------------------------------------------------------------------------------------------
'Project         : Youth Empowerment Society - Student Database Management System
'Programmers     : BIS 635 Group-4
'Delivery Date   : December 10th, 2015
'Class           : LoginForm
'Description     : This class contains all the properties of LoginForm.
'Project Manager : Dr. Zhenyu Huang
'***************************************************************************************************

Public Class LoginForm

    Public LoggedInEmpId As Integer
    Public LoggedInEmpFullName As String
    Private DBAccess As New DBControl 'DBAccess is an instance of the DBControl data tier.  

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function

    Private Sub LoginForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Application.Exit()
    End Sub

    Private Sub LoginForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        Me.UserNameTextBox.Focus()
        Me.UserNameTextBox.Text = "1" 'Hard-Coded for you to easily login into the system.
        Me.PasswordTextBox.Text = "1" 'Hard-Coded for you to easily login into the system.
        Me.AcceptButton = LoginButton
        Me.CancelButton = ExitButton

    End Sub

    Private Sub LoginButton_Click(sender As System.Object, e As System.EventArgs) Handles LoginButton.Click

        If UserNameTextBox.Text = "" Then
            MessageBox.Show("Please Enter Your User Name")
        ElseIf PasswordTextBox.Text = "" Then
            MessageBox.Show("Please Enter Your Password")
        Else
            EmployeeLogin(UserNameTextBox.Text, PasswordTextBox.Text)
        End If

    End Sub


    Private Sub EmployeeLogin(EmpId As Integer, EmpPwd As String)

        DBAccess.ExecuteQuery("SELECT * FROM Employees WHERE EmployeeId =  " & EmpId & "  AND EmployeePassword = '" & EmpPwd & "' ")

        'report & abort on errors 
        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        Try

            If (DBAccess.RecordCount > 0) Then

                MessageBox.Show("Login Successful!")
                MainMenuForm.Show()
                Me.UserNameTextBox.Clear()
                Me.PasswordTextBox.Clear()
                Me.Hide()
                LoggedInEmpId = DBAccess.DBDataTable.Rows(0).Item("EmployeeId")
                LoggedInEmpFullName = DBAccess.DBDataTable.Rows(0).Item("EmployeeFirstName") & " " & DBAccess.DBDataTable.Rows(0).Item("EmployeeLastName")

            Else
                MessageBox.Show("Invalid username or password!")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ExitButton_Click(sender As System.Object, e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

    Private Sub ResetButton_Click(sender As System.Object, e As System.EventArgs) Handles ResetButton.Click
        UserNameTextBox.Clear()
        PasswordTextBox.Clear()
    End Sub

End Class

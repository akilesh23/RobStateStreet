﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RecordAttendanceForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim SectionNameLabel As System.Windows.Forms.Label
        Dim CourseIdLabel As System.Windows.Forms.Label
        Dim AttendanceDateLabel As System.Windows.Forms.Label
        Dim CourseNameLabel As System.Windows.Forms.Label
        Dim SectionIdLabel As System.Windows.Forms.Label
        Dim StudentsEnrolledLabel As System.Windows.Forms.Label
        Me.SectionNameComboBox = New System.Windows.Forms.ComboBox()
        Me.SubmitButton = New System.Windows.Forms.Button()
        Me.RecordAttendanceDataGridView = New System.Windows.Forms.DataGridView()
        Me.StudentIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentLastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentFirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PresentDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.AttendanceDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.CourseNameComboBox = New System.Windows.Forms.ComboBox()
        Me.CourseIdTextBox = New System.Windows.Forms.TextBox()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.SectionIdTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        SectionNameLabel = New System.Windows.Forms.Label()
        CourseIdLabel = New System.Windows.Forms.Label()
        AttendanceDateLabel = New System.Windows.Forms.Label()
        CourseNameLabel = New System.Windows.Forms.Label()
        SectionIdLabel = New System.Windows.Forms.Label()
        StudentsEnrolledLabel = New System.Windows.Forms.Label()
        CType(Me.RecordAttendanceDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SectionNameLabel
        '
        SectionNameLabel.AutoSize = True
        SectionNameLabel.Location = New System.Drawing.Point(25, 130)
        SectionNameLabel.Name = "SectionNameLabel"
        SectionNameLabel.Size = New System.Drawing.Size(77, 13)
        SectionNameLabel.TabIndex = 3
        SectionNameLabel.Text = "Section Name:"
        '
        'CourseIdLabel
        '
        CourseIdLabel.AutoSize = True
        CourseIdLabel.Location = New System.Drawing.Point(263, 64)
        CourseIdLabel.Name = "CourseIdLabel"
        CourseIdLabel.Size = New System.Drawing.Size(55, 13)
        CourseIdLabel.TabIndex = 1
        CourseIdLabel.Text = "Course Id:"
        '
        'AttendanceDateLabel
        '
        AttendanceDateLabel.AutoSize = True
        AttendanceDateLabel.Location = New System.Drawing.Point(80, 207)
        AttendanceDateLabel.Name = "AttendanceDateLabel"
        AttendanceDateLabel.Size = New System.Drawing.Size(73, 13)
        AttendanceDateLabel.TabIndex = 10
        AttendanceDateLabel.Text = "Today's Date:"
        '
        'CourseNameLabel
        '
        CourseNameLabel.AutoSize = True
        CourseNameLabel.Location = New System.Drawing.Point(25, 64)
        CourseNameLabel.Name = "CourseNameLabel"
        CourseNameLabel.Size = New System.Drawing.Size(74, 13)
        CourseNameLabel.TabIndex = 11
        CourseNameLabel.Text = "Course Name:"
        '
        'SectionIdLabel
        '
        SectionIdLabel.AutoSize = True
        SectionIdLabel.Location = New System.Drawing.Point(263, 130)
        SectionIdLabel.Name = "SectionIdLabel"
        SectionIdLabel.Size = New System.Drawing.Size(58, 13)
        SectionIdLabel.TabIndex = 18
        SectionIdLabel.Text = "Section Id:"
        '
        'StudentsEnrolledLabel
        '
        StudentsEnrolledLabel.AutoSize = True
        StudentsEnrolledLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        StudentsEnrolledLabel.Location = New System.Drawing.Point(546, 30)
        StudentsEnrolledLabel.Name = "StudentsEnrolledLabel"
        StudentsEnrolledLabel.Size = New System.Drawing.Size(172, 25)
        StudentsEnrolledLabel.TabIndex = 22
        StudentsEnrolledLabel.Text = "Students Enrolled:"
        '
        'SectionNameComboBox
        '
        Me.SectionNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SectionNameComboBox.FormattingEnabled = True
        Me.SectionNameComboBox.Location = New System.Drawing.Point(118, 127)
        Me.SectionNameComboBox.Name = "SectionNameComboBox"
        Me.SectionNameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.SectionNameComboBox.TabIndex = 4
        '
        'SubmitButton
        '
        Me.SubmitButton.Location = New System.Drawing.Point(151, 368)
        Me.SubmitButton.Name = "SubmitButton"
        Me.SubmitButton.Size = New System.Drawing.Size(75, 23)
        Me.SubmitButton.TabIndex = 6
        Me.SubmitButton.Text = "Submit"
        Me.SubmitButton.UseVisualStyleBackColor = True
        '
        'RecordAttendanceDataGridView
        '
        Me.RecordAttendanceDataGridView.AllowUserToAddRows = False
        Me.RecordAttendanceDataGridView.AllowUserToDeleteRows = False
        Me.RecordAttendanceDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RecordAttendanceDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudentIdDataGridViewTextBoxColumn, Me.StudentLastNameDataGridViewTextBoxColumn, Me.StudentFirstNameDataGridViewTextBoxColumn, Me.PresentDataGridViewCheckBoxColumn})
        Me.RecordAttendanceDataGridView.Location = New System.Drawing.Point(549, 61)
        Me.RecordAttendanceDataGridView.Name = "RecordAttendanceDataGridView"
        Me.RecordAttendanceDataGridView.Size = New System.Drawing.Size(445, 408)
        Me.RecordAttendanceDataGridView.TabIndex = 8
        '
        'StudentIdDataGridViewTextBoxColumn
        '
        Me.StudentIdDataGridViewTextBoxColumn.DataPropertyName = "StudentId"
        Me.StudentIdDataGridViewTextBoxColumn.HeaderText = "Student ID"
        Me.StudentIdDataGridViewTextBoxColumn.Name = "StudentIdDataGridViewTextBoxColumn"
        Me.StudentIdDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StudentLastNameDataGridViewTextBoxColumn
        '
        Me.StudentLastNameDataGridViewTextBoxColumn.DataPropertyName = "StudentLastName"
        Me.StudentLastNameDataGridViewTextBoxColumn.HeaderText = "Student Last Name"
        Me.StudentLastNameDataGridViewTextBoxColumn.Name = "StudentLastNameDataGridViewTextBoxColumn"
        Me.StudentLastNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StudentFirstNameDataGridViewTextBoxColumn
        '
        Me.StudentFirstNameDataGridViewTextBoxColumn.DataPropertyName = "StudentFirstName"
        Me.StudentFirstNameDataGridViewTextBoxColumn.HeaderText = "Student First Name"
        Me.StudentFirstNameDataGridViewTextBoxColumn.Name = "StudentFirstNameDataGridViewTextBoxColumn"
        Me.StudentFirstNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PresentDataGridViewCheckBoxColumn
        '
        Me.PresentDataGridViewCheckBoxColumn.DataPropertyName = "Present"
        Me.PresentDataGridViewCheckBoxColumn.HeaderText = "Is the Student Present Today?"
        Me.PresentDataGridViewCheckBoxColumn.Name = "PresentDataGridViewCheckBoxColumn"
        '
        'AttendanceDateTimePicker
        '
        Me.AttendanceDateTimePicker.Location = New System.Drawing.Point(198, 203)
        Me.AttendanceDateTimePicker.Name = "AttendanceDateTimePicker"
        Me.AttendanceDateTimePicker.Size = New System.Drawing.Size(211, 20)
        Me.AttendanceDateTimePicker.TabIndex = 9
        '
        'CourseNameComboBox
        '
        Me.CourseNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CourseNameComboBox.FormattingEnabled = True
        Me.CourseNameComboBox.Location = New System.Drawing.Point(118, 61)
        Me.CourseNameComboBox.Name = "CourseNameComboBox"
        Me.CourseNameComboBox.Size = New System.Drawing.Size(121, 21)
        Me.CourseNameComboBox.TabIndex = 12
        '
        'CourseIdTextBox
        '
        Me.CourseIdTextBox.Location = New System.Drawing.Point(356, 61)
        Me.CourseIdTextBox.Name = "CourseIdTextBox"
        Me.CourseIdTextBox.ReadOnly = True
        Me.CourseIdTextBox.Size = New System.Drawing.Size(121, 20)
        Me.CourseIdTextBox.TabIndex = 13
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(266, 368)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 14
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(371, 368)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 15
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'SectionIdTextBox
        '
        Me.SectionIdTextBox.Location = New System.Drawing.Point(356, 127)
        Me.SectionIdTextBox.Name = "SectionIdTextBox"
        Me.SectionIdTextBox.ReadOnly = True
        Me.SectionIdTextBox.Size = New System.Drawing.Size(121, 20)
        Me.SectionIdTextBox.TabIndex = 19
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(880, 504)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(144, 15)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "© 2015 BIS 635 Group-4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 504)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 15)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "Youth Empowerment Society"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RecordAttendanceForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1036, 528)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(StudentsEnrolledLabel)
        Me.Controls.Add(Me.SectionIdTextBox)
        Me.Controls.Add(SectionIdLabel)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CourseIdTextBox)
        Me.Controls.Add(CourseNameLabel)
        Me.Controls.Add(Me.CourseNameComboBox)
        Me.Controls.Add(AttendanceDateLabel)
        Me.Controls.Add(Me.AttendanceDateTimePicker)
        Me.Controls.Add(Me.RecordAttendanceDataGridView)
        Me.Controls.Add(Me.SubmitButton)
        Me.Controls.Add(SectionNameLabel)
        Me.Controls.Add(Me.SectionNameComboBox)
        Me.Controls.Add(CourseIdLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "RecordAttendanceForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Record Attendance"
        CType(Me.RecordAttendanceDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SectionNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents SubmitButton As System.Windows.Forms.Button
    Friend WithEvents RecordAttendanceDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents AttendanceDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents CourseNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CourseIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents StudentIdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentLastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentFirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PresentDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents SectionIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class

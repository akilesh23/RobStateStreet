﻿Public Class CourseEnrollForm

    Private DBAccess As New DBControl

    Private rr1 As New DataGridViewRow
    Private rr2 As New DataGridViewRow
    Private rr3 As New DataGridViewRow

    Private Function NotEmpty(text As String) As Boolean
        Return Not String.IsNullOrEmpty(text)
    End Function


    Private Sub CourseEnrollForm_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        RegisteredByTextBox.Text = LoginForm.LoggedInEmpFullName
        RegisteredByTextBox.ReadOnly = True

        DBAccess.ExecuteQuery("SELECT * FROM Students")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
            StudentIdComboBox.Items.Add(ADataRow("StudentId"))
        Next

        'display first StudentFirstName  
        If DBAccess.RecordCount > 0 Then
            'Nothing should be displayed in the Combo Box initially!
            StudentIdComboBox.SelectedIndex = -1
        End If


        LoadCourseName1ComboBox()
        LoadCourseName2ComboBox()
        LoadCourseName3ComboBox()
    End Sub


    Private Sub StudentIdComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles StudentIdComboBox.SelectionChangeCommitted

        DBAccess.ExecuteQuery("SELECT * FROM Students WHERE StudentId = " & StudentIdComboBox.Text & "")

        StudentFullNameTextBox.Text = DBAccess.DBDataTable.Rows(0).Item("StudentFirstName") & " " & DBAccess.DBDataTable.Rows(0).Item("StudentLastName")

        LoadSelectedCourseListDataGridView()

    End Sub


    Private Sub LoadSelectedCourseListDataGridView()

        DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")
        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable




        'For Each r4 As DataGridViewRow In SelectedCourseListDataGridView.Rows
        '    r4.Cells(0).Value = True
        '    r4.Cells(0).ReadOnly = True
        'Next


        'For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1
        '    SelectedCourseListDataGridView.Rows(i).Cells(0).Value = True
        '    SelectedCourseListDataGridView.Rows(i).Cells(0).ReadOnly = True
        'Next


    End Sub


    Private Sub SelectedCourseListDataGridView_CellContentClick1(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles SelectedCourseListDataGridView.CellContentClick

        If TypeOf SelectedCourseListDataGridView.Columns(e.ColumnIndex) Is DataGridViewButtonColumn AndAlso e.RowIndex >= 0 Then

            If e.RowIndex = 0 Then

                DBAccess.ExecuteQuery("DELETE * FROM CourseEnrollment WHERE StudentId = " & StudentIdComboBox.Text & " AND SectionId = (SELECT SectionId FROM Sections WHERE SectionName = '" & SelectedCourseListDataGridView.CurrentRow.Cells(2).Value & "')")

                If NotEmpty(DBAccess.Exception) Then
                    MessageBox.Show(DBAccess.Exception)
                    Exit Sub
                End If

            End If

            If e.RowIndex = 1 Then

                DBAccess.ExecuteQuery("DELETE * FROM CourseEnrollment WHERE StudentId = " & StudentIdComboBox.Text & " AND SectionId = (SELECT SectionId FROM Sections WHERE SectionName = '" & SelectedCourseListDataGridView.CurrentRow.Cells(2).Value & "')")

                If NotEmpty(DBAccess.Exception) Then
                    MessageBox.Show(DBAccess.Exception)
                    Exit Sub
                End If

            End If

            If e.RowIndex = 2 Then

                DBAccess.ExecuteQuery("DELETE * FROM CourseEnrollment WHERE StudentId = " & StudentIdComboBox.Text & " AND SectionId = (SELECT SectionId FROM Sections WHERE SectionName = '" & SelectedCourseListDataGridView.CurrentRow.Cells(2).Value & "')")

                If NotEmpty(DBAccess.Exception) Then
                    MessageBox.Show(DBAccess.Exception)
                    Exit Sub
                End If

            End If
        End If

        LoadSelectedCourseListDataGridView()


    End Sub



    Private Sub LoadCourseName1ComboBox()

        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseName1ComboBox.Items.Add(ADataRow("CourseName"))
            Next


            If DBAccess.RecordCount > 0 Then
                CourseName1ComboBox.SelectedIndex = -1
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub LoadCourseName2ComboBox()

        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseName2ComboBox.Items.Add(ADataRow("CourseName"))
            Next


            If DBAccess.RecordCount > 0 Then
                CourseName2ComboBox.SelectedIndex = -1
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub LoadCourseName3ComboBox()

        Try

            DBAccess.ExecuteQuery("SELECT CourseName FROM OfferedCourses")

            If NotEmpty(DBAccess.Exception) Then
                MessageBox.Show(DBAccess.Exception)
                Exit Sub
            End If

            For Each ADataRow As DataRow In DBAccess.DBDataTable.Rows
                CourseName3ComboBox.Items.Add(ADataRow("CourseName"))
            Next


            If DBAccess.RecordCount > 0 Then
                CourseName3ComboBox.SelectedIndex = -1
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub



    Private Sub CourseName1ComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseName1ComboBox.SelectionChangeCommitted
        'Course1DataGridView.DataSource = Nothing
        'Course1DataGridView.Rows.Clear()
        Try

            If CourseName1ComboBox.Text = CourseName2ComboBox.Text Or CourseName1ComboBox.Text = CourseName3ComboBox.Text Then

                MessageBox.Show("You have already selected this course. Please select a different course!")

                CourseName1ComboBox.Items.Clear()

                If Course1DataGridView.RowCount > 0 Then

                    Course1DataGridView.DataSource.Clear()

                End If

                LoadCourseName1ComboBox()

            Else

                LoadDataGridView1()

            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub LoadDataGridView1()

        DBAccess.ExecuteQuery("SELECT Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId)INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) WHERE OC.CourseName = '" & CourseName1ComboBox.Text & "' ")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        If DBAccess.RecordCount = 0 Then
            MessageBox.Show("Sorry, No Sections found for the Selected Course!")
        End If

        Course1DataGridView.DataSource = DBAccess.DBDataTable


    End Sub

    Private Sub ReloadCourse1Button_Click(sender As System.Object, e As System.EventArgs) Handles ReloadCourse1Button.Click

        CourseName1ComboBox.Items.Clear()

        If Course1DataGridView.RowCount > 0 Then

            Course1DataGridView.DataSource.Clear() 'Changed From Course1DataGridView.DataSource.clear()

        End If

        LoadCourseName1ComboBox()

    End Sub


    Private Sub CourseName2ComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseName2ComboBox.SelectionChangeCommitted

        Try
            If CourseName2ComboBox.Text = CourseName1ComboBox.Text Or CourseName2ComboBox.Text = CourseName3ComboBox.Text Then

                MessageBox.Show("You have already selected this course. Please select a different course!")

                CourseName2ComboBox.Items.Clear()

                If Course2DataGridView.RowCount > 0 Then

                    Course2DataGridView.DataSource.Clear()

                End If

                LoadCourseName2ComboBox()
            Else

                LoadDataGridView2()

            End If
        Catch ex As Exception

        End Try
        

    End Sub


    Private Sub LoadDataGridView2()

        DBAccess.ExecuteQuery("SELECT Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId)INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) WHERE OC.CourseName = '" & CourseName2ComboBox.Text & "' ")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        If DBAccess.RecordCount = 0 Then
            MessageBox.Show("Sorry, No Sections found for the Selected Course!")
        End If

        Course2DataGridView.DataSource = DBAccess.DBDataTable

    End Sub

    Private Sub ReloadCourse2Button_Click(sender As System.Object, e As System.EventArgs) Handles ReloadCourse2Button.Click

        CourseName2ComboBox.Items.Clear()

        If Course2DataGridView.RowCount > 0 Then

            Course2DataGridView.DataSource.Clear()

        End If

        LoadCourseName2ComboBox()

    End Sub


    Private Sub CourseName3ComboBox_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles CourseName3ComboBox.SelectionChangeCommitted
        Try

            If CourseName3ComboBox.Text = CourseName1ComboBox.Text Or CourseName3ComboBox.Text = CourseName2ComboBox.Text Then

                MessageBox.Show("You have already selected this course. Please select a different course!")

                CourseName3ComboBox.Items.Clear()

                If Course3DataGridView.RowCount > 0 Then
                    Course3DataGridView.DataSource.Clear()
                End If

                LoadCourseName3ComboBox()

            Else
                LoadDataGridView3()
            End If

        Catch ex As Exception

        End Try

    End Sub


    Private Sub LoadDataGridView3()

        DBAccess.ExecuteQuery("SELECT Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId)INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) WHERE OC.CourseName = '" & CourseName3ComboBox.Text & "' ")

        If NotEmpty(DBAccess.Exception) Then
            MessageBox.Show(DBAccess.Exception)
            Exit Sub
        End If

        If DBAccess.RecordCount = 0 Then
            MessageBox.Show("Sorry, No Sections found for the Selected Course!")
        End If

        Course3DataGridView.DataSource = DBAccess.DBDataTable

    End Sub


    Private Sub ReloadCourse3Button_Click(sender As System.Object, e As System.EventArgs) Handles ReloadCourse3Button.Click
        CourseName3ComboBox.Items.Clear()

        If Course3DataGridView.RowCount > 0 Then
            Course3DataGridView.DataSource.Clear()
        End If

        LoadCourseName3ComboBox()

    End Sub

    Private Sub Course1DataGridView_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course1DataGridView.CellClick


        'If TypeOf Course1DataGridView.Columns(e.ColumnIndex) Is DataGridViewCheckBoxColumn AndAlso e.RowIndex >= 0 Then

        'End If---------------> ADD THIS WHEN YOU HAVE TIME

        'Making CheckBoxes To Work like Radio Buttons!
        For Each r1 As DataGridViewRow In Course1DataGridView.Rows

            If r1.Index = e.RowIndex Then
                r1.Cells(0).Value = True
                r1.Cells(0).ReadOnly = True
            Else
                r1.Cells(0).Value = False
                r1.Cells(0).ReadOnly = False
            End If

        Next


        'Comparing with other DataGridView Cell Values
        If Course1DataGridView.RowCount > 0 And Course2DataGridView.RowCount > 0 Then

            For i = 0 To Course2DataGridView.Rows.Count - 1

                If (Course1DataGridView.CurrentRow.Cells(2).Value = Course2DataGridView.Rows(i).Cells(2).Value) And (Course2DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course1DataGridView.CurrentRow.Cells(0).Value = False
                    Course1DataGridView.EndEdit()
                End If
            Next

        End If

        If Course1DataGridView.RowCount > 0 And Course3DataGridView.RowCount > 0 Then

            For i = 0 To Course3DataGridView.Rows.Count - 1

                If (Course1DataGridView.CurrentRow.Cells(2).Value = Course3DataGridView.Rows(i).Cells(2).Value) And (Course3DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course1DataGridView.CurrentRow.Cells(0).Value = False
                    Course1DataGridView.EndEdit()
                End If
            Next

        End If


    End Sub

    Private Sub Course1DataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course1DataGridView.CellContentClick

        'For i = 0 To Course2DataGridView.Rows.Count - 1

        '    If (Course1DataGridView.CurrentRow.Cells(2).Value = Course2DataGridView.Rows(i).Cells(2).Value) And (Course2DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course1DataGridView.CurrentRow.Cells(0).Value = False
        '        Course1DataGridView.EndEdit()
        '    End If
        'Next

        'For i = 0 To Course3DataGridView.Rows.Count - 1

        '    If (Course1DataGridView.CurrentRow.Cells(2).Value = Course3DataGridView.Rows(i).Cells(2).Value) And (Course3DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course1DataGridView.CurrentRow.Cells(0).Value = False
        '        Course1DataGridView.EndEdit()
        '    End If
        'Next

    End Sub

    Private Sub Course2DataGridView_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course2DataGridView.CellClick
        'Making CheckBoxes To Work like Radio Buttons!
        For Each r2 As DataGridViewRow In Course2DataGridView.Rows
            If r2.Index = e.RowIndex Then
                r2.Cells(0).Value = True
                r2.Cells(0).ReadOnly = True
            Else
                r2.Cells(0).Value = False
                r2.Cells(0).ReadOnly = False
            End If
        Next



        'Comparing with other DataGridView Cell Values
        If Course1DataGridView.RowCount > 0 And Course2DataGridView.RowCount > 0 Then

            For i = 0 To Course1DataGridView.Rows.Count - 1

                If (Course2DataGridView.CurrentRow.Cells(2).Value = Course1DataGridView.Rows(i).Cells(2).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course2DataGridView.CurrentRow.Cells(0).Value = False
                    Course2DataGridView.EndEdit()
                End If
            Next
        End If

        If Course2DataGridView.RowCount > 0 And Course3DataGridView.RowCount > 0 Then

            For i = 0 To Course3DataGridView.Rows.Count - 1

                If (Course2DataGridView.CurrentRow.Cells(2).Value = Course3DataGridView.Rows(i).Cells(2).Value) And (Course3DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course2DataGridView.CurrentRow.Cells(0).Value = False
                    Course2DataGridView.EndEdit()
                End If
            Next

        End If
       
    End Sub


    Private Sub Course2DataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course2DataGridView.CellContentClick

        'For i = 0 To Course1DataGridView.Rows.Count - 1

        '    If (Course2DataGridView.CurrentRow.Cells(2).Value = Course1DataGridView.Rows(i).Cells(2).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course2DataGridView.CurrentRow.Cells(0).Value = False
        '        Course2DataGridView.EndEdit()
        '    End If
        'Next


        'For i = 0 To Course3DataGridView.Rows.Count - 1

        '    If (Course2DataGridView.CurrentRow.Cells(2).Value = Course3DataGridView.Rows(i).Cells(2).Value) And (Course3DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course2DataGridView.CurrentRow.Cells(0).Value = False
        '        Course2DataGridView.EndEdit()
        '    End If
        'Next


    End Sub

    Private Sub Course3DataGridView_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course3DataGridView.CellClick
        'Making CheckBoxes To Work like Radio Buttons!
        For Each r3 As DataGridViewRow In Course3DataGridView.Rows
            If r3.Index = e.RowIndex Then
                r3.Cells(0).Value = True
                r3.Cells(0).ReadOnly = True
            Else
                r3.Cells(0).Value = False
                r3.Cells(0).ReadOnly = False
            End If
        Next




        'Comparing with other DataGridView Cell Values

        If Course1DataGridView.RowCount > 0 And Course3DataGridView.RowCount > 0 Then

            For i = 0 To Course1DataGridView.Rows.Count - 1

                If (Course3DataGridView.CurrentRow.Cells(2).Value = Course1DataGridView.Rows(i).Cells(2).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course3DataGridView.CurrentRow.Cells(0).Value = False
                    Course3DataGridView.EndEdit()
                End If
            Next

        End If
        
        If Course2DataGridView.RowCount > 0 And Course3DataGridView.RowCount > 0 Then

            For i = 0 To Course2DataGridView.Rows.Count - 1

                If (Course3DataGridView.CurrentRow.Cells(2).Value = Course2DataGridView.Rows(i).Cells(2).Value) And (Course2DataGridView.Rows(i).Cells(0).Value = True) Then
                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

                    Course3DataGridView.CurrentRow.Cells(0).Value = False
                    Course3DataGridView.EndEdit()
                End If
            Next
        End If

    End Sub


    Private Sub Course3DataGridView_CellContentClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Course3DataGridView.CellContentClick

        'For i = 0 To Course1DataGridView.Rows.Count - 1

        '    If (Course3DataGridView.CurrentRow.Cells(2).Value = Course1DataGridView.Rows(i).Cells(2).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course3DataGridView.CurrentRow.Cells(0).Value = False
        '        Course3DataGridView.EndEdit()
        '    End If
        'Next


        'For i = 0 To Course2DataGridView.Rows.Count - 1

        '    If (Course3DataGridView.CurrentRow.Cells(2).Value = Course2DataGridView.Rows(i).Cells(2).Value) And (Course2DataGridView.Rows(i).Cells(0).Value = True) Then
        '        MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '        Course3DataGridView.CurrentRow.Cells(0).Value = False
        '        Course3DataGridView.EndEdit()
        '    End If
        'Next

    End Sub

    Private Sub Course1DataGridView_SelectionChanged(sender As Object, e As System.EventArgs) Handles Course1DataGridView.SelectionChanged
        Course1DataGridView.ClearSelection()
    End Sub


    Private Sub Course2DataGridView_SelectionChanged(sender As Object, e As System.EventArgs) Handles Course2DataGridView.SelectionChanged
        Course2DataGridView.ClearSelection()
    End Sub


    Private Sub Course3DataGridView_SelectionChanged(sender As Object, e As System.EventArgs) Handles Course3DataGridView.SelectionChanged
        Course3DataGridView.ClearSelection()
    End Sub

 
    Private Sub RegisterButton_Click(sender As System.Object, e As System.EventArgs) Handles RegisterButton.Click

        RegisterCourses(StudentIdComboBox.Text, CourseEnrollFormDateTimePicker.Value.Date)

    End Sub



    Private Sub RegisterCourses(StudentId As Integer, CourseEnrollmentDate As Date)

        Try

            'Course1DataGridView
            If Course1DataGridView.Rows.Count = 0 Then


            Else

                For i = 0 To Course1DataGridView.Rows.Count - 1

                    If (Course1DataGridView.Rows(i).Cells(0).Value = True) Then

                        DBAccess.ExecuteQuery("SELECT SectionId FROM Sections WHERE SectionName = '" & Course1DataGridView.Rows(i).Cells(1).Value & "'")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                        Dim SectionId1 As Integer = DBAccess.DBDataTable.Rows(0).Item("SectionId")

                        DBAccess.AddParam("@StudentId", StudentId)
                        DBAccess.AddParam("@SectionId", SectionId1)
                        DBAccess.AddParam("@CourseEnrollmentDate", CourseEnrollmentDate)
                        DBAccess.AddParam("@EmployeeId", LoginForm.LoggedInEmpId)

                        DBAccess.ExecuteQuery("INSERT INTO CourseEnrollment(StudentId,SectionId,CourseEnrollmentDate,RegisteredBy) values(@StudentId,@SectionId,@CourseEnrollmentDate,@EmployeeId)")


                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                    End If
                Next

            End If


            'Course2DataGridView
            If Course2DataGridView.Rows.Count = 0 Then

            Else

                For i = 0 To Course2DataGridView.Rows.Count - 1

                    If (Course2DataGridView.Rows(i).Cells(0).Value = True) Then

                        DBAccess.ExecuteQuery("SELECT SectionId FROM Sections WHERE SectionName = '" & Course2DataGridView.Rows(i).Cells(1).Value & "'")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                        Dim SectionId2 As Integer = DBAccess.DBDataTable.Rows(0).Item("SectionId")

                        DBAccess.AddParam("@StudentId", StudentId)
                        DBAccess.AddParam("@SectionId", SectionId2)
                        DBAccess.AddParam("@CourseEnrollmentDate", CourseEnrollmentDate)
                        DBAccess.AddParam("@EmployeeId", LoginForm.LoggedInEmpId)

                        DBAccess.ExecuteQuery("INSERT INTO CourseEnrollment(StudentId,SectionId,CourseEnrollmentDate,RegisteredBy) values(@StudentId,@SectionId,@CourseEnrollmentDate,@EmployeeId)")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                    End If
                Next

            End If

            
            'Course3DataGridView
            If Course3DataGridView.Rows.Count = 0 Then

            Else

                For i = 0 To Course3DataGridView.Rows.Count - 1

                    If (Course3DataGridView.Rows(i).Cells(0).Value = True) Then

                        DBAccess.ExecuteQuery("SELECT SectionId FROM Sections WHERE SectionName = '" & Course3DataGridView.Rows(i).Cells(1).Value & "'")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                        Dim SectionId3 As Integer = DBAccess.DBDataTable.Rows(0).Item("SectionId")

                        DBAccess.AddParam("@StudentId", StudentId)
                        DBAccess.AddParam("@SectionId", SectionId3)
                        DBAccess.AddParam("@CourseEnrollmentDate", CourseEnrollmentDate)
                        DBAccess.AddParam("@EmployeeId", LoginForm.LoggedInEmpId)

                        DBAccess.ExecuteQuery("INSERT INTO CourseEnrollment(StudentId,SectionId,CourseEnrollmentDate,RegisteredBy) values(@StudentId,@SectionId,@CourseEnrollmentDate,@EmployeeId)")

                        If NotEmpty(DBAccess.Exception) Then
                            MessageBox.Show(DBAccess.Exception)
                            Exit Sub
                        End If

                    End If
                Next

            End If
            
            MessageBox.Show("Selected Courses Registered Successfully!")
        Catch ex As Exception

        End Try

    End Sub

    
    
    Private Sub TransferButton_Click(sender As System.Object, e As System.EventArgs) Handles TransferButton.Click



        'If SelectedCourseListDataGridView.RowCount = 3 Then

        '    MessageBox.Show("Sorry, The Student has already reached the max. no. of courses that he can enroll for! Please drop a course and select from the courses list!")


        'ElseIf Course1DataGridView.RowCount = 0 And Course2DataGridView.RowCount = 0 And Course3DataGridView.RowCount = 0 Then
        '    MessageBox.Show("Sorry, No Courses Selected! Please Select A Course And Then Click >> Button")

        'Else


        '    'Course1DataGridView VS SelectedCourseListDataGridView
        '    If Course1DataGridView.RowCount > 0 And SelectedCourseListDataGridView.RowCount > 0 Then

        '        For i = 0 To Course1DataGridView.Rows.Count - 1

        '            For j = 0 To SelectedCourseListDataGridView.Rows.Count - 1

        '                If (CourseName1ComboBox.Text = SelectedCourseListDataGridView.Rows(j).Cells(1).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then

        '                    MessageBox.Show("You have already enrolled for this Course! Please select a different course!")

        '                ElseIf (Course1DataGridView.Rows(i).Cells(2).Value = SelectedCourseListDataGridView.Rows(j).Cells(3).Value) And (Course1DataGridView.Rows(i).Cells(0).Value = True) Then
        '                    MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")

        '                    'Course1DataGridView.CurrentRow.Cells(0).Value = False
        '                    'Course1DataGridView.EndEdit()
        '                ElseIf (Course1DataGridView.Rows(i).Cells(0).Value = False) Then

        '                    MessageBox.Show("Please Choose A Section From The Course List")

        '                Else


        '                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView!
        '                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

        '                    If NotEmpty(DBAccess.Exception) Then
        '                        MessageBox.Show(DBAccess.Exception)
        '                        Exit Sub
        '                    End If

        '                    Dim r1 As DataRow
        '                    r1 = DBAccess.DBDataTable.NewRow
        '                    r1.Item("CourseName") = CourseName1ComboBox.Text
        '                    r1.Item("SectionName") = Course1DataGridView.Rows(i).Cells(1).Value
        '                    r1.Item("ScheduleName") = Course1DataGridView.Rows(i).Cells(2).Value
        '                    r1.Item("InstructorName") = Course1DataGridView.Rows(i).Cells(3).Value
        '                    r1.Item("CourseFee") = Course1DataGridView.Rows(i).Cells(4).Value

        '                    DBAccess.DBDataTable.Rows.Add(r1)

        '                    DBAccess.DBDataTable.AcceptChanges()

        '                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable

        '                End If
        '            Next

        '        Next

        '        If SelectedCourseListDataGridView.RowCount = 3 Then
        '            MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
        '        End If

        '    End If

        'End If

        '-------------------------------------------------


        If SelectedCourseListDataGridView.RowCount = 3 Then

            MessageBox.Show("Sorry, The Student has already reached the max. no. of courses that he can enroll for! Please drop a course and select from the courses list!")

            Exit Sub

        ElseIf Course1DataGridView.RowCount = 0 And Course2DataGridView.RowCount = 0 And Course3DataGridView.RowCount = 0 Then
            MessageBox.Show("Sorry, No Courses Selected! Please Select A Course And Then Click >> Button")

            Exit Sub


        ElseIf SelectedCourseListDataGridView.RowCount = 0 Then 'New Registration

            'Course1DataGridView TO SelectedCourseListDataGridView
            If Course1DataGridView.RowCount > 0 Then

                If (Course1DataGridView.CurrentRow.Cells(0).Value = True) Then

                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r1 As DataRow
                    r1 = DBAccess.DBDataTable.NewRow
                    r1.Item("CourseName") = CourseName1ComboBox.Text
                    r1.Item("SectionName") = Course1DataGridView.CurrentRow.Cells(1).Value
                    r1.Item("ScheduleName") = Course1DataGridView.CurrentRow.Cells(2).Value
                    r1.Item("InstructorName") = Course1DataGridView.CurrentRow.Cells(3).Value
                    r1.Item("CourseFee") = Course1DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r1)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else
                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")

                End If

            End If



            'Course2DataGridView TO SelectedCourseListDataGridView
            If Course2DataGridView.RowCount > 0 Then

                If (Course2DataGridView.CurrentRow.Cells(0).Value = True) Then

                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r2 As DataRow
                    r2 = DBAccess.DBDataTable.NewRow
                    r2.Item("CourseName") = CourseName2ComboBox.Text
                    r2.Item("SectionName") = Course2DataGridView.CurrentRow.Cells(1).Value
                    r2.Item("ScheduleName") = Course2DataGridView.CurrentRow.Cells(2).Value
                    r2.Item("InstructorName") = Course2DataGridView.CurrentRow.Cells(3).Value
                    r2.Item("CourseFee") = Course2DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r2)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else
                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")

                End If

            End If



            'Course3DataGridView TO SelectedCourseListDataGridView
            If Course3DataGridView.RowCount > 0 Then

                If (Course3DataGridView.CurrentRow.Cells(0).Value = True) Then

                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r3 As DataRow
                    r3 = DBAccess.DBDataTable.NewRow
                    r3.Item("CourseName") = CourseName3ComboBox.Text
                    r3.Item("SectionName") = Course3DataGridView.CurrentRow.Cells(1).Value
                    r3.Item("ScheduleName") = Course3DataGridView.CurrentRow.Cells(2).Value
                    r3.Item("InstructorName") = Course3DataGridView.CurrentRow.Cells(3).Value
                    r3.Item("CourseFee") = Course3DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r3)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else
                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")

                End If

            End If





        Else 'Update Enrollment

            'Course1DataGridView VS SelectedCourseListDataGridView
            If Course1DataGridView.RowCount > 0 And SelectedCourseListDataGridView.RowCount > 0 Then

                If (Course1DataGridView.CurrentRow.Cells(0).Value = True) Then

                    For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1

                        If (CourseName1ComboBox.Text = SelectedCourseListDataGridView.Rows(i).Cells(1).Value) And (Course1DataGridView.CurrentRow.Cells(0).Value = True) Then

                            MessageBox.Show("You have already enrolled for this Course! Please select a different course!")
                            Exit Sub

                        ElseIf (Course1DataGridView.CurrentRow.Cells(2).Value = SelectedCourseListDataGridView.Rows(i).Cells(3).Value) And (Course1DataGridView.CurrentRow.Cells(0).Value = True) Then
                            MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")
                            Exit Sub
                            'Course1DataGridView.CurrentRow.Cells(0).Value = False
                            'Course1DataGridView.EndEdit()

                        Else


                        End If

                    Next

                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r1 As DataRow
                    r1 = DBAccess.DBDataTable.NewRow
                    r1.Item("CourseName") = CourseName1ComboBox.Text
                    r1.Item("SectionName") = Course1DataGridView.CurrentRow.Cells(1).Value
                    r1.Item("ScheduleName") = Course1DataGridView.CurrentRow.Cells(2).Value
                    r1.Item("InstructorName") = Course1DataGridView.CurrentRow.Cells(3).Value
                    r1.Item("CourseFee") = Course1DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r1)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else
                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")
                End If

            End If




            'Course2DataGridView VS SelectedCourseListDataGridView
            If Course2DataGridView.RowCount > 0 And SelectedCourseListDataGridView.RowCount > 0 Then

                If (Course2DataGridView.CurrentRow.Cells(0).Value = True) Then

                    For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1

                        If (CourseName2ComboBox.Text = SelectedCourseListDataGridView.Rows(i).Cells(1).Value) And (Course2DataGridView.CurrentRow.Cells(0).Value = True) Then

                            MessageBox.Show("You have already enrolled for this Course! Please select a different course!")
                            Exit Sub

                        ElseIf (Course2DataGridView.CurrentRow.Cells(2).Value = SelectedCourseListDataGridView.Rows(i).Cells(3).Value) And (Course2DataGridView.CurrentRow.Cells(0).Value = True) Then
                            MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")
                            Exit Sub
                        Else

                        End If
                    Next


                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r2 As DataRow
                    r2 = DBAccess.DBDataTable.NewRow
                    r2.Item("CourseName") = CourseName2ComboBox.Text
                    r2.Item("SectionName") = Course2DataGridView.CurrentRow.Cells(1).Value
                    r2.Item("ScheduleName") = Course2DataGridView.CurrentRow.Cells(2).Value
                    r2.Item("InstructorName") = Course2DataGridView.CurrentRow.Cells(3).Value
                    r2.Item("CourseFee") = Course2DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r2)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else

                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")
                End If


            End If



            'Course3DataGridView VS SelectedCourseListDataGridView
            If Course3DataGridView.RowCount > 0 And SelectedCourseListDataGridView.RowCount > 0 Then

                If (Course3DataGridView.CurrentRow.Cells(0).Value = True) Then

                    For i = 0 To SelectedCourseListDataGridView.Rows.Count - 1

                        If (CourseName3ComboBox.Text = SelectedCourseListDataGridView.Rows(i).Cells(1).Value) And (Course3DataGridView.CurrentRow.Cells(0).Value = True) Then

                            MessageBox.Show("You have already enrolled for this Course! Please select a different course!")
                            Exit Sub

                        ElseIf (Course3DataGridView.CurrentRow.Cells(2).Value = SelectedCourseListDataGridView.Rows(i).Cells(3).Value) And (Course3DataGridView.CurrentRow.Cells(0).Value = True) Then
                            MessageBox.Show("You have already selected a course with the same timing. Please select a different timing!")
                            Exit Sub

                        Else

                        End If
                    Next

                    'Calling this query again just to make sure that the datatable is filled with contents that are to be filled into the SelectedCourseListDataGridView  and also to transfer the row values from Course1/2/3DataGridView to this query's datatable and then onto the SelectedCourseListDataGridView! YOU CANNOT ADD ROWS TO A DATAGRIDVIEW WHEN IT IS BOUND TO THE DATASOURE; THEREFORE WE ADD IT TO THE DATATABLE AND THEN TRANSFER IT TO THE DATAGRIDVIEW!
                    DBAccess.ExecuteQuery("SELECT OC.CourseName, Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")

                    If NotEmpty(DBAccess.Exception) Then
                        MessageBox.Show(DBAccess.Exception)
                        Exit Sub
                    End If

                    Dim r3 As DataRow
                    r3 = DBAccess.DBDataTable.NewRow
                    r3.Item("CourseName") = CourseName3ComboBox.Text
                    r3.Item("SectionName") = Course3DataGridView.CurrentRow.Cells(1).Value
                    r3.Item("ScheduleName") = Course3DataGridView.CurrentRow.Cells(2).Value
                    r3.Item("InstructorName") = Course3DataGridView.CurrentRow.Cells(3).Value
                    r3.Item("CourseFee") = Course3DataGridView.CurrentRow.Cells(4).Value

                    DBAccess.DBDataTable.Rows.Add(r3)

                    DBAccess.DBDataTable.AcceptChanges()

                    SelectedCourseListDataGridView.DataSource = DBAccess.DBDataTable


                    If SelectedCourseListDataGridView.RowCount = 3 Then
                        MessageBox.Show("The Student Has Reached His/Her Maximum Course Enrollment Limit!")
                        Exit Sub
                    End If

                Else

                    MessageBox.Show("Please Choose A Section From One Of The Three Course Lists Available")

                End If

            End If

        End If

    End Sub
End Class
















'For CheckboxRowIndex As Integer = 0 To Course1DataGridView.Rows.Count - 1

'    'http://vbcity.com/forums/t/156361.aspx
'    'http://stackoverflow.com/questions/14393171/radiobuttons-in-datagridview-column-vb-net
'    'https://www.google.com/?gws_rd=ssl#q=making+datagridview+checkbox+to+act+like+radio+buttons+in+VB.NET
'    'http://stackoverflow.com/questions/932040/triggering-a-checkbox-value-changed-event-in-datagridview
'    'http://stackoverflow.com/questions/17836208/best-event-to-check-when-using-a-datagridviewcheckboxcell
'    'http://stackoverflow.com/questions/13632536/get-value-from-datagridviewcheckboxcell
'    'https://www.google.com/?gws_rd=ssl#q=comparing+the+value+of+datagridviewcheckbox+with+other+datagridviewcheckbox


'Next

'If (e.ColumnIndex = CheckboxColIndex) Then
'    If CType(Me.Course1DataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex).Value, Boolean) = False Then
'        Dim otherCellIndex As Integer = DirectCast(If(e.ColumnIndex = firstCheckboxColIndex, secondCheckboxColIndex, firstCheckboxColIndex), Integer)
'        DirectCast(sender, DataGridView).Rows(e.RowIndex).Cells(otherCellIndex).Value = False
'    End If
'End If


'-------------------------------------------------------------------------------------------------------------------------------------------
''Code to transfer one row of datatable to one and only one datagrid at a time. Eg. 1st row of datatable to 1st grid; 2nd row of datatable to 2nd grid and so on..
'DBAccess.ExecuteQuery("SELECT Sec.SectionName, S.ScheduleName, I.InstructorLastName & ', ' & I.InstructorFirstName AS InstructorName, OC.CourseFee FROM (((((Sections Sec INNER JOIN Schedule S ON S.ScheduleId = Sec.ScheduleId) INNER JOIN Instructors I ON I.InstructorId = Sec.InstructorId) INNER JOIN OfferedCourses OC ON OC.CourseId = Sec.CourseId) INNER JOIN CourseEnrollment CE ON CE.SectionId = Sec.SectionId) INNER JOIN Students Stu ON Stu.StudentId = CE.StudentId) WHERE Stu.StudentId = " & StudentIdComboBox.Text & "")


'If NotEmpty(DBAccess.Exception) Then
'    MessageBox.Show(DBAccess.Exception)
'    Exit Sub
'End If

'If DBAccess.RecordCount = 0 Then
'    MessageBox.Show("Sorry, There are NO Registered Courses Under Your Name!")
'End If


''https://support.microsoft.com/en-us/kb/305346
''https://www.daniweb.com/programming/software-development/threads/385430/copy-a-datatable-row-to-datagrid-row

'If Course1DataGridView.RowCount > 0 Then
'    Course1DataGridView.Rows.Clear()
'End If

'If Course2DataGridView.RowCount > 0 Then
'    Course2DataGridView.Rows.Clear()
'End If

'If Course3DataGridView.RowCount > 0 Then
'    Course3DataGridView.Rows.Clear()
'End If


''DBAccess.DBDataTable.Columns("SectionName").SetOrdinal(0)
''DBAccess.DBDataTable.Columns("ScheduleName").SetOrdinal(1)
''DBAccess.DBDataTable.Columns("InstructorName").SetOrdinal(2)
''DBAccess.DBDataTable.Columns("CourseFee").SetOrdinal(3)


'Course1DataGridView.Rows.Add()
'Course2DataGridView.Rows.Add()
'Course3DataGridView.Rows.Add()
''add new row to dgv control

''get this row`s index
''now insert one row from dataTable:
''I will show you how to add 1st row from dataTable:
'Dim rowIndex1 As Integer = Course1DataGridView.Rows.Count - 1
'Dim rowIndex2 As Integer = Course2DataGridView.Rows.Count - 1
'Dim rowIndex3 As Integer = Course3DataGridView.Rows.Count - 1

'For i As Integer = 0 To DBAccess.DBDataTable.Rows.Count - 1
'    'loop through thr rows of dataTable
'    If i = 0 Then
'        'only add row at index 0 (1st row in dataTable)
'        For j As Integer = 0 To DBAccess.DBDataTable.Columns.Count - 1
'            'loop through thr columns of dataTable
'            Course1DataGridView(j, rowIndex1).Value = DBAccess.DBDataTable.Rows(i)(j)
'            Course1DataGridView(4, rowIndex1).Value = True
'            Course1DataGridView.ReadOnly = True
'        Next
'        'when done, code will leave for loop (of rows) - makes code faster!
'        'Exit For
'    End If

'    If i = 1 Then
'        'only add row at index 0 (1st row in dataTable)
'        For j As Integer = 0 To DBAccess.DBDataTable.Columns.Count - 1
'            'loop through thr columns of dataTable
'            Course2DataGridView(j, rowIndex2).Value = DBAccess.DBDataTable.Rows(i)(j)
'            Course2DataGridView(4, rowIndex2).Value = True
'            Course2DataGridView.ReadOnly = True
'        Next
'        'when done, code will leave for loop (of rows) - makes code faster!
'        'Exit For
'    End If

'    If i = 2 Then
'        'only add row at index 0 (1st row in dataTable)
'        For j As Integer = 0 To DBAccess.DBDataTable.Columns.Count - 1
'            'loop through thr columns of dataTable
'            Course3DataGridView(j, rowIndex3).Value = DBAccess.DBDataTable.Rows(i)(j)
'            Course3DataGridView(4, rowIndex3).Value = True
'            Course3DataGridView.ReadOnly = True
'        Next
'        'when done, code will leave for loop (of rows) - makes code faster!
'        'Exit For
'    End If
'Next
'-------------------------------------------------------------------------------------------------------------------------------------------
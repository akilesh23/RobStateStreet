-- Create a Table Temp(ID) with values 1,2,3,1,3
Create Table Temp
(
ID Int
)

INSERT INTO Temp(ID)
values (1),(2),(3),(1),(3)

Select * from Temp

-- WAQ to display duplicates in a table

Select ID, count(*) AS Duplicates
From Temp
Group By ID
Having Count(*)>1

-- What is a difference b/w WHERE & HAVING Clause?

--WAQ to remove duplicates in the Table
-- Hint: Use CTE & ROW_NUM Function

With CTE
As
(Select *, ROW_NUMBER() Over (Partition by ID Order by ID) As Rownumber
From Temp)
Delete From CTE
Where Rownumber>1
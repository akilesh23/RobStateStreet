IF EXISTS (SELECT 1 
    FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_TYPE='BASE TABLE' 
    AND TABLE_NAME='Cage') 
Drop Table Cage    
    
Create Table Cage
(
Cageid Int,
CageName VarChar(20)
)
Insert Into Cage(Cageid,CageName)
Values(1,'Cage1')
Insert Into Cage(Cageid,CageName)
Values (2 ,'cage2')
Insert Into Cage(Cageid,CageName)
Values(3 ,'cage3')
Insert Into Cage(Cageid,CageName)
Values(4 ,'cage4')
Insert Into Cage(Cageid,CageName)
Values (5,'cage5')


IF EXISTS (SELECT 1 
    FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_TYPE='BASE TABLE' 
    AND TABLE_NAME='Cats') 


Drop Table Cats
Create Table Cats
( 
Catid Int,
CatsName VarChar(20),
Cageid Int
)
Insert Into Cats(Catid,CatsName,Cageid)
Values(1,'Cat1' ,1)
Insert Into Cats(Catid,CatsName,Cageid)
Values  (2,'Cat2',1)
Insert Into Cats(Catid,CatsName,Cageid)
Values (3,'Cat3',3)
Insert Into Cats(Catid,CatsName,Cageid)
Values(4,'Cat4',5)
      
IF EXISTS (SELECT 1 
    FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_TYPE='BASE TABLE' 
    AND TABLE_NAME='Dogs') 

Drop Table Dogs      
Create Table Dogs
( 
DogID Int,
DogsName VarChar(20),
Cageid Int
)      
      
Insert Into Dogs(DogId,DogsName,Cageid)
Values(1,'Dog1' ,1)
Insert Into Dogs(DogId,DogsName,Cageid)
Values(2,'Dog2',1)
Insert Into Dogs(DogId,DogsName,Cageid)
Values(3,'Dog3' ,1)      
Insert Into Dogs(DogId,DogsName,Cageid)
Values(4,'Dog4' ,5) 
Insert Into Dogs(DogId,DogsName,Cageid)
Values(5,'Dog5' ,2)  

Select * From Cats      
Select * From Cage 
Select * From Dogs

--WAQ to DISPLAY Cats Name, Cage Name
Select C.CatsName, CG.CageName
From Cats C
JOIN Cage CG ON C.Cageid = CG.Cageid

--WAQ to DISPLAY Dogs Name, Cage Name
Select D.DogsName, CG.CageName
From Dogs D
JOIN Cage CG ON D.Cageid = CG.Cageid

--WAQ to DISPLAY Cages which doesn't have Cats
Select CG.CageName, C.CatsName
From Cage CG
LEFT JOIN Cats C ON CG.Cageid = C.Cageid
WHERE C.CatsName IS NULL -- When using NULL use "IS" not "=".

--WAQ to DISPLAY Cages which doesn't have Dogs
Select CG.CageName, D.DogsName
From Cage CG
LEFT JOIN Dogs D ON CG.Cageid = D.Cageid
WHERE D.DogsName IS NULL -- When using NULL use "IS" not "=".

--WAQ to DISPLAY Cages which has both Cats and Dogs
Select DISTINCT(CG.CageName)
From Cage CG
JOIN Dogs D ON CG.Cageid = D.Cageid
JOIN Cats C ON CG.Cageid = C.Cageid

--WAQ to DISPLAY Cages which doesn't have Cats and Dogs
Select CG.CageName
From Cage CG
LEFT JOIN Cats C ON CG.Cageid = C.Cageid
LEFT JOIN Dogs D ON CG.Cageid = D.Cageid
WHERE C.CatsName IS NULL AND D.DogsName IS NULL
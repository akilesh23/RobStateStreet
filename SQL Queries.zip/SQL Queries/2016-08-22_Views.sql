--Views--Virtual Tables

Create Table EmpSalary
(
Empid Int 
,EmpName Varchar(20)
,SSN Varchar(10)
)

Insert EmpSalary(Empid,EmpName,SSN)
Select 1,'Akhil','101'
Union
Select 2,'Harish','102'

Select * From EmpSalary

Alter View Vw_EmpSalary
With SchemaBinding
As
Select Empid,EmpName from dbo.EmpSalary


Select * From Vw_EmpSalary

Update Vw_EmpSalary
Set EmpName='Akil'
Where Empid=1

--it contains aggregates, or a DISTINCT or GROUP BY clause, or PIVOT or UNPIVOT operator

Drop Table EmpSalary
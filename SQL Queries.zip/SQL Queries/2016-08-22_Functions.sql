--CAF which will calculate greater of 2 numbers
--UDF
Create Function ufn_Greaterof2NUmbers
(
@FirstNumber Int,
@SecondNumber Int
)
Returns Int
As
Begin
Declare @Result Int
If (@FirstNumber>@SecondNumber)
Set @Result=@FirstNumber
Else
Set @Result=@SecondNumber
Return (@Result)
End


--Test Function

Select [dbo].[ufn_Greaterof2NUmbers] (100,20)

--WAF which will take date of a parameter and it will return the first day of the month

Create Function UFN_FirstDayOfMonth
(
@InputDate Date
)
Returns Date
As
Begin
Declare @Result Date
		,@Day Int

Select @Day=DAY(@InputDate)-1
Select @Result=DATEADD(DD,-@Day,@InputDate)
Return (@Result)
End

Select dbo.UFN_FirstDayOfMonth ('08/22/2016')

--WAF which will take date as a parameter and returns the last day of the month

--08/22/2016 --1 Month --09/22/2016
--09/22/2016-22 days

Create Function UFN_LastDayOfMonth
(
@InputDate Date
)
Returns Date
As
Begin
Declare @Result Date
		,@Day Int	
Select @Day=DAY(@InputDate)
Select @Result=DATEADD(mm,1,@InputDate)
Select @Result=DATEADD(dd,-@day,@Result)

Return (@Result)
End

Select dbo.UFN_LastDayOfMonth('02/22/2015')
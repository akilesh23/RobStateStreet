
--Create Employee Table

CREATE TABLE Employee
(
EmpID int,
Name varchar(255),
LocationId varchar(255),
)

-- INSERT Data in Employee Table

INSERT INTO Employee (EmpID, Name, LocationId)
VALUES (1,'Amulya',1), (2,'Archana',1), (3,'Arun',2), (4,'Bharat',30), (5,'Bhavana',2)

--Create Location Table

CREATE TABLE Location
(
LocationID int,
City varchar(255),
)

-- INSERT Data in Location Table

INSERT INTO Location (LocationID, City)
VALUES (1,'Dallas'), (2,'Irving'), (3,'Arlington'), (4,'Richardson')

-- WAQ to display EmployeeName, City (USING INNER JOIN)

Select E.Name As EmployeeName, L.City
From Employee E
Join Location L
ON E.LocationId = L.LocationID

-- WAQ to display EmployeeName, City (LEFT OUTER JOIN)

Select E.Name As EmployeeName, L.City
From Employee E
Left Join Location L
ON E.LocationId = L.LocationID

-- WAQ to display EmployeeName, City (RIGHT OUTER JOIN)

Select E.Name As EmployeeName, L.City
From Employee E
Right Join Location L
ON E.LocationId = L.LocationID

-- WAQ to display EmployeeName, City (FULL OUTER JOIN)

Select E.Name As EmployeeName, L.City
From Employee E
Full Join Location L
ON E.LocationId = L.LocationID
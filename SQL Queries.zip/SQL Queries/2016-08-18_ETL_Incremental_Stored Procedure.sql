--ETL Stored Procedures
--Drop Table ETLEmployee

Create Table ETLEmployee
(
EmployeeID Int 
,FirstName Varchar(20)
,LastName Varchar(20)
,DateofBirth Date
,ManagerFirstName Varchar(20)
,ManagerLastName Varchar(20)
)


Select * From ETLEmployee
 
--Source AdventureWorks
--Tables Employee,Contact

--WSP which wil poluate the data into this table incrementally

Create Procedure Usp_LoadETLEmployee
As
Begin
---Self Join
;With EmpDetails
As
(
Select pc.FirstName
		,pc.LastName
		,Hre.BirthDate
		,Hre.EmployeeID
		,Hre.ManagerID
		,pc.ContactID
From AdventureWorks.HumanResources.Employee Hre
Join AdventureWorks.Person.Contact pc on Hre.ContactID=pc.ContactID


)
Insert ETLEmployee(EmployeeID,FirstName,LastName,DateofBirth,ManagerFirstName,ManagerLastName)
Select Emp.EmployeeID
		,Emp.FirstName As FirstName
		,Emp.LastName As LastName
		,Emp.BirthDate
		,Mgr.FirstName As ManagerName
		,Mgr.LastName As ManagerLastName
		
From EmpDetails Emp
Join EmpDetails Mgr on Emp.ManagerID=Mgr.EmployeeID
Left Join ETLEmployee Dest on Dest.EmployeeID=Emp.EmployeeID
Where Dest.EmployeeID is Null
End


--Incremental Load --SSIS --ETL Extract Transform Load
select * From ETLEmployee Order by 1

Exec Usp_LoadETLEmployee

--Delete Duplicates from table
;With Duplicates
As
(
Select * 
	,ROW_NUMBER() Over (Partition By Employeeid Order BY EmployeeID) AS Rnum
From ETLEmployee
)
Delete from Duplicates 
Where Rnum>1
Create Table Employee_Sales
(
SalesID Int Identity(1,1)
,Name Varchar(20)
,SaleDAte DateTime
,SalesAmount Money
)


Insert into Employee_Sales(Name,SaleDate,SalesAmount)
Values('Sriram','08/18/2016',1000)
,('Sriram','08/19/2016',200)
,('Sriram','08/20/2016',100)
,('Suresh','08/20/2016',50)
,('Suresh','08/21/2016',100)

Select * From Employee_Sales
--WAQ to display running total
/*
Siram August 18 1000 1000
Sriram August 19 200 1200
Sriram August 20 100 1300
*/

Select E1.Name
		,E1.SaleDAte
		,E1.SalesAmount
		,Sum(E2.SalesAmount) As RunningTotal
From Employee_Sales E1
Join Employee_Sales E2 on E1.Name=E2.Name and e1.SaleDAte>=E2.SaleDAte
Group By E1.Name
		,E1.SaleDAte
		,E1.SalesAmount


--PRogram Flow 
--IF ,While,Case

--WSP which will take a number and return the factorial--4

Declare @inputnumber int=5
		,@Result int=1
While (@inputnumber>0)
Begin

Set @Result=@Result*((@inputnumber+1)-1)--5,4*5
Set @inputnumber=@inputnumber-1--4

End
Select @Result


--Error Handling Stored Procedure
--Try Catch
Begin Try
Select 1/0
End Try
Begin CAtch
Select ERROR_MESSAGE()
End Catch

Select * From Sys.messages
Where message_id=8134


--Master Stored Procedure
--Child
Create Procedure Usp_Child
As
Select 'Child'

Create Procedure usp_parent
As
Exec Usp_Child

Exec usp_parent
--Nesting of Stored Procedures





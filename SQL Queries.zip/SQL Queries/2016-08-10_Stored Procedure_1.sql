Create Table Employee_Manager
(
EmployeeId Int
,FirstName Varchar(20)
,ManagerID Int
)

Select * From Employee_Manager

Insert Employee_Manager(EmployeeId,FirstName)
Select 1,'John'

Insert Employee_Manager(EmployeeId,FirstName,ManagerID)
Select 2,'David',1
uNion
Select 3,'Ram',1
uNion
Select 4,'Rani',2
uNion
Select 5,'Keith',2
uNion
Select 6,'Ken',5
uNion
Select 7,'Richard',5

--WAQ to Display Employee Name, Manager Name
Select * from Employee_Manager

--SELF JOIN
Select E.FirstName AS EmployeeName, M.FirstName AS ManagerName
From Employee_Manager E
JOIN Employee_Manager M ON E.ManagerID = M.EmployeeId

-- STORED PROCEDURE
Create Procedure Usp_EmpDetails
As
Begin
Select E.FirstName AS EmployeeName, M.FirstName AS ManagerName
From Employee_Manager E
JOIN Employee_Manager M ON E.ManagerID = M.EmployeeId
End

Exec Usp_EmpDetails

--WAQ to display Top 3rd and 4th Highest Paid Employees
Select top 2  *
From
(
  Select top 4 *  From Employee_Salary
  Order By Salary Desc
)i
Order By Salary


--WAQ to display Top 3rd and 4th Highest Paid Employees
Select top 2  *
From
(
  Select top 4 *  From Employee_Salary
  Order By Salary Desc
)i
Order By Salary

--CTE Common Table Expression
With Cte
As
(
Select *
  ,Rank() Over (Order by Salary Desc) As EmployeeRank --Derived Column
From Employee_Salary
)
Select * From Cte
Where EmployeeRank in (3,4)
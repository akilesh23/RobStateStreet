-- WAQ TO EXTRACT EMPLOYEES WHO ARE MALE AND ARE MARRIED(eMPLOYEEid,MANAGERID,GEDNER,BIRTHDATE,AGE)

Select EmployeeID, ManagerID, Gender, MaritalStatus, BirthDate, DATEDIFF(YY, BirthDate, GETDATE()) AS Age 
From [HumanResources].[Employee]
Where MaritalStatus = 'M' AND Gender = 'M'

--CAP which will implement the above query in SSIS and load the data into a Flat File.
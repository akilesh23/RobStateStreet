Select * From HumanResources.Employee

-- CAP which will extract the data from the above Table and load it into a Flat File.



-- CAP which will extract the data from the Person.Address Table and load it into a Flat File (Address.csv).

-- CAP which will extract the data from the HumanResources.Shift Table and load it into a Flat File (Shift.csv).

-- CAP which will extract the data from the Person.StateProvince Table and load it into a Flat File (StateProvince.csv).

-- CAP which will extract the data from the Person.Contact Table and load it into a Flat File (Contact.csv).

-- CAP which will extract the data from the Production.Loacation Table and load it into a Flat File (Location.csv).

-- Send an One Line Description about every transformations in DataFlow Tab.
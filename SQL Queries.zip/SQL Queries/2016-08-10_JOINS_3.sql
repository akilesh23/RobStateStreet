--WAQ to display Top 10 Records in Employee Table

Select TOP 2 *
From [HumanResources].[Employee]

Select TOP 2 *
From Person.Contact

--WAQ to display EmployeeId, FirstName, LastName, BirthDate

Select E.EmployeeID, P.FirstName, P.LastName, E.BirthDate
From HumanResources.Employee E
JOIN Person.Contact P ON E.ContactID = P.ContactID
-- WAQ to dispplay Female Employees aged between 21-30 (Employeeid,firstname,lastname,birthdate,age,gedner)


With CTE
AS
(
Select E.EmployeeID, P.FirstName, P.LastName, E.BirthDate, DATEDIFF(YY, E.BirthDate, GETDATE()) AS Age, E.Gender
From HumanResources.Employee E
JOIN Person.Contact P ON E.ContactID = P.ContactID
)
Select * From CTE
WHERE Gender = 'F'
AND 
Age BETWEEN 21 AND 40


Select E.EmployeeID, P.FirstName, P.LastName, E.BirthDate, DATEDIFF(YY, E.BirthDate, GETDATE()) AS Age, E.Gender
From HumanResources.Employee E
JOIN Person.Contact P ON E.ContactID = P.ContactID
WHERE Gender = 'F'
AND 
DATEDIFF(YY, E.BirthDate, GETDATE()) BETWEEN 21 AND 40

--CAP which will implement the above query in SSIS and load the data into a Flat File.
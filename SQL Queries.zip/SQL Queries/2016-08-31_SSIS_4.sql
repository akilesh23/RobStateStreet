-- WAQ to display the list of employees born between 1972 and 1982 (EmpID, BirthDate, Age, Gender, Marital Status)

SELECT EmployeeID, BirthDate, Gender, MaritalStatus, DATEDIFF(YY,BirthDate,GETDATE()) AS Age, YEAR(BirthDate) As BirthYear
FROM [HumanResources].[Employee]
WHERE YEAR(BirthDate) BETWEEN 1972 AND 1982

--CAP which will implement the above query in SSIS and load the data into a table (Training.SSIS_EmployeeDetails)


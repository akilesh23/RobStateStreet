--Whenever any one updates orders table i want to capture the changes

Create Table Orders
(
OrderID Int Identity(1,1)
,ProductName Varchar(255)
,Quantity int
)



Create Table Orders_Audit
(
OrderID Int 
,ProductName Varchar(255)
,Quantity int
,[Action] Varchar(25)
,CreatedBy Varchar(255)
,CreatedOn DateTime

)


Delete from Orders Where OrderID=1
Select * From Orders
Select * From Orders_Audit

--Insert Action
Create Trigger Tri_Orders on Orders
For Insert
As
Insert Orders_Audit(OrderID,ProductName,Quantity,Action,CreatedBy,CreatedOn)
Select OrderID,ProductName,Quantity,'Insert',SUSER_NAME(),GETDATE()
From Inserted

Insert Orders(ProductName,Quantity)
Select 'Laptp',10



--Delete Action
Create Trigger Trd_Orders on Orders
For Delete
As
Insert Orders_Audit(OrderID,ProductName,Quantity,Action,CreatedBy,CreatedOn)
Select OrderID,ProductName,Quantity,'Delete',SUSER_NAME(),GETDATE()
From Deleted


--Update Action
Create Trigger Tru_Orders on Orders
For Update
As
Insert Orders_Audit(OrderID,ProductName,Quantity,Action,CreatedBy,CreatedOn)
Select OrderID,ProductName,Quantity,'After Update',SUSER_NAME(),GETDATE()
From Inserted
Insert Orders_Audit(OrderID,ProductName,Quantity,Action,CreatedBy,CreatedOn)
Select OrderID,ProductName,Quantity,'Before Update',SUSER_NAME(),GETDATE()
From Deleted





Select * From Orders
Select * From Orders_Audit

Update Orders
Set Quantity=50
Where OrderID=2
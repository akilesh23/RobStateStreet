--Create Table Sp.Student(StudentID,FirstName)
Create Schema Sp
Create Table Sp.Student
(
StudentID Int Identity(1,1),
FirstName Varchar(20)
)

Select *From Sp.Student

Insert into Sp.Student
Values ('John')
      ,('Ram')


Select SCOPE_IDENTITY()

Create Procedure Usp_StudentDetails
@FirstName Varchar(20)
As
Begin

Insert into Sp.Student(FirstName)
Values (@FirstName)
Select SCOPE_IDENTITY() As StudentID

End

Select *From Sp.Student
EXEC Usp_StudentDetails 'David'


Create Table Sp.Professor
(
ProfessorID Int Identity(1,10),
ProfessorName Varchar(20)
)

Select *From Sp.Professor
Select *From Sp.Student
Insert into Sp.Professor
Values ('Sai') 

Alter Table Sp.Student Add ProfessorID Int

Create Procedure Usp_StudentProfessorinfo
@StudentName Varchar(20),
@ProfessorName Varchar(20)
As
Begin
--Scopeidentity null
Insert into Sp.Professor(ProfessorName)
Values(@ProfessorName)
--Scopeidentity=11
Insert into Sp.Student(FirstName,ProfessorID)
Values(@StudentName,SCOPE_IDENTITY())
--Scopeidentity 5

Select SCOPE_IDENTITY() As StudentID

End


EXEC Usp_StudentProfessorinfo 'Devansi','Jack'

-- IF EXISTS & Use Variable

Create Procedure Usp_StudentProfessorinfo_Duplicates
@StudentName Varchar(20),
@ProfessorName Varchar(20)
As
Begin
--Scopeidentity null
If not  Exists(Select * From Sp.Professor  Where ProfessorName=@ProfessorName)
	Begin --If Clause
	Insert into Sp.Professor(ProfessorName)
	Values(@ProfessorName)
	End--If Clause
Declare @Profid Int--LOcal Variable
Select @Profid=ProfessorID From Sp.Professor  Where ProfessorName=@ProfessorName

--Scopeidentity=11
Insert into Sp.Student(FirstName,ProfessorID)
Values(@StudentName,@Profid)
--Scopeidentity 5

Select SCOPE_IDENTITY() As StudentID

End



-- Empty the Table
Truncate Table Sp.Professor
Truncate Table Sp.Student

Select * From Sp.Student
Select * From Sp.Professor

exec Usp_StudentProfessorinfo_Duplicates 'Sriram','John'
exec Usp_StudentProfessorinfo_Duplicates 'SeshaSai','John'
exec Usp_StudentProfessorinfo_Duplicates 'Manasa','DAvid'

EXEC Usp_StudentProfessorinfo 'Devansi','Jack'
EXEC Usp_StudentProfessorinfo 'Suresh','David'
EXEC Usp_StudentProfessorinfo 'Nagaraj','David'
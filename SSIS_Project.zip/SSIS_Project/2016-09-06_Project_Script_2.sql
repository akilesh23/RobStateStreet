Create Table SSIS_Log
(
PackageID Int Identity(1,1),
PackageName Varchar(255),
PackageStartDate DateTime,
PackageEndDate DateTime,
PackageStatus Varchar(255),
PackageRowCount Int
)

Select * From SSIS_Log

--StartLogging
Insert SSIS_Log(PackageName, PackageStartDate)
Select ?,GETDATE()
Select SCOPE_IDENTITY()

--FinishLogging
Update SSIS_Log
Set PackageEndDate = GETDATE(),
	PackageStatus = 'Success',
	PackageRowCount = ? --Parameter0
Where PackageID = ? --Parameter1


-------
Delete [Dimension].[Contact]
Delete SSIS_Log

--Reset Identity
DBCC CHECKIDENT ('[Dimension].[Contact]', RESEED, 0);
GO

DBCC CHECKIDENT ('[SSIS_Log]', RESEED, 0);
GO
--------

--Dimension.Contact

Select * From [Dimension].[Contact]
Where ContactName LIKE '%James,He%'

Select * From SSIS_Log

--Dimension.ShipMethod

Select * From [Dimension].[ShipMethod]

Select * From SSIS_Log


--Dimension.Territory

Select * From [Dimension].[Territory]

Select * From SSIS_Log
Order By PackageID


--Dimension.Date

Select * From [Dimension].[Date]

Select * From SSIS_Log
Order By PackageID


--Fact.OrderHeader

Select * From [Fact].[OrderHeader_Fact]
Order By ContactID

Select * From SSIS_Log
Order By PackageID

Truncate Table [Fact].[OrderHeader_Fact]

Select * From Dimension.Contact
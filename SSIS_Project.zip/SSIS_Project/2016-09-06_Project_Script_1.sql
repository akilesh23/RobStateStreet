Create Database SSIS_DatawareHouse
Go

Use SSIS_DatawareHouse
Go
Create Schema Dimension
Go

Create Schema Fact
Go

CREATE TABLE Dimension.[Contact](
[ContactID] [int] IDENTITY(1,1) NOT NULL Primary Key,
[ContactName] Varchar(30) NOT NULL,
CreatedDate   DateTime
)

CREATE TABLE Dimension.Date(
[DateID] [int] IDENTITY(1,1) NOT NULL Primary Key,
[Date] Varchar(30) NOT NULL,
CreatedDate   DateTime
)

CREATE TABLE Dimension.Territory(
[TerritoryID] [int] IDENTITY(1,1) NOT NULL Primary Key,
[TerritoryName] Varchar(30) NOT NULL,
CreatedDate   DateTime
)

CREATE TABLE Dimension.ShipMethod(
[ShipMethodID] [int] IDENTITY(1,1) NOT NULL Primary Key,
[ShipMethodName] Varchar(30) NOT NULL,
CreatedDate   DateTime
)

Create Table Fact.OrderHeader_Fact
(
ContactID Int,
OrderDateId Int,
DueDateId Int,
ShipDateId Int,
[TerritoryID] INt,
ShipMethodID Int,
TotalDue Money,
Freight Money
)


ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_ContactID] FOREIGN KEY(ContactID)
REFERENCES Dimension.Contact (ContactID)

ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_OrderDateId_DateID] FOREIGN KEY(OrderDateId)
REFERENCES Dimension.Date (DateID)

ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_DueDateId_DateID] FOREIGN KEY(DueDateId)
REFERENCES Dimension.Date (DateID)

ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_ShipDateId_DateID] FOREIGN KEY(ShipDateId)
REFERENCES Dimension.Date (DateID)

ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_TerritoryID] FOREIGN KEY([TerritoryID])
REFERENCES Dimension.Territory ([TerritoryID])


ALTER TABLE Fact.OrderHeader_Fact  ADD  CONSTRAINT [FK_OrderHeader_Fact_ShipMethodID] FOREIGN KEY(ShipMethodID)
REFERENCES Dimension.ShipMethod (ShipMethodID)



---------------------------

Select OrderDate AS Date From [Sales].[SalesOrderHeader]
UNION
Select DueDate From [Sales].[SalesOrderHeader]
UNION
Select ShipDate From [Sales].[SalesOrderHeader]


SELECT PC.FirstName + ',' + LastName AS FullName, 
       OrderDate, 
       DueDate, 
       ShipDate, 
       ST.Name AS TerritoryName, 
       SM.Name AS ShipMethodName, 
       TotalDue, 
       Freight 
FROM   Sales.SalesOrderHeader SOH 
       JOIN Sales.SalesTerritory ST 
         ON ST.TerritoryID = SOH.TerritoryID 
       JOIN Purchasing.ShipMethod SM 
         ON SM.ShipMethodID = SOH.ShipMethodID
       JOIN Person.Contact PC 
         ON PC.ContactID = SOH.ContactID

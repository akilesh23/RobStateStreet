IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Borrower]') AND type in (N'U'))
DROP TABLE [dbo].Borrower


CREATE TABLE Borrower 
(
BorrowerId INT IDENTITY(1,1)
,Firstname  VARCHAR(10)
,SSN        VARCHAR(10)

)

INSERT Borrower (Firstname,SSN)
SELECT 'John','101010'
UNION
SELECT 'Ram','101110'
UNION
SELECT 'Raja','101210'
UNION
SELECT 'Ronnie','122010' 
UNION
SELECT 'Rama','133010'
UNION
SELECT 'Patrick','12222'

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROPERTY]') AND type in (N'U'))
DROP TABLE [dbo].PROPERTY
CREATE TABLE PROPERTY 
(
PropertyID INT IDENTITY(1,1)
,PropertyName VARCHAR(10)
,PropertyAddress VARCHAR(100)
)

INSERT PROPERTY(PropertyName,PropertyAddress)
SELECT 'MTH','1200 Hidden Ridge'
UNION
SELECT 'Emerald','1200 Bailey Ridge'
UNION
SELECT 'Reliance','3300 Rose Ct'
UNION
SELECT 'XYZ','2300 Meadow Creek Ridge'
UNION
SELECT 'Rancho','1300 Hidden Ridge'
UNION
SELECT 'Remington','2400 Hidden Ridge'

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CoBorrower]') AND type in (N'U'))
DROP TABLE [dbo].CoBorrower
CREATE TABLE CoBorrower 
(
CoBorrowerId INT IDENTITY(1,1)
,Firstname  VARCHAR(10)
,SSN        VARCHAR(10)
,BorrowerID Int

)


INSERT CoBorrower
SELECT 'Patricia','1012222',4
UNION
SELECT 'Rani','10342',5



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Loan]') AND type in (N'U'))
DROP TABLE [dbo].Loan
CREATE TABLE Loan 
(
LoanId INT   IDENTITY(1,1)
,BorrowerID  VARCHAR(10)
,PropertyID  VARCHAR(10)
,IsActive     Bit
,LoanAmount MONEY 
,MonthlyAmount  Money

)


INSERT Loan(BorrowerID,PropertyID,IsActive,LoanAmount,MonthlyAmount)
SELECT 3,5,1,433000,2878
UNION
SELECT 4,2,1,272000,1673
UNION
SELECT 4,1,1,332000,1973
UNION
SELECT 5,4,0,272000,1673
UNION
SELECT 5,6,0,352000,2432
UNION
SELECT 1,5,1,145000,1232
UNION
SELECT 3,4,0,225000,1364
UNION
SELECT 3,4,0,225000,1364
UNION
SELECT 6,2,0,245000,1998
UNION
SELECT 6,2,0,245000,1998

SELECT * FROM Borrower
SELECT * FROM Property
SELECT * FROM CoBorrower
SELECT * FROM Loan

-- 1)WAQ TO display BorrowerName,LoanAmount
CREATE Procedure USP_Loans_Assn_Q1
AS
Begin
Select B.FirstName, SUM(L.LoanAmount) AS "Loan Amount"
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
Group By B.FirstName
End

Exec USP_Loans_Assn_Q1

-- Parametrized Stored Procedures Example

Create Procedure USP_Loans_Assn_Q1_Parameter
@FirstName Varchar(20) = 'UNK' -- Default Value Parameter
AS
Begin
Select B.FirstName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
Where B.Firstname = Case When @FirstName='UNK' Then B.Firstname
							Else @FirstName End
End

Exec USP_Loans_Assn_Q1_Parameter

Exec USP_Loans_Assn_Q1_Parameter 'Ram'

-- 2)WAQ TO display BorrowerName,PropertyName,LoanAmount

Create Procedure USP_Loans_Assn_Q2
AS
Begin
Select B.FirstName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
End

Exec USP_Loans_Assn_Q2

-- 3)WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with Mutiple Properties

Create Procedure USP_Loans_Assn_Q3
AS
Begin
Select B.FirstName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
End

Exec USP_Loans_Assn_Q3

-- 4)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and have coborrowers

Create Procedure USP_Loans_Assn_Q4
AS
Begin
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
End

Exec USP_Loans_Assn_Q4

-- 6)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and Doesn�t have coborrowers

Create Procedure USP_Loans_Assn_Q6
AS
Begin
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
From Borrower B
LEFT JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
AND
B.BorrowerId NOT IN
(
Select B.BorrowerId
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
)
End

Exec USP_Loans_Assn_Q6

--Method-2:
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
From Borrower B
LEFT JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
AND
C.Firstname IS NULL


-- 7)WAQ to display property name with no borrowers
Select P.PropertyName
From Property P
LEFT JOIN Loan L ON L.PropertyID = P.PropertyID
WHERE L.BorrowerId IS NULL


--10) WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with top 1 highest loan amount
Select Top 1 * From
(
Select B.FirstName AS BorrowerName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
)a
Order By a.LoanAmount Desc

--11) WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with top 3rd highest loan amount
With Cte As
(
Select B.FirstName AS BorrowerName, P.PropertyName, L.LoanAmount, Rank() Over (Order by L.LoanAmount Desc) As LoanRank
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
)
Select BorrowerName, PropertyName, LoanAmount From Cte
Where LoanRank = 3


--12) WAQ TO display BorrowerName,PropertyName,LoanAmount,CoBorrowerName for Borrowers with top 2rd highest loan amount 
--and has coborrowers on the property

Create Procedure USP_Loans_Assn_Q12
AS
Begin
With Cte As
(
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
,Rank() Over (Order by L.LoanAmount Desc) As LoanRank
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
)
Select BorrowerName, PropertyName, CoBorrowerName, LoanAmount From Cte
Where LoanRank = 2
End


Exec USP_Loans_Assn_Q12

Create Procedure USP_Loans_Assn_Q12_Parameter
@Rank int=0 --Defaulta Value
As
Begin
With Cte
As
(
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
,Rank() Over (Order by L.LoanAmount Desc) As LoanRank
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID    
)
Select * From Cte
Where LoanRank = Case When @Rank=0 then LoanRank 
Else @Rank End 
End

Exec USP_Loans_Assn_Q12_Parameter

Exec USP_Loans_Assn_Q12_Parameter 2
Exec USP_Loans_Assn_Q12_Parameter 3


--Method-2
Select B.Firstname As BorrowerName,P.PropertyName,TT.LoanAmount 
From 
(
Select * 
		,Rank() Over(Order by LoanAmount Desc) As LoanAmtRank -- Derived Column
From Loan
) AS TT
Join Borrower B on B.BorrowerId=TT.BorrowerID
Join PROPERTY P on TT.PropertyID=P.PropertyID
Left Join CoBorrower C on TT.BorrowerId=C.BorrowerId
Where LoanAmtRank = 2 AND C.CoBorrowerId IS NOT NULL


--13)WAQ to display Borrowers with no Property
Select B.Firstname AS BorrowerName
From Borrower B
LEFT JOIN Loan L ON B.BorrowerId = L.BorrowerID
WHERE L.PropertyID IS NULL

-- 8)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and 
-- Doesn�t have coborrowers and both Properties are Active

Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.IsActive, L.LoanAmount
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
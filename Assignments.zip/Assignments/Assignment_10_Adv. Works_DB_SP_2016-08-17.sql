--1)WSP(Write a Stored Procedure which will take Managerid as Parameter and Display the Employees reporting to manager

Alter Procedure USP_ManagerID_EmployeeDetails
@ManagerID int
AS
Begin
Select E.EmployeeID, E.ManagerID, E.ContactID, C.FirstName AS EmployeeFirstName, C.LastName AS EmployeeLastName
From [HumanResources].[Employee] E
JOIN Person.Contact C
ON E.ContactID = C.ContactID
WHERE ManagerID = 16
Order By E.EmployeeID
End

Exec USP_ManagerID_EmployeeDetails 16

--2)WSP(Write a Stored Procedure which will take ProductName  as Parameter and Display the ProductName,ProductCategoryName
--,ProductSubcategoryName

Select * From [Production].[Product]
Order By ProductID Asc

Select * From [Production].[ProductCategory]
Order By ProductCategoryID Asc

Select * From [Production].[ProductSubcategory]
Order By ProductSubcategoryID Asc

Alter Procedure USP_ProductName_ProductDetails
@ProductName varchar(100)
AS
Begin
Select P.Name AS ProductName, PC.Name AS ProductCategoryName, PSC.Name AS ProductSubcategoryName
From [Production].[Product] P
JOIN [Production].[ProductSubcategory] PSC
ON P.ProductSubcategoryID = PSC.ProductSubcategoryID
JOIN [Production].[ProductCategory] PC
ON PC.ProductCategoryID = PSC.ProductCategoryID
Where P.Name LIKE %@ProductName% --Check how to do this!
End

Exec USP_ProductName_ProductDetails 'HL'

--HL Road Frame - Black, 58


-- Create this Procedure and execute it

Create Procedure USP_dEmpName_MgrName

As
Begin
;
With EmpDetails
As
(
Select pc.FirstName
		,pc.LastName
		,Pa.City
		,Hre.EmployeeID
		,Hre.ManagerID
		,pc.ContactID
From HumanResources.Employee Hre
Join Person.Contact pc on Hre.ContactID=pc.ContactID
Join HumanResources.EmployeeAddress hrea on hrea.EmployeeID=Hre.EmployeeID
Join Person.Address Pa on Pa.AddressID=hrea.AddressID

)
Select Emp.FirstName As EmployeeName
		,Emp.LastName As EmployeeLastName
		,Mgr.FirstName As ManagerName
		,Mgr.LastName As ManagerLastName
		,Emp.City AS EmployeeCity
		,Mgr.City As ManagerCity
From EmpDetails Emp
Join EmpDetails Mgr on Emp.ManagerID=Mgr.EmployeeID

End


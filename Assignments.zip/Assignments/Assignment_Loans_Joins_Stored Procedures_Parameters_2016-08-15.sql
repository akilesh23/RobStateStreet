SELECT * FROM Borrower
SELECT * FROM Property
SELECT * FROM CoBorrower
SELECT * FROM Loan

-- 1)WAQ TO display BorrowerName,LoanAmount

ALTER Procedure USP_Loans_Assn_Q1_Parameter
@FirstName Varchar(20) = 'AKI' -- Default Value Parameter
AS
Begin
Select B.FirstName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
Where B.Firstname = Case When @FirstName='AKI' Then B.Firstname
							Else @FirstName End
End

Exec USP_Loans_Assn_Q1_Parameter

Exec USP_Loans_Assn_Q1_Parameter 'Ram'

-- 2)WAQ TO display BorrowerName,PropertyName,LoanAmount

Create Procedure USP_Loans_Assn_Q2_Parameter
@PropertyName Varchar(20) = 'AKI'
AS
Begin
Select B.FirstName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
Where P.PropertyName = Case When @PropertyName = 'AKI' Then P.PropertyName
						Else @PropertyName End
End

Exec USP_Loans_Assn_Q2_Parameter 'Reliance'

-- 3)WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with Mutiple Properties

Create Procedure USP_Loans_Assn_Q3_Parameter
@PropertyName Varchar(20) = 'AKI'
AS
Begin
Select B.FirstName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE 
P.PropertyName = Case When @PropertyName = 'AKI' Then P.PropertyName
						Else @PropertyName End
AND
B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
End

Exec USP_Loans_Assn_Q3_Parameter 'Emerald'

-- 4)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and have coborrowers

Create Procedure USP_Loans_Assn_Q4_Parameter
@PropertyName Varchar(20) = 'AKI'
AS
Begin
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
WHERE P.PropertyName = Case When @PropertyName = 'AKI' Then P.PropertyName
						Else @PropertyName End
AND
B.BorrowerId IN (
Select BorrowerID
From Loan
Group By BorrowerID
Having Count(*)>1
)
End

Exec USP_Loans_Assn_Q4_Parameter 'Reliance'

-- 6)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and Doesn�t have coborrowers

Alter Procedure USP_Loans_Assn_Q6_Parameter
@Coborrower Varchar(20) = 'AKI'
AS
Begin
With BorrowerWithMultipleProp
As
(
Select BorrowerId from Loan 
Group By BorrowerID Having Count(*) > 1  
)
Select B.FirstName, P.PropertyName, L.LoanAmount, C.Firstname As CoBorrower
From BorrowerWithMultipleProp Bo
JOIN Loan L ON Bo.BorrowerId = L.BorrowerId
JOIN Borrower B ON B.BorrowerId = Bo.BorrowerID
JOIN Property P ON L.PropertyID = P.PropertyID
LEFT JOIN CoBorrower C ON B.BorrowerId = C.BorrowerId
WHERE  C.Firstname = Case When @Coborrower = 'AKI' Then C.Firstname
						Else @Coborrower End
OR C.CoBorrowerId Is Null
End

Exec USP_Loans_Assn_Q6_Parameter 'Patricia'

-- 7)WAQ to display property name with no borrowers

Create Procedure USP_Loans_Assn_Q7_Parameter
@PropertyName Varchar(20) = 'AKI'
As
Begin
Select P.PropertyName  
From Property as P 
Left Join Loan as L
On P.PropertyId = L.PropertyId
WHERE  P.PropertyName = Case When @PropertyName = 'AKI' Then P.PropertyName
						Else @PropertyName End
OR L.LoanID IS NULL
End

Exec USP_Loans_Assn_Q7_Parameter 'Reliance'

--10) WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with top 1 highest loan amount

Create Procedure USP_Loans_Assn_Q10_Parameter
@LoanAmount int = 0
As 
Begin
Select Top 1 * From
(
Select B.FirstName AS BorrowerName, P.PropertyName, L.LoanAmount
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
)a
Where LoanAmount=Case When @LoanAmount=0 then LoanAmount Else @LoanAmount End
Order By a.LoanAmount Desc
End

Exec USP_Loans_Assn_Q10_Parameter '430000'

--11) WAQ TO display BorrowerName,PropertyName,LoanAmount for Borrowers with top 3rd highest loan amount

Create Procedure USP_Loans_Assn_Q11_Parameter
@LoanAmount int = 0
As
Begin
With Cte As
(
Select B.FirstName AS BorrowerName, P.PropertyName, L.LoanAmount, Rank() Over (Order by L.LoanAmount Desc) As LoanRank
From Borrower B
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID
)
Select BorrowerName, PropertyName, LoanAmount From Cte
Where LoanRank = Case When @LoanAmount = 0 Then LoanRank
Else @LoanAmount END AND LoanRank = 3
End

Exec USP_Loans_Assn_Q11_Parameter '333000'


--12) WAQ TO display BorrowerName,PropertyName,LoanAmount,CoBorrowerName for Borrowers with top 2rd highest loan amount 
--and has coborrowers on the property

Alter Procedure USP_Loans_Assn_Q12_Parameter
@Rank int=0 --Defaulta Value
As
Begin
With Cte
As
(
Select B.FirstName AS BorrowerName, P.PropertyName, C.Firstname AS CoBorrowerName, L.LoanAmount
,Rank() Over (Order by L.LoanAmount Desc) As LoanRank
From Borrower B
JOIN CoBorrower C ON B.BorrowerId = C.BorrowerID
JOIN Loan L ON B.BorrowerId = L.BorrowerId
JOIN Property P ON L.PropertyID = P.PropertyID    
)
Select * From Cte
Where LoanRank = Case When @Rank=0 then LoanRank 
Else @Rank End 
End

Exec USP_Loans_Assn_Q12_Parameter

Exec USP_Loans_Assn_Q12_Parameter 2
Exec USP_Loans_Assn_Q12_Parameter 3


--13)WAQ to display Borrowers with no Property

Alter Procedure USP_Loans_Assn_Q13_Parameter
@FirstName varchar(20) = 'AKI'
As
Begin
Select B.Firstname AS BorrowerName
From Borrower B
LEFT JOIN Loan L ON B.BorrowerId = L.BorrowerID
WHERE B.Firstname = CASE When @FirstName = 'AKI' Then B.Firstname 
Else @FirstName END AND PropertyID IS NULL
End

Exec USP_Loans_Assn_Q13_Parameter 'Patrick'


-- 8)WAQ TO display BorrowerName,PropertyName,Coborrowername,LoanAmount for Borrowers with Mutiple Properties and 
-- Doesn�t have coborrowers and both Properties are Active

Alter Procedure USP_Loans_Assn_Q8_Parameter
@Coborrower int = 0
As
Begin
With BorrowerWithMultipleProp
As
(
Select BorrowerId from Loan 
Group By BorrowerID Having Count(*) > 1  
)
Select *
From BorrowerWithMultipleProp Bo
JOIN Loan L ON Bo.BorrowerId = L.BorrowerId
JOIN Borrower B ON B.BorrowerId = Bo.BorrowerID
JOIN Property P ON L.PropertyID = P.PropertyID
LEFT JOIN CoBorrower C ON B.BorrowerId = C.BorrowerId
WHERE  C.CoBorrowerId = Case When @Coborrower = 0 Then C.CoBorrowerId
						Else @Coborrower End
OR C.CoBorrowerId Is Null  
End

Exec USP_Loans_Assn_Q8_Parameter 2